using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Uninter.Correios.Domain.Interfaces.Api;
using Uninter.Correios.Domain.Request.Token;

namespace Uninter.Correios.Api.Controllers;


[ApiController]
[Route("api/v1/auth")]
[Produces("application/json")]
public sealed class AuthController : BaseController
{
    private readonly ITokenApi _tokenApi;
    private readonly ILogger<AuthController> _logger;

    public AuthController(ITokenApi tokenApi,ILogger<AuthController> logger)
    {
        _tokenApi = tokenApi;
        _logger = logger;
    }
        
    [AllowAnonymous]
    [HttpPost()]
    public async Task<IActionResult> GetTokenAsync([FromBody] TokenJwtRequest request)
    {
        if (request == null || string.IsNullOrWhiteSpace(request.UserName))
        {
            _logger.LogWarning("Tentativa de obter token JWT sem userName");
            return BadRequest(new { success = false, errors = new[] { "userName é obrigatório" } });
        }

        var sanitizedUserName = request.UserName.Replace("\r", string.Empty).Replace("\n", string.Empty);
        _logger.LogInformation("Solicitando token JWT para userName: {UserName}", sanitizedUserName);

        var tokenResponse = await _tokenApi.GetTokenJwtAsync(request);

        if (tokenResponse?.Data != null)
        {
            _logger.LogInformation("Token JWT obtido com sucesso. Expira em: {Expiration}", tokenResponse.Data.Expiration);
        }

        return Ok(tokenResponse);
    }
}
