using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Uninter.Correios.Api.Controllers;

public class BaseController : Controller
{
    private static readonly string[] error = ["Internal Server Error."];

    /// <summary>
    ///
    /// </summary>
    /// <param name="result"></param>
    /// <param name="notifications"></param>
    /// <returns></returns>
    [NonAction]
    public new IActionResult Response(object result, IReadOnlyCollection<string> notifications = null)
    {
        if (notifications == null || notifications.Count == 0)
        {
            try
            {
                return Ok(new
                {
                    success = true,
                    data = result
                });
            }
            catch
            {
                return BadRequest(new
                {
                    success = false,
                    errors = error
                });
            }
        }
        else
        {
            return BadRequest(new
            {
                success = false,
                errors = notifications
            });
        }
    }
}
