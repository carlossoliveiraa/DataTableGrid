using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Uninter.Core.V5.Log;
using Uninter.Correios.CrossCutting.Constants;
using Uninter.Correios.Domain.Interfaces.Service;
using Uninter.Correios.Domain.Request.Cep;

namespace Uninter.Correios.Api.Controllers;

[Route("cep")]
public class CepController(ICepService cepService) : BaseController
{
    private readonly ICepService _cepService = cepService;
    
    
    [HttpGet("v1/get/{cep}"), Authorize(Policy = "SistemasInternos")]
    public async Task<IActionResult> ConsultarCepAsync(string cep)
    {
        var cepLog = cep?.Replace("\r", "").Replace("\n", "");
        Logger.Information($"Iniciando consulta de CEP: {cepLog}");

        var request = new ConsultarCepRequest(cep);
        var resultado = await _cepService.ConsultarCepAsync(request);

        if (resultado == null)
        {
            Logger.Information($"CEP não encontrado: {cepLog}");
            return Ok(new
            {
                success = false,
                message = CorreiosConstants.ErrorMessages.CEP_NAO_ENCONTRADO,
                data = (object)null
            });
        }

        Logger.Information($"Consulta de CEP concluída com sucesso: {cepLog}");
        return Response(resultado);
    }
}
