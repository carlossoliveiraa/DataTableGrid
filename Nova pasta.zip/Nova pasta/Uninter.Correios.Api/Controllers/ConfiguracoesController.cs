using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Uninter.Core.V5.Log;
using Uninter.Correios.Domain.Interfaces.Service;
using Uninter.Correios.Domain.Request.ConfiguracaoAplicacao;

namespace Uninter.Correios.Api.Controllers;

[Route("configuracao-aplicacao")]
public class ConfiguracoesController(
    ICorreiosConfiguracaoService service) : BaseController
{
    private readonly ICorreiosConfiguracaoService _service = service;

    [HttpGet("v1/listar"), Authorize(Policy = "SistemasInternos")]
    public async Task<IActionResult> ListarAsync()
    {
        Logger.Information("Listando configurações dos Correios");
        var resultado = await _service.ListarTodosAsync();
        return Response(resultado);
    }

    [HttpGet("v1/get/{id:int}"), Authorize(Policy = "SistemasInternos")]
    public async Task<IActionResult> ObterPorIdAsync(int id)
    {
        Logger.Information($"Buscando configuração dos Correios por Id: {id}");
        var resultado = await _service.ObterPorIdAsync(id);
        if (resultado == null)
            return Ok(new { success = false, message = "Configuração não encontrada.", data = (object)null });
        return Response(resultado);
    }

    [HttpPost("v1/inserir"), Authorize(Policy = "SistemasInternos")]
    public async Task<IActionResult> InserirAsync([FromBody] CorreiosConfiguracaoInserirRequest request)
    {
        Logger.Information("Inserindo nova configuração dos Correios");
        var id = await _service.InserirAsync(request);
        return Response(new { id });
    }

    [HttpPut("v1/atualizar/{id:int}"), Authorize(Policy = "SistemasInternos")]
    public async Task<IActionResult> AtualizarAsync(int id, [FromBody] CorreiosConfiguracaoAtualizarRequest request)
    {
        Logger.Information($"Atualizando configuração dos Correios Id: {id}");
        await _service.AtualizarAsync(id, request.Token, request.Observacao);
        return Response(new { success = true });
    }

    [HttpDelete("v1/excluir/{id:int}"), Authorize(Policy = "SistemasInternos")]
    public async Task<IActionResult> ExcluirAsync(int id)
    {
        Logger.Information($"Excluindo (lógico) configuração dos Correios Id: {id}");
        await _service.ExcluirLogicoAsync(id);
        return Response(new { success = true });
    }

    [HttpPost("v1/recarregar-token-cache"), Authorize(Policy = "SistemasInternos")]
    public async Task<IActionResult> RecarregarTokenCacheAsync()
    {
        Logger.Information("Recarregando cache de token dos Correios a partir do banco de dados");
        var expiracao = await _service.RecarregarTokenCacheAsync();
        Logger.Information($"Cache de token dos Correios recarregado com sucesso. Expira em: {expiracao:dd/MM/yyyy HH:mm}");
        return Response(new { success = true, expiracao });
    }
}
