using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Uninter.Core.V5.Log;
using Uninter.Correios.Domain.Interfaces.Service;
using Uninter.Correios.Domain.Request.Api;
using Uninter.Correios.Domain.Response;

namespace Uninter.Correios.Api.Controllers;


[Route("enderecos")]
public class EnderecoController(IEnderecoService enderecoService) : BaseController
{
    private readonly IEnderecoService _enderecoService = enderecoService;

    [HttpGet("v1/get"), Authorize(Policy = "SistemasInternos")]
    public async Task<IActionResult> ListarEnderecosAsync([FromQuery] ListaEnderecosQueryParams queryParams)
    {
        Logger.Information("Iniciando busca de endereços");

        var (resultado, erro) = await _enderecoService.ListarEnderecosAsync(queryParams);

        // Retorna erro de validação
        if (!string.IsNullOrEmpty(erro))
        {
            var erroLog = erro.Replace("\r", "").Replace("\n", "");
            Logger.Warning($"Erro de validação ao buscar endereços: {erroLog}");
            return BadRequest(new MessageResponse
            {
                Msgs = new List<string> { erro }
            });
        }

        Logger.Information($"Busca de endereços concluída. Total de elementos: {resultado?.Page.TotalElements ?? 0}");

        return Response(resultado);
    }
}
