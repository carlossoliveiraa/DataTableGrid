using System.Threading.Tasks;
using Hangfire;
using Hangfire.Server;
using Uninter.Correios.Domain.Interfaces.Service;

namespace Uninter.Correios.Api.Jobs;

/// <summary>
/// Job Hangfire responsável APENAS pelo download dos arquivos dos Correios.
/// Não executa a importação - apenas baixa o arquivo ZIP.
/// </summary>
[DisableConcurrentExecution(timeoutInSeconds: 0)]
[AutomaticRetry(Attempts = 3, DelaysInSeconds = new[] { 60, 600, 3600 })]
public class BaixarArquivosCorreiosJob : BaseJob
{
    private readonly IImportaDadosCorreiosService _service;

    protected override string NomeJob => "BaixarArquivosCorreios";

    public BaixarArquivosCorreiosJob(
        IImportaDadosCorreiosService service,
        IEmailNotificationService emailNotificationService) 
        : base(emailNotificationService)
    {
        _service = service;
    }

    protected override async Task ExecutarJobAsync(PerformContext context)
    {
        await _service.DownloadEExecutarAsync(context);
    }
}
