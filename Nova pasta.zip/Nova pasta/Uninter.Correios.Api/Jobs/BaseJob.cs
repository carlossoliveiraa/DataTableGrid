using System;
using System.Data.Common;
using System.Diagnostics;
using System.Runtime;
using System.Threading.Tasks;
using Hangfire.Console;
using Hangfire.Server;
using Uninter.Correios.Domain.Enum;
using Uninter.Correios.Domain.Interfaces.Service;
using Uninter.Correios.Domain.Models;

namespace Uninter.Correios.Api.Jobs;

/// <summary>
/// Classe base abstrata para jobs Hangfire, eliminando código duplicado.
/// Encapsula tratamento de erros, logging, limpeza de memória e notificações por email.
/// </summary>
public abstract class BaseJob
{
    private readonly IEmailNotificationService _emailNotificationService;

    protected BaseJob(IEmailNotificationService emailNotificationService)
    {
        _emailNotificationService = emailNotificationService;
    }

    protected abstract string NomeJob { get; }
    
    /// <summary>
    /// Indica se este job deve enviar notificações por email
    /// </summary>
    protected virtual bool EnviarNotificacoesEmail => false;
    
    /// <summary>
    /// Retorna informações sobre a execução bem-sucedida do job (para notificação)
    /// </summary>
    protected virtual (int QuantidadeRegistros, string NomeArquivo) ObterInformacoesExecucao()
    {
        return (0, "N/A");
    }

    /// <summary>
    /// Método público chamado pelo Hangfire. Orquestra execução com tratamento de erros e notificações.
    /// </summary>
    public async Task ExecuteAsync(PerformContext context)
    {
        var sw = Stopwatch.StartNew();
        var dataInicio = DateTime.Now;
        
        try
        {
            LogarInicio(context);
            
            await ExecutarJobAsync(context);
            
            sw.Stop();
            LogarSucesso(context, sw.Elapsed);
            
            // Enviar email de sucesso se configurado
            if (EnviarNotificacoesEmail)
            {
                try
                {
                    var (quantidadeRegistros, nomeArquivo) = ObterInformacoesExecucao();

                    await _emailNotificationService.EnviarEmailAsync(
                        TipoNotificacaoEmail.NovaImportacao,
                        new EmailDadosNotificacao
                        {
                            DataImportacao = dataInicio,
                            QuantidadeRegistros = quantidadeRegistros,
                            NomeArquivo = nomeArquivo,
                            TempoProcessamento = sw.Elapsed
                        });

                    context?.WriteLine("📧 Email de sucesso enviado");
                }
                catch (Exception exEmail)
                {
                    context?.WriteLine($"⚠️  Erro ao enviar email (não bloqueante): {exEmail.Message}");
                }
            }
            
            LiberarMemoria(context);
        }
        catch (Exception ex)
        {
            sw.Stop();
            LogarErro(context, ex, sw.Elapsed);
            
            // Enviar email de falha se configurado
            if (EnviarNotificacoesEmail)
            {
                try
                {
                    var (_, nomeArquivo) = ObterInformacoesExecucao();

                    await _emailNotificationService.EnviarEmailAsync(
                        TipoNotificacaoEmail.FalhaExecucao,
                        new EmailDadosNotificacao
                        {
                            DataFalha = dataInicio,
                            MensagemErro = ex.Message,
                            StackTrace = ex.StackTrace,
                            NomeArquivo = nomeArquivo
                        });
                    context?.WriteLine("📧 Email de falha enviado");
                }
                catch (Exception exEmail)
                {
                    context?.WriteLine($"⚠️  Erro ao enviar email (não bloqueante): {exEmail.Message}");
                }
            }
            
            throw;
        }
    }

    /// <summary>
    /// Método abstrato que cada job concreto deve implementar com sua lógica específica.
    /// </summary>
    protected abstract Task ExecutarJobAsync(PerformContext context);

    private void LogarInicio(PerformContext context)
    {
        var mensagem = $"🚀 Job {NomeJob} iniciado";
        EscreverNoConsoleSemFalhar(context, mensagem);
        Uninter.Core.V5.Log.Logger.Information($"[Hangfire] {mensagem}");
    }

    private void LogarSucesso(PerformContext context, TimeSpan duracao)
    {
        var mensagem = $"✅ Job {NomeJob} concluído com sucesso em {duracao.TotalSeconds:F1}s";
        EscreverNoConsoleSemFalhar(context, mensagem);
        Uninter.Core.V5.Log.Logger.Information($"[Hangfire] {mensagem}");
    }

    private void LogarErro(PerformContext context, Exception ex, TimeSpan duracao)
    {
        var mensagem = $"❌ Job {NomeJob} falhou após {duracao.TotalSeconds:F1}s: {ex.Message}";
        EscreverNoConsoleSemFalhar(context, mensagem);
        Uninter.Core.V5.Log.Logger.Error($"[Hangfire] Job {NomeJob} falhou", ex);
    }

    private void LiberarMemoria(PerformContext context)
    {
        var memAntes = MemoriaMB();
        EscreverNoConsoleSemFalhar(context, "🧹 Liberando memória e cache...");
        EscreverNoConsoleSemFalhar(context, $"💾 Memória antes do GC final: {memAntes} MB");

        ForcarLiberacaoMemoria();

        var memDepois = MemoriaMB();
        EscreverNoConsoleSemFalhar(context, $"✅ Cache limpo - Memória após GC: {memDepois} MB (liberado: {memAntes - memDepois} MB) - Pronto para próximo job");
    }

    private static void EscreverNoConsoleSemFalhar(PerformContext? context, string mensagem)
    {
        if (context is null)
        {
            return;
        }

        try
        {
            context.WriteLine(mensagem);
        }
        catch (Exception ex) when (ex is InvalidOperationException or ObjectDisposedException or DbException)
        {
            Uninter.Core.V5.Log.Logger.Warning(
                $"[Hangfire] Falha ao escrever no console do job (ignorado): {ex.Message}");
        }
    }

    /// <summary>
    /// Memória atual do processo em MB. Disponível para jobs derivados.
    /// </summary>
    protected static long MemoriaMB() => GC.GetTotalMemory(false) / 1024 / 1024;

    /// <summary>
    /// Força liberação agressiva de memória (LOH + Gen2 compactado). Disponível para jobs derivados.
    /// </summary>
    protected static void ForcarLiberacaoMemoria()
    {
        GCSettings.LargeObjectHeapCompactionMode = GCLargeObjectHeapCompactionMode.CompactOnce;
        GC.Collect(2, GCCollectionMode.Aggressive, blocking: true, compacting: true);
        GC.WaitForPendingFinalizers();
        GC.Collect(2, GCCollectionMode.Aggressive, blocking: true, compacting: true);
    }
}
