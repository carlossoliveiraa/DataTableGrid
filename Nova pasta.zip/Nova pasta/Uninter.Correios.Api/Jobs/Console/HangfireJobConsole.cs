using Hangfire.Console;
using Hangfire.Console.Progress;
using Hangfire.Server;

using Uninter.Correios.CrossCutting.Jobs;

namespace Uninter.Correios.Api.Jobs.Console;

/// <summary>
/// Adapta o <see cref="PerformContext"/> do Hangfire para o contrato neutro
/// <see cref="IJobConsole"/> consumido pela camada de serviço.
/// </summary>
public sealed class HangfireJobConsole : IJobConsole
{
    private readonly PerformContext _context;

    public HangfireJobConsole(PerformContext context)
    {
        _context = context;
    }

    /// <summary>
    /// Cria um <see cref="IJobConsole"/> a partir de um <see cref="PerformContext"/>,
    /// retornando um console no-op caso o contexto seja nulo (chamada fora do Hangfire).
    /// </summary>
    public static IJobConsole Para(PerformContext context)
        => context is null ? NullJobConsole.Instance : new HangfireJobConsole(context);

    public void EscreverLinha(string mensagem = "")
        => _context.WriteLine(mensagem);

    public IJobProgressBar IniciarBarraProgresso()
        => new HangfireProgressBar(_context.WriteProgressBar());

    private sealed class HangfireProgressBar : IJobProgressBar
    {
        private readonly IProgressBar _progressBar;

        public HangfireProgressBar(IProgressBar progressBar)
        {
            _progressBar = progressBar;
        }

        public void DefinirValor(int porcentagem) => _progressBar.SetValue(porcentagem);
    }
}
