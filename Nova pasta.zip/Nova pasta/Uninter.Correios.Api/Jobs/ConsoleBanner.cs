using Hangfire.Console;
using Hangfire.Server;

namespace Uninter.Correios.Api.Jobs;

/// <summary>
/// Helper para exibir banners e separadores padronizados no console do Hangfire.
/// Centraliza os blocos repetidos de '═══' e '╔═╗' usados pelos jobs.
/// </summary>
internal static class ConsoleBanner
{
    private const string LinhaSimples = "═══════════════════════════════════════════════════════════════";
    private const string LinhaTopo = "╔════════════════════════════════════════════════════════════════╗";
    private const string LinhaBase = "╚════════════════════════════════════════════════════════════════╝";

    /// <summary>
    /// Banner em caixa dupla (uso para início/fim de processo).
    /// </summary>
    public static void Caixa(PerformContext? context, string titulo)
    {
        if (context == null) return;
        context.WriteLine(LinhaTopo);
        context.WriteLine($"║ {titulo,-62} ║");
        context.WriteLine(LinhaBase);
    }

    /// <summary>
    /// Cabeçalho de etapa com linha simples.
    /// </summary>
    public static void Etapa(PerformContext? context, string titulo)
    {
        if (context == null) return;
        context.WriteLine(LinhaSimples);
        context.WriteLine(titulo);
        context.WriteLine(LinhaSimples);
    }

    /// <summary>
    /// Apenas uma linha separadora simples.
    /// </summary>
    public static void Separador(PerformContext? context)
    {
        context?.WriteLine(LinhaSimples);
    }
}
