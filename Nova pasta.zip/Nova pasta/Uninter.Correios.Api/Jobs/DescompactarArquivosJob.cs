using System.Threading.Tasks;
using Hangfire;
using Hangfire.Server;
using Uninter.Correios.Domain.Interfaces.Service;

namespace Uninter.Correios.Api.Jobs;

/// <summary>
/// Job Hangfire responsável pela descompactação do arquivo eDNE_Basico.zip.
/// Extrai o arquivo principal e identifica os arquivos internos (Delta e Full),
/// direcionando cada um para sua pasta específica.
/// </summary>
[DisableConcurrentExecution(timeoutInSeconds: 0)]
[AutomaticRetry(Attempts = 3, DelaysInSeconds = new[] { 60, 600, 3600 })]
public class DescompactarArquivosJob : BaseJob
{
    private readonly IDescompactaDadosService _service;

    protected override string NomeJob => "DescompactarArquivos";

    public DescompactarArquivosJob(
        IDescompactaDadosService service,
        IEmailNotificationService emailNotificationService)
        : base(emailNotificationService)
    {
        _service = service;
    }

    protected override async Task ExecutarJobAsync(PerformContext context)
    {
        await _service.UnzipAsync(context);
    }
}
