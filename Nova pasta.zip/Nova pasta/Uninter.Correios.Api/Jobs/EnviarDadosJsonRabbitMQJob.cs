using System.Threading.Tasks;
using Hangfire;
using Hangfire.Server;
using Uninter.Correios.Domain.Interfaces.Service;

namespace Uninter.Correios.Api.Jobs;

[DisableConcurrentExecution(timeoutInSeconds: 0)]
[AutomaticRetry(Attempts = 3, DelaysInSeconds = new[] { 60, 600, 3600 })]
public class EnviarDadosJsonRabbitMQJob : BaseJob
{
    private readonly IEnviarDadosJsonRabbitMQService _service;

    protected override string NomeJob => "EnviarDadosJsonRabbitMQ";

    /// <summary>
    /// Este job é o último da cadeia orquestrada por <see cref="ImportacaoCorreiosV2Job"/>.
    /// Ao concluir com sucesso, dispara o e-mail de "Nova Importação" sinalizando fim do processo completo.
    /// </summary>
    protected override bool EnviarNotificacoesEmail => true;

    public EnviarDadosJsonRabbitMQJob(
        IEnviarDadosJsonRabbitMQService service,
        IEmailNotificationService emailNotificationService)
        : base(emailNotificationService)
    {
        _service = service;
    }

    protected override async Task ExecutarJobAsync(PerformContext context)
    {
        await _service.ProcessarArquivosJsonAsync(context);
    }
}
