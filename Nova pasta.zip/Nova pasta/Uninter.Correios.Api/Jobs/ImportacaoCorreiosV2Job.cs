using System;
using System.Diagnostics;
using System.Threading.Tasks;
using Hangfire;
using Hangfire.Console;
using Hangfire.Server;
using Uninter.Correios.Domain.Interfaces.Service;

namespace Uninter.Correios.Api.Jobs;

/// <summary>
/// Job de Importação Correios V2.
///
/// Executa o processo COMPLETO em uma única execução, em sequência, exibindo o status
/// de cada fase no console do Hangfire (mesmo card). O usuário acompanha tudo abrindo
/// um único job — sem precisar navegar entre vários cards.
///
/// Fases:
///   FASE 1/5 - Precheck (consulta API dos Correios)
///   FASE 2/5 - Baixar arquivos ZIP
///   FASE 3/5 - Descompactar arquivos
///   FASE 4/5 - Importar dados (MERGE FULL) + grava DataAtualizacaoCorreios
///   FASE 5/5 - Enviar JSON para RabbitMQ
///
/// Em caso de falha em qualquer fase, o job inteiro retenta (3 tentativas, backoff 1min/10min/1h).
/// E-mail de sucesso/falha é disparado pela BaseJob ao final.
/// </summary>
[DisableConcurrentExecution(timeoutInSeconds: 0)]
[AutomaticRetry(Attempts = 3, DelaysInSeconds = new[] { 60, 600, 3600 })]
public class ImportacaoCorreiosV2Job : BaseJob
{
    private readonly ICorreiosAtualizacaoService _atualizacaoService;
    private readonly IImportaDadosCorreiosService _downloadService;
    private readonly IDescompactaDadosService _descompactaService;
    private readonly IExecutaImportadorService _importadorService;
    private readonly IEnviarDadosJsonRabbitMQService _rabbitMQService;

    protected override string NomeJob => "ImportacaoCorreiosV2";

    // E-mail de sucesso/falha é enviado por este job ao final do processo completo.
    protected override bool EnviarNotificacoesEmail => true;

    public ImportacaoCorreiosV2Job(
        ICorreiosAtualizacaoService atualizacaoService,
        IImportaDadosCorreiosService downloadService,
        IDescompactaDadosService descompactaService,
        IExecutaImportadorService importadorService,
        IEnviarDadosJsonRabbitMQService rabbitMQService,
        IEmailNotificationService emailNotificationService)
        : base(emailNotificationService)
    {
        _atualizacaoService = atualizacaoService;
        _downloadService = downloadService;
        _descompactaService = descompactaService;
        _importadorService = importadorService;
        _rabbitMQService = rabbitMQService;
    }

    protected override async Task ExecutarJobAsync(PerformContext context)
    {
        var swTotal = Stopwatch.StartNew();
        var swFase = new Stopwatch();

        ConsoleBanner.Caixa(context, "IMPORTAÇÃO CORREIOS V2 - PROCESSO COMPLETO");
        context?.WriteLine($"⏱️  Início do processo: {DateTime.Now:dd/MM/yyyy HH:mm:ss}");
        context?.WriteLine("ℹ️  Este job executa todas as fases em sequência. Acompanhe os status abaixo.");
        context?.WriteLine("");

        // ===== FASE 1/5 - PRECHECK =====
        ConsoleBanner.Etapa(context, "🔍 FASE 1/5 - PRECHECK: VERIFICAR ATUALIZAÇÃO DISPONÍVEL");
        swFase.Restart();

        var (haAtualizacao, primeiraExecucao, dataAtualizacaoCorreios) =
            await _atualizacaoService.VerificarEGravarDataInicialSeNecessarioAsync();

        if (!dataAtualizacaoCorreios.HasValue)
        {
            ConsoleBanner.Caixa(context, "⛔ PROCESSO ENCERRADO - DATA DE ATUALIZAÇÃO NÃO OBTIDA");
            context?.WriteLine("A API dos Correios (GET /cep/v1/atualizacao) não retornou o campo 'atualizadoEm'.");
            context?.WriteLine("➡️  Verifique o token de acesso configurado no banco de dados.");
            context?.WriteLine($"⏱️  Tempo até encerramento: {swTotal.Elapsed.TotalSeconds:F1}s");

            Uninter.Core.V5.Log.Logger.Warning(
                "[Hangfire] ImportacaoCorreiosV2 - Encerrado: API não retornou 'atualizadoEm'. Verifique o token."
            );
            return;
        }

        if (!haAtualizacao)
        {
            ConsoleBanner.Caixa(context, "ℹ️  NENHUMA ATUALIZAÇÃO DISPONÍVEL");
            context?.WriteLine($"📅 Data dos Correios: {dataAtualizacaoCorreios.Value:dd/MM/yyyy HH:mm:ss}");
            context?.WriteLine("Os dados já estão atualizados. Nenhuma fase adicional será executada.");
            context?.WriteLine($"⏱️  Tempo total: {swTotal.Elapsed.TotalSeconds:F1}s");

            Uninter.Core.V5.Log.Logger.Information(
                "[Hangfire] ImportacaoCorreiosV2 - Nenhuma atualização disponível."
            );
            return;
        }

        if (primeiraExecucao)
            context?.WriteLine("🆕 PRIMEIRA EXECUÇÃO detectada — todos os dados serão importados.");
        else
            context?.WriteLine("✅ Atualização disponível!");

        context?.WriteLine($"📅 Data dos Correios: {dataAtualizacaoCorreios.Value:dd/MM/yyyy HH:mm:ss}");
        context?.WriteLine($"✅ FASE 1/5 concluída em {swFase.Elapsed.TotalSeconds:F1}s");
        context?.WriteLine("➡️  Próxima fase: download dos arquivos...");
        context?.WriteLine("");

        // ===== FASE 2/5 - DOWNLOAD =====
        ConsoleBanner.Etapa(context, "⬇️  FASE 2/5 - BAIXAR ARQUIVOS DOS CORREIOS");
        swFase.Restart();

        await _downloadService.DownloadEExecutarAsync(context);

        context?.WriteLine($"✅ FASE 2/5 concluída em {swFase.Elapsed.TotalSeconds:F1}s");
        context?.WriteLine($"💾 Memória atual: {MemoriaMB()} MB");
        context?.WriteLine("➡️  Próxima fase: descompactação...");
        context?.WriteLine("");

        // ===== FASE 3/5 - DESCOMPACTAR =====
        ConsoleBanner.Etapa(context, "📦 FASE 3/5 - DESCOMPACTAR ARQUIVOS");
        swFase.Restart();

        await _descompactaService.UnzipAsync(context);

        context?.WriteLine($"✅ FASE 3/5 concluída em {swFase.Elapsed.TotalSeconds:F1}s");
        context?.WriteLine($"💾 Memória atual: {MemoriaMB()} MB");
        context?.WriteLine("➡️  Próxima fase: importação para o banco (MERGE FULL)...");
        context?.WriteLine("");

        // ===== FASE 4/5 - IMPORTAR (FULL) =====
        ConsoleBanner.Etapa(context, "🗃️  FASE 4/5 - IMPORTAR DADOS NO BANCO (MERGE FULL)");
        swFase.Restart();

        await _importadorService.ExecutarPorTipoAsync("full", context);

        context?.WriteLine("");
        context?.WriteLine("🔄 Gravando DataAtualizacaoCorreios no banco...");
        try
        {
            await _atualizacaoService.AtualizarDataAtualizacaoAsync(dataAtualizacaoCorreios.Value);
            context?.WriteLine($"✅ DataAtualizacaoCorreios = {dataAtualizacaoCorreios.Value:dd/MM/yyyy HH:mm:ss} gravada com sucesso.");
        }
        catch (Exception ex)
        {
            context?.WriteLine($"⚠️  Erro ao gravar DataAtualizacaoCorreios (não bloqueante): {ex.Message}");
            Uninter.Core.V5.Log.Logger.Warning(
                $"[Hangfire] ImportacaoCorreiosV2 - Erro ao gravar DataAtualizacaoCorreios: {ex.Message}"
            );
        }

        context?.WriteLine($"✅ FASE 4/5 concluída em {swFase.Elapsed.TotalSeconds:F1}s");
        context?.WriteLine($"💾 Memória atual: {MemoriaMB()} MB");
        context?.WriteLine("➡️  Próxima fase: envio para RabbitMQ...");
        context?.WriteLine("");

        // ===== FASE 5/5 - ENVIAR RABBITMQ =====
        ConsoleBanner.Etapa(context, "📨 FASE 5/5 - ENVIAR JSON PARA RABBITMQ");
        swFase.Restart();

        await _rabbitMQService.ProcessarArquivosJsonAsync(context);

        context?.WriteLine($"✅ FASE 5/5 concluída em {swFase.Elapsed.TotalSeconds:F1}s");
        context?.WriteLine("");

        // ===== ENCERRAMENTO =====
        swTotal.Stop();
        ConsoleBanner.Caixa(context, "🎉 PROCESSO COMPLETO FINALIZADO COM SUCESSO");
        context?.WriteLine($"⏱️  Tempo total do processo: {swTotal.Elapsed.TotalMinutes:F1} min ({swTotal.Elapsed.TotalSeconds:F0}s)");
        context?.WriteLine($"📅 Data dos Correios processada: {dataAtualizacaoCorreios.Value:dd/MM/yyyy HH:mm:ss}");
        context?.WriteLine("📧 E-mail de notificação será enviado a seguir.");

        Uninter.Core.V5.Log.Logger.Information(
            $"[Hangfire] ImportacaoCorreiosV2 - Processo completo finalizado com sucesso em {swTotal.Elapsed.TotalSeconds:F0}s."
        );
    }
}
