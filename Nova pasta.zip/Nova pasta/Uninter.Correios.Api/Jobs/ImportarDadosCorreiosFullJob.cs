using System;
using System.Threading.Tasks;
using Hangfire;
using Hangfire.Console;
using Hangfire.Server;
using Uninter.Correios.Domain.Interfaces.Service;

namespace Uninter.Correios.Api.Jobs;

[DisableConcurrentExecution(timeoutInSeconds: 0)]
[AutomaticRetry(Attempts = 3, DelaysInSeconds = new[] { 60, 600, 3600 })]
public class ImportarDadosCorreiosFullJob : BaseJob
{
    private readonly IExecutaImportadorService _service;
    private readonly ICorreiosAtualizacaoService _atualizacaoService;

    protected override string NomeJob => "ImportarDadosCorreios FULL";

    public ImportarDadosCorreiosFullJob(
        IExecutaImportadorService service,
        ICorreiosAtualizacaoService atualizacaoService,
        IEmailNotificationService emailNotificationService)
        : base(emailNotificationService)
    {
        _service = service;
        _atualizacaoService = atualizacaoService;
    }

    protected override async Task ExecutarJobAsync(PerformContext context)
    {
        await _service.ExecutarPorTipoAsync("full", context);

        context?.WriteLine("");
        context?.WriteLine("🔄 Atualizando DataAtualizacaoCorreios no banco de dados...");

        try
        {
            await _atualizacaoService.AtualizarDataAtualizacaoAsync();
            context?.WriteLine("✅ DataAtualizacaoCorreios atualizada com sucesso.");
        }
        catch (Exception ex)
        {
            context?.WriteLine($"⚠️  Erro ao atualizar DataAtualizacaoCorreios: {ex.Message}");
            Uninter.Core.V5.Log.Logger.Warning(
                $"[Hangfire] ImportarDadosCorreiosFullJob - Erro ao atualizar DataAtualizacaoCorreios: {ex.Message}"
            );
        }
    }
}
