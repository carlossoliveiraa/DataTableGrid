using System;
using System.Threading.Tasks;
using Hangfire.Console;
using Hangfire.Server;
using Uninter.Correios.Domain.Interfaces.Infra;
using Uninter.Correios.Domain.Interfaces.Service;

namespace Uninter.Correios.Api.Jobs;

public class VerificarTokenCorreiosJob : BaseJob
{
    private readonly ICorreiosTokenCache _tokenCache;
    private readonly IEmailNotificationService _emailService;

    protected override string NomeJob => "VerificarTokenCorreios";

    public VerificarTokenCorreiosJob(
        ICorreiosTokenCache tokenCache,
        IEmailNotificationService emailService)
        : base(emailService)
    {
        _tokenCache = tokenCache;
        _emailService = emailService;
    }

    protected override async Task ExecutarJobAsync(PerformContext context)
    {
        ConsoleBanner.Etapa(context, "🔐 VERIFICAÇÃO DE EXPIRAÇÃO DO TOKEN DOS CORREIOS");
        context?.WriteLine("");

        try
        {
            // Obter data de expiração do token
            var dataExpiracao = _tokenCache.ObterDataExpiracao();

            if (!dataExpiracao.HasValue)
            {
                context?.WriteLine("⚠️  Token não possui data de expiração configurada.");
                context?.WriteLine("ℹ️  Verifique se o token foi cadastrado corretamente no sistema.");
                Uninter.Core.V5.Log.Logger.Warning(
                    "[Hangfire] VerificarTokenCorreios - Token sem data de expiração configurada"
                );
                return;
            }

            var diasRestantes = (dataExpiracao.Value.Date - DateTime.Now.Date).Days;

            context?.WriteLine($"📅 Data de expiração: {dataExpiracao.Value:dd/MM/yyyy HH:mm:ss}");
            context?.WriteLine($"⏳ Dias restantes: {diasRestantes} dias");
            context?.WriteLine("");

            if (diasRestantes < 0)
            {
                context?.WriteLine("❌ CRÍTICO: Token EXPIRADO!");
                context?.WriteLine("⚠️  O token expirou e precisa ser renovado IMEDIATAMENTE!");
                Uninter.Core.V5.Log.Logger.Warning(
                    $"[Hangfire] VerificarTokenCorreios - Token EXPIRADO há {Math.Abs(diasRestantes)} dias (CRÍTICO)"
                );
            }
            else if (diasRestantes == 0)
            {
                context?.WriteLine("❌ CRÍTICO: Token expira HOJE!");
                Uninter.Core.V5.Log.Logger.Warning(
                    "[Hangfire] VerificarTokenCorreios - Token expira hoje (CRÍTICO)"
                );
            }
            else if (diasRestantes <= 5)
            {
                context?.WriteLine("🔴 URGENTE: Token expira em breve!");
                Uninter.Core.V5.Log.Logger.Warning(
                    $"[Hangfire] VerificarTokenCorreios - Token expira em {diasRestantes} dias (CRÍTICO)"
                );
            }
            else if (diasRestantes <= 10)
            {
                context?.WriteLine("🟡 ATENÇÃO: Token expirando em breve!");
                Uninter.Core.V5.Log.Logger.Warning(
                    $"[Hangfire] VerificarTokenCorreios - Token expira em {diasRestantes} dias (ALERTA)"
                );
            }
            else
            {
                context?.WriteLine("✅ Token ainda válido por um período adequado.");
                Uninter.Core.V5.Log.Logger.Information(
                    $"[Hangfire] VerificarTokenCorreios - Token expira em {diasRestantes} dias"
                );
            }

            context?.WriteLine("");
            context?.WriteLine("📧 Verificando necessidade de enviar notificação...");

            // Verificar e enviar email se necessário
            await _emailService.VerificarEEnviarEmailTokenExpiracaoAsync(dataExpiracao.Value);

            context?.WriteLine("✅ Verificação de token concluída com sucesso");
            context?.WriteLine("");
        }
        catch (Exception ex)
        {
            context?.WriteLine($"❌ Erro ao verificar token: {ex.Message}");
            Uninter.Core.V5.Log.Logger.Error(
                "[Hangfire] VerificarTokenCorreios - Erro ao verificar token",
                ex
            );
            throw;
        }
    }
}
