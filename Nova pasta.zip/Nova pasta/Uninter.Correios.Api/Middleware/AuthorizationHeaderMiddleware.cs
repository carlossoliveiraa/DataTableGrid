using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace Uninter.Correios.Api.Middleware;

public class AuthorizationHeaderMiddleware
{
    private readonly RequestDelegate _next;

    public AuthorizationHeaderMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var authHeader = context.Request.Headers["Authorization"].FirstOrDefault();

        if (string.IsNullOrWhiteSpace(authHeader))
        {
            await _next(context);
            return;
        }

        // Não normalizar credenciais Basic (usadas pelo Hangfire Dashboard). Este middleware
        // só deve tratar tokens Bearer/JWT. Se convertermos "Basic xxx" em "Bearer Basic xxx",
        // o HangfireBasicAuthMiddleware nunca reconhece o Basic Auth e entra em loop de 401.
        if (authHeader.TrimStart().StartsWith("Basic ", StringComparison.OrdinalIgnoreCase))
        {
            await _next(context);
            return;
        }

        var cleanedHeader = PrepareBearerHeader(authHeader);
        context.Request.Headers["Authorization"] = cleanedHeader;

        await _next(context);
    }

    private static string PrepareBearerHeader(string header)
    {
        var cleaned = header.Trim();
        cleaned = cleaned.Replace("bearer ", "", StringComparison.OrdinalIgnoreCase)
                         .Replace("Bearer ", "", StringComparison.OrdinalIgnoreCase)
                         .Trim();

        return $"Bearer {cleaned}";
    }
}
