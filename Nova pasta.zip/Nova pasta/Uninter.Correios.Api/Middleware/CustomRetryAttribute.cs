﻿using System;
using System.Collections.Generic;

using Hangfire.Common;
using Hangfire.States;

namespace Uninter.Correios.Api.Middleware;

public class CustomRetryAttribute : JobFilterAttribute, IElectStateFilter
{
    private readonly List<TimeSpan> _delays;

    public CustomRetryAttribute(params int[] minutes)
    {
        _delays = new List<TimeSpan>();
        foreach (var min in minutes)
            _delays.Add(TimeSpan.FromMinutes(min));
    }

    public void OnStateElection(ElectStateContext context)
    {
        if (context.CandidateState is FailedState)
        {
            var retryCount = context.GetJobParameter<int>("RetryCount");
            if (retryCount < _delays.Count)
            {
                context.SetJobParameter("RetryCount", retryCount + 1);
                context.CandidateState = new ScheduledState(_delays[retryCount]);
            }
            else
            {              
                Console.WriteLine("Job atingiu o limite de tentativas e será marcado como falha definitiva.");
            }
        }
    }
}
