﻿using Hangfire.Dashboard;

namespace Uninter.Correios.Api.Middleware;

public class HangfireBasicAuthFilter : IDashboardAuthorizationFilter
{
    private const string AuthenticatedItemKey = "HangfireBasicAuthOk";

    public bool Authorize(DashboardContext context)
    {
        var httpContext = context.GetHttpContext();
        return httpContext.Items.TryGetValue(AuthenticatedItemKey, out var flag)
               && flag is bool ok
               && ok;
    }
}
