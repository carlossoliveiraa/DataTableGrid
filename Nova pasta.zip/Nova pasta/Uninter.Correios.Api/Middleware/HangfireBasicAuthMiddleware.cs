using System;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Uninter.Correios.Domain.Interfaces.Api;
using Uninter.Correios.Domain.Request.Api;

namespace Uninter.Correios.Api.Middleware;

public class HangfireBasicAuthMiddleware
{
    private const string HangfirePathPrefix = "/hangfire";
    private const string BasicPrefix = "Basic ";
    private const string Realm = "Hangfire Dashboard (RU e senha da Uninter)";
    private const string AuthenticatedItemKey = "HangfireBasicAuthOk";
    private const string CacheKeyPrefix = "hangfire:basicauth:";

    private static readonly TimeSpan PositiveCacheTtl = TimeSpan.FromMinutes(15);
    private static readonly TimeSpan PositiveCacheMaxTtl = TimeSpan.FromHours(4);
    private static readonly TimeSpan NegativeCacheTtl = TimeSpan.FromSeconds(5);
    private static readonly TimeSpan GraceCacheTtl = TimeSpan.FromHours(8);

    private readonly RequestDelegate _next;

    public HangfireBasicAuthMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(
        HttpContext context,
        IAccountApi accountApi,
        IMemoryCache cache,
        IConfiguration configuration,
        ILogger<HangfireBasicAuthMiddleware> logger)
    {
        if (!context.Request.Path.StartsWithSegments(HangfirePathPrefix))
        {
            await _next(context);
            return;
        }

        var authHeader = context.Request.Headers.Authorization.ToString();
        if (string.IsNullOrEmpty(authHeader) ||
            !authHeader.StartsWith(BasicPrefix, StringComparison.OrdinalIgnoreCase))
        {
            await ChallengeAsync(context);
            return;
        }

        if (!TryExtractCredentials(authHeader, out var ruTexto, out var senha) ||
            !int.TryParse(ruTexto, out var ru))
        {
            logger.LogWarning("[HANGFIRE] Basic Auth: header malformado (path={Path})",
                context.Request.Path.Value);
            await ChallengeAsync(context);
            return;
        }

        var cacheKey = MontarCacheKey(ruTexto, senha);
        var graceKey = cacheKey + ":grace";

        if (cache.TryGetValue<bool>(cacheKey, out var cached) && cached)
        {
            // Hit POSITIVO: o TryGetValue renova a janela deslizante (SlidingExpiration), então
            // enquanto o dashboard estiver ativo (poll de /stats a cada ~2s) a credencial não
            // expira e NÃO revalidamos na Account API a cada request. Isso elimina o 403
            // intermitente que aparecia sempre que o cache absoluto de 15min vencia no meio do
            // polling e uma chamada transitória à Account API falhava.
            context.Items[AuthenticatedItemKey] = true;
            await _next(context);
            return;
        }

        var resultado = await ValidarNaAccountApiAsync(accountApi, configuration, ru, senha, logger);

        switch (resultado)
        {
            case ValidacaoResultado.Autenticado:
                cache.Set(cacheKey, true, new MemoryCacheEntryOptions
                {
                    SlidingExpiration = PositiveCacheTtl,
                    AbsoluteExpirationRelativeToNow = PositiveCacheMaxTtl
                });
                // Marca a credencial como "já validada" por um período maior. Usado como
                // fail-open controlado quando a Account API estiver temporariamente fora.
                cache.Set(graceKey, true, GraceCacheTtl);
                logger.LogInformation("[HANGFIRE] Basic Auth: RU {Ru} autenticado com sucesso", ru);
                context.Items[AuthenticatedItemKey] = true;
                await _next(context);
                return;

            case ValidacaoResultado.ErroTransitorio
                when cache.TryGetValue<bool>(graceKey, out var conhecidoBom) && conhecidoBom:
                // Account API indisponível (timeout/5xx), mas ESSAS credenciais já foram validadas
                // recentemente. Liberamos para não derrubar um dashboard ativo por um soluço de
                // rede - o dashboard sempre trafega sob TLS.
                logger.LogWarning(
                    "[HANGFIRE] Account API indisponível; liberando RU {Ru} pelo período de graça (credencial já validada)",
                    ru);
                context.Items[AuthenticatedItemKey] = true;
                await _next(context);
                return;

            case ValidacaoResultado.Rejeitado:
                cache.Set(cacheKey, false, NegativeCacheTtl);
                logger.LogWarning("[HANGFIRE] Basic Auth: RU {Ru} rejeitado pela Account API", ru);
                await ChallengeAsync(context);
                return;

            default:
                // Erro transitório sem credencial previamente válida: não dá pra confirmar,
                // então desafia (o navegador reenvia as credenciais no próximo request).
                logger.LogWarning(
                    "[HANGFIRE] Basic Auth: não foi possível validar RU {Ru} (Account API indisponível)", ru);
                await ChallengeAsync(context);
                return;
        }
    }

    /// <summary>
    /// Responde 401 + WWW-Authenticate para o navegador exibir o prompt nativo.
    /// </summary>
    private static Task ChallengeAsync(HttpContext context)
    {
        context.Response.Clear();
        context.Response.Headers.WWWAuthenticate = $"Basic realm=\"{Realm}\", charset=\"UTF-8\"";
        context.Response.StatusCode = StatusCodes.Status401Unauthorized;
        context.Response.ContentType = "text/plain; charset=utf-8";
        return context.Response.WriteAsync("Autenticação necessária. Informe seu RU e senha da Uninter.");
    }

    /// <summary>
    /// Decodifica "Basic base64(user:senha)". Retorna false para malformado.
    /// </summary>
    private static bool TryExtractCredentials(string authHeader, out string user, out string senha)
    {
        user = string.Empty;
        senha = string.Empty;

        try
        {
            var encoded = authHeader.Substring(BasicPrefix.Length).Trim();
            if (string.IsNullOrEmpty(encoded)) return false;

            var decoded = Encoding.UTF8.GetString(Convert.FromBase64String(encoded));
            var separator = decoded.IndexOf(':');
            if (separator <= 0 || separator == decoded.Length - 1) return false;

            user = decoded.Substring(0, separator);
            senha = decoded.Substring(separator + 1);
            return !string.IsNullOrEmpty(user) && !string.IsNullOrEmpty(senha);
        }
        catch (FormatException)
        {
            return false;
        }
    }

    /// <summary>
    /// Chave de cache = SHA-256 de "ru:senha". Nunca guardar senha em texto puro na memória.
    /// </summary>
    private static string MontarCacheKey(string ru, string senha)
    {
        var payload = Encoding.UTF8.GetBytes(ru + ":" + senha);
        var hash = SHA256.HashData(payload);
        return CacheKeyPrefix + Convert.ToHexString(hash);
    }

    private static async Task<ValidacaoResultado> ValidarNaAccountApiAsync(
        IAccountApi accountApi,
        IConfiguration configuration,
        int ru,
        string senha,
        ILogger logger)
    {
        var sistema = configuration.GetValue<string>("HangfireSettings:SistemaAutenticacao")
                      ?? "contratodigital";
        var accountApiUrl = configuration.GetValue<string>("AccountApiUrl") ?? "(não configurado)";

        logger.LogInformation(
            "[HANGFIRE] Validando na Account API - URL: {Url} - RU: {Ru} - Sistema: {Sistema} - SenhaLen: {SenhaLen}",
            accountApiUrl, ru, sistema, senha?.Length ?? 0);

        try
        {
            var resposta = await accountApi.AuthenticateRu(new AuthenticateRuCommand
            {
                ru = ru,
                senha = senha,
                sistema = sistema,
                recaptchaToken = "string",
            });

            var success = resposta?.Success ?? false;
            var hasData = resposta?.Data != null;
            var hasToken = resposta?.Data?.Token != null;
            var errors = resposta?.Errors != null && resposta.Errors.Length > 0
                ? string.Join(" | ", resposta.Errors)
                : "(nenhum)";

            logger.LogInformation(
                "[HANGFIRE] Account API retornou - RU: {Ru} - Success: {Success} - HasData: {HasData} - HasToken: {HasToken} - Errors: {Errors}",
                ru, success, hasData, hasToken, errors);

            var autenticado = success && hasToken;
            if (!autenticado)
            {
                logger.LogWarning(
                    "[HANGFIRE] Credenciais REJEITADAS pela Account API para RU {Ru}. Motivo provável: {Motivo}",
                    ru,
                    !success ? $"Success=false ({errors})" :
                    !hasData ? "Data ausente na resposta" :
                    !hasToken ? "Token ausente em Data" :
                    "desconhecido");
            }

            return autenticado ? ValidacaoResultado.Autenticado : ValidacaoResultado.Rejeitado;
        }
        catch (Refit.ApiException ex)
        {
            var body = ex.Content ?? "(sem corpo de resposta)";
            logger.LogWarning(ex,
                "[HANGFIRE] Account API respondeu com erro HTTP {Status} {Reason} para RU {Ru}. Body: {Body}",
                (int)ex.StatusCode, ex.ReasonPhrase, ru, body);

            // 400/401/403 = credenciais efetivamente recusadas pela Account API.
            // Demais status (5xx, 408, etc.) são falhas transitórias de infraestrutura.
            var recusado = ex.StatusCode == HttpStatusCode.BadRequest
                           || ex.StatusCode == HttpStatusCode.Unauthorized
                           || ex.StatusCode == HttpStatusCode.Forbidden;
            return recusado ? ValidacaoResultado.Rejeitado : ValidacaoResultado.ErroTransitorio;
        }
        catch (Exception ex)
        {
            // Timeout (TaskCanceledException) e falhas de rede: tratados como transitórios para
            // não invalidar uma sessão de dashboard já autenticada.
            logger.LogError(ex, "[HANGFIRE] Erro ao validar RU {Ru} na Account API (tratado como transitório)", ru);
            return ValidacaoResultado.ErroTransitorio;
        }
    }

    private enum ValidacaoResultado
    {
        Autenticado,
        Rejeitado,
        ErroTransitorio
    }
}
