using FluentValidation;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using Refit;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Uninter.Core.V5.Log;
using Uninter.Correios.CrossCutting.Extensions;
using Uninter.Correios.CrossCutting.Helpers;

namespace Uninter.Correios.Api.Middleware;

/// <summary>
/// Middleware responsável por capturar e tratar exceções globais na aplicação.
/// </summary>
/// <remarks>
/// Este middleware substitui a necessidade de blocos try-catch espalhados pelo código.
/// Ele intercepta exceções lançadas durante o processamento das requisições e as trata de forma centralizada.
/// 
/// Recomenda-se não utilizar try-catch diretamente no código do projeto, pois todas as exceções já estão mapeadas e tratadas aqui.
/// </remarks>
public class ResponseExceptionHandler(RequestDelegate next)
{
    private readonly RequestDelegate _next = next;

    public async Task Invoke(HttpContext httpContext)
    {
        try
        {
            await _next(httpContext);
        }
        catch (Exception Error)
        {
            await HandleExceptionAsync(httpContext, Error);
        }
    }

    private async Task HandleExceptionAsync(HttpContext httpContext, Exception Error)
    {
        switch (Error)
        {
            case System.ComponentModel.DataAnnotations.ValidationException ex:
                await Response(httpContext, ExceptionHelper.GetInnerException([ex.Message], ex), ex, HttpStatusCode.NotAcceptable); break;
            case ValidationException ex:
                await Response(httpContext, ExceptionHelper.GetInnerException([.. ex.Errors.Select(x => x.ErrorMessage)], ex), ex, HttpStatusCode.NotAcceptable); break;
            case ArgumentException ex:
                await Response(httpContext, ExceptionHelper.GetInnerException([ex.Message], ex), ex, HttpStatusCode.PreconditionRequired); break;
            case KeyNotFoundException ex:
                await Response(httpContext, ExceptionHelper.GetInnerException([ex.Message], ex), ex, HttpStatusCode.NotFound); break;
            case InvalidOperationException ex:
                await Response(httpContext, ExceptionHelper.GetInnerException([ex.Message], ex), ex, HttpStatusCode.BadRequest); break;
            case SqlException ex:
                await Response(httpContext, ExceptionHelper.GetInnerException([ex.Message], ex), ex, HttpStatusCode.ServiceUnavailable); break;
            case HttpRequestException ex:
                await Response(httpContext, ExceptionHelper.GetInnerException([ex.Message], ex), ex, ex.StatusCode ?? HttpStatusCode.InternalServerError); break;
            case ApiException ex:
                await Response(httpContext, ExceptionHelper.GetInnerException([ex.RequestMessage?.RequestUri?.ToString(), ex.Content, ex.Message], ex), ex, ex.StatusCode); break;
            default:
                await Response(httpContext, ExceptionHelper.GetInnerException([Error.Message], Error), Error, HttpStatusCode.InternalServerError); break;
        }
    }

    public async Task Response(HttpContext context, IReadOnlyCollection<string> errors, Exception ex, HttpStatusCode statusCode)
    {
        context.Response.StatusCode = (int)statusCode;
        context.Response.ContentType = "text/json";
        await context.Response.WriteAsync(new { success = false, errors, ex = Environment.GetEnvironmentVariable("Ambiente") != "PROD" && ex != null ? new { ex.StackTrace, ex.Source } : null }.ToJson());
        Logger.Error($"Template.Api.Error: {NetworkHelper.GetLocalIPAddress()} {NetworkHelper.GetConnections()} {errors.ToJson()}", ex);
    }
}

public static class ResponseExceptionHandlerExtensions
{
    public static IApplicationBuilder UseResponseExceptionHandler(this IApplicationBuilder builder) => builder.UseMiddleware<ResponseExceptionHandler>();
}
