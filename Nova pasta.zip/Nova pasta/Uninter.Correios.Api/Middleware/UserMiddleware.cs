using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Uninter.Core.Authentication.Extensions;
using Uninter.Correios.CrossCutting;

namespace Uninter.Correios.Api.Middleware;

/// <summary>
/// Middleware para extrair informações do usuário autenticado do token JWT.
/// </summary>
public class UserMiddleware
{
    private readonly RequestDelegate _next;

    public UserMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // Extrai informações do usuário autenticado do token JWT
        if (context.User?.Identity?.IsAuthenticated == true)
        {
            var usuarioLogado = context.RequestServices.GetRequiredService<UsuarioLogado>();

            // Extrai o UserName do Identity
            usuarioLogado.UserName = context.User.Identity.Name;

            // Extrai o PessoaId do token (se disponível)
            try
            {
                var pessoaId = context.User.Identity.GetPessoaId();
                usuarioLogado.PessoaId = Convert.ToInt32(pessoaId);
            }
            catch
            {
                // Se não houver PessoaId no token, mantém valor padrão (0)
            }
        }

        await _next(context);
    }
}
