using System;
using System.Net;
using System.Text;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

using Uninter.Core.Authentication.Extensions;
using Uninter.Core.V5.Log;
using Uninter.Correios.Api.Middleware;
using Uninter.Correios.Api.StartupExtensions;
using Uninter.Correios.Service;

namespace Uninter.Correios.Api;

public partial class Program
{
    private static void Main(string[] args)
    {
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
   
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

        var builder = WebApplication.CreateBuilder(args);
        var appSettings = builder.AddAppSettings();

        // Autenticação padrão da Uninter (AuthenticationAPI - JWT) - APIs REST usam Bearer.
        // O Hangfire Dashboard usa HTTP Basic Auth próprio via HangfireBasicAuthFilter
        // (não passa pelo pipeline padrão de authentication/authorization do ASP.NET Core).
        builder.Services.AuthenticationAPI(builder.Environment);

        // Forwarded Headers - necessário para que HttpContext.Request.Scheme/IsHttps
        // reflitam o request original quando existe reverse proxy (ARR, F5, nginx)
        // na frente do IIS. Sem isso, UseHttpsRedirection pode gerar loops.
        builder.Services.Configure<ForwardedHeadersOptions>(options =>
        {
            options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
            options.KnownNetworks.Clear();
            options.KnownProxies.Clear();
        });

        builder.Services.AddLog(builder.Environment);
        builder.Services.AddController(builder.Environment);
        builder.Services.AddAuthorizationPolicies();
        builder.Services.AddSwagger(builder.Environment);
        builder.Services.AddRefitClients(appSettings);
        builder.Services.AddOptions();

        builder.Services.Configure<CrossCutting.RabbitMQSettings>(
            builder.Configuration.GetSection("RabbitMQ"));

        builder.Services.AddCorsPolicy();
        builder.Services.AddHttpContextAccessor();

        // Cache em memória usado pelo HangfireBasicAuthMiddleware para não bater na
        // Account API a cada request do dashboard (o próprio dashboard poll /stats a ~2s).
        builder.Services.AddMemoryCache();

        // Adicionar Hangfire com proteção contra falhas críticas
        try
        {
            Logger.Information("Inicializando Hangfire...");
            builder.Services.AddHangfire();
            Logger.Information("Hangfire inicializado com sucesso");
        }
        catch (Exception ex)
        {
            Logger.Error($"[ERRO CRÍTICO] Falha ao inicializar Hangfire: {ex.Message}", ex);
            Logger.Information("Verifique: 1) ConnectionString HangfireConnection, 2) Acesso ao SQL Server, 3) Permissões de rede");           
        }

        ApplicationModule.RegisterServices(builder.Services);

        var app = builder.Build();
        app.AddSwaggerApp();
        app.InicializarCorreiosTokenCache();

        // ForwardedHeaders PRIMEIRO - antes de qualquer coisa que dependa de Scheme/Host.
        app.UseForwardedHeaders();

        app.UseHttpsRedirection();
        app.UseStaticFiles();
        app.UseRouting();
        app.UseCorsPolicy();
        app.UseAuthorizationHeaderNormalization();
        app.UseAuthentication();
        app.UseAuthorization();
        app.UseMiddleware<UserMiddleware>();
        app.UseResponseExceptionHandler();

        // Proteção do Hangfire Dashboard: Basic Auth validando RU/senha na Account API.
        // Precisa ficar ANTES de AddHangfireApp para que o dashboard só receba requests
        // já autenticados (o middleware responde 401 + WWW-Authenticate caso contrário).
        app.UseMiddleware<HangfireBasicAuthMiddleware>();

        // Adicionar Hangfire Dashboard com proteção
        try
        {
            Logger.Information("Configurando Hangfire Dashboard...");
            app.AddHangfireApp();
            Logger.Information("Hangfire Dashboard configurado com sucesso em /hangfire");
        }
        catch (Exception ex)
        {
            Logger.Error($"[ERRO] Falha ao configurar Hangfire Dashboard: {ex.Message}", ex);
            Logger.Information("Rota /hangfire não estará disponível.");
            // NÃO fazer throw - aplicação continua sem Hangfire
        }

        app.MapControllers();
        Logger.Information("Iniciando o processo Api Correios");
        app.Run();
    }
}
