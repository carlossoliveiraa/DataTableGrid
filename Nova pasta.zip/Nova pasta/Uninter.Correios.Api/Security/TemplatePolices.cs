using Microsoft.AspNetCore.Authorization;

namespace Uninter.Correios.Api.Security;

public static class TemplatePolices
{
   
    public static void UseAuthorizationOptions(this AuthorizationOptions options)
    {      
        
        // Policy principal - valida se o Identity.Name do token é "SistemasInternos"
        options.AddPolicy("SistemasInternos", policy =>
            policy.RequireAssertion(context =>
                context.User.Identity?.Name == "SistemasInternos"));

        // Policy que aceita múltiplos usuários (SistemasInternos ou CorreiosAPI)
        options.AddPolicy("CorreiosAPI", policy =>
            policy.RequireAssertion(context =>
                context.User.Identity?.Name == "SistemasInternos" ||
                context.User.Identity?.Name == "CorreiosAPI"));    
    } 
}
