using System;

using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using Uninter.Core.V5.RabbitMq;
using Uninter.Correios.CrossCutting.Configurations;
using Uninter.Correios.Infra.Configuration;

namespace Uninter.Correios.Api.StartupExtensions;

public static class AppSettingsExtensions
{
    public static AppSettings AddAppSettings(this WebApplicationBuilder builder)
    {
        var hangfireConn = builder.Configuration.GetConnectionString("HangfireConnection");
        var zipCodeConn = builder.Configuration.GetConnectionString("ZipCodeConnection");
        
        // VALIDAÇÃO CRÍTICA: ConnectionStrings devem existir
        if (string.IsNullOrWhiteSpace(hangfireConn))
        {
            var env = builder.Configuration["Ambiente"] ?? "UNKNOWN";
            var msg = $"[ERRO CRÍTICO] HangfireConnection não configurada no ambiente {env}! Verifique appsettings.json";
            Console.WriteLine(msg);
            throw new InvalidOperationException(msg);
        }
        
        if (string.IsNullOrWhiteSpace(zipCodeConn))
        {
            var env = builder.Configuration["Ambiente"] ?? "UNKNOWN";
            var msg = $"[ERRO CRÍTICO] ZipCodeConnection não configurada no ambiente {env}! Verifique appsettings.json";
            Console.WriteLine(msg);
            throw new InvalidOperationException(msg);
        }
        
        DatabaseConfiguration.HangfireConnection = hangfireConn;
        DatabaseConfiguration.ZipCodeConnection = zipCodeConn;
        
        Console.WriteLine($"[CONFIG] HangfireConnection configurada: {hangfireConn.Substring(0, Math.Min(50, hangfireConn.Length))}...");
        Console.WriteLine($"[CONFIG] ZipCodeConnection configurada: {zipCodeConn.Substring(0, Math.Min(50, zipCodeConn.Length))}...");

        var config = builder.Configuration;
        if (config["AplicacaoNome"] is { } nome) Environment.SetEnvironmentVariable("AplicacaoNome", nome);
        if (config["Ambiente"] is { } ambiente) Environment.SetEnvironmentVariable("Ambiente", ambiente);
        if (config["EmailDEVQA"] is { } emailDevQa) Environment.SetEnvironmentVariable("EmailDEVQA", emailDevQa);

        RabbitMqConfig.SetEnviromentVariablesApi();

        builder.Services.Configure<AppSettings>(builder.Configuration);
        var appSettings = builder.Configuration.Get<AppSettings>();

        return appSettings;
    }
}
