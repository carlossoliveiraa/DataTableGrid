using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;

using Uninter.Core.Authentication.PrivilegioCore;
using Uninter.Correios.Api.Security;
using Uninter.Correios.CrossCutting;

namespace Uninter.Correios.Api.StartupExtensions;

public static class AuthorizationExtensions
{
    public static IServiceCollection AddAuthorizationPolicies(this IServiceCollection services)
    {
        // Configuração de Authorization Policies
        services.AddAuthorization(options => 
        { 
            options.UseAuthorizationOptions(); 
        });
        
        // Registrar o handler de autorização
        services.AddSingleton<IAuthorizationHandler, PrivilegioHandler>();
        
        // Registrar classe para armazenar contexto do usuário logado
        services.AddScoped<UsuarioLogado>();

        return services;
    }
}
