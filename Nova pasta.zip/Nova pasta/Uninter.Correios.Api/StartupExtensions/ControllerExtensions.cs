using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Uninter.Correios.Api.StartupExtensions;

public static class ControllerExtensions
{
    /// <summary>
    /// 
    /// </summary>
    /// <param name="services"></param>
    /// <returns></returns>
    public static IServiceCollection AddController(this IServiceCollection services, IHostEnvironment environment)
    {
        var builder = services.AddControllersWithViews(config =>
        {
            config.Filters.Add(new AuthorizeFilter(new AuthorizationPolicyBuilder().AddRequirements().RequireAuthenticatedUser().Build()));
        })
          .AddJsonOptions(o => o.JsonSerializerOptions.WriteIndented = true);

        // Habilita Razor Runtime Compilation apenas em desenvolvimento
        if (environment.IsDevelopment())
        {
            builder.AddRazorRuntimeCompilation();
        }

        return services;
    }
}
