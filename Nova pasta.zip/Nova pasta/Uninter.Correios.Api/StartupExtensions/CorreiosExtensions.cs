using System;

using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

using Uninter.Core.V5.Log;
using Uninter.Correios.Api.Middleware;
using Uninter.Correios.Domain.Interfaces.Infra;

namespace Uninter.Correios.Api.StartupExtensions;

public static class CorreiosExtensions
{
    /// <summary>
    /// Inicializa o cache de token dos Correios no startup da aplicação
    /// </summary>
    public static WebApplication InicializarCorreiosTokenCache(this WebApplication app)
    {
        using var scope = app.Services.CreateScope();
        
        try
        {
            var tokenCache = scope.ServiceProvider.GetRequiredService<ICorreiosTokenCache>();
            var configuracaoRepository = scope.ServiceProvider.GetRequiredService<ICorreiosConfiguracaoRepository>();
            tokenCache.InicializarAsync(configuracaoRepository).GetAwaiter().GetResult();
            
            Logger.Information("Cache de token dos Correios inicializado com sucesso");
        }
        catch (Exception ex)
        {
            Logger.Warning($"Falha ao inicializar cache de token dos Correios: {ex.Message}");           
        }

        return app;
    }

    /// <summary>
    /// Adiciona middleware para normalizar o header Authorization, incluindo "Bearer" automaticamente
    /// </summary>
    public static WebApplication UseAuthorizationHeaderNormalization(this WebApplication app)
    {
        app.UseMiddleware<AuthorizationHeaderMiddleware>();
        return app;
    }
}
