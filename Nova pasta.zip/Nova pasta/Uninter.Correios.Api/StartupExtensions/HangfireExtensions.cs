﻿using System;

using Hangfire;
using Hangfire.Console;

using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

using Uninter.Correios.Api.Jobs;
using Uninter.Correios.Api.Middleware;
using Uninter.Correios.CrossCutting.Configurations;
using Uninter.Correios.Infra.Configuration;

namespace Uninter.Correios.Api.StartupExtensions;

public static class HangfireExtensions
{
    private const string DashboardUrl = "/hangfire";

    // Job IDs
    private const string JobBaixarArquivosCorreios = "01.baixar-arquivos-correios";
    private const string JobDescompactarArquivos = "02.descompactar-arquivos";
    private const string JobImportarDadosCorreiosFull = "03.importar-dados-correios-full";
    private const string JobEnviarDadosJsonRabbitMQ = "04.enviar-dados-json-rabbitMQ";
    private const string JobVerificacaoTokenCorreios = "06.verificar-token-correios2";

    private const string JobImportacaoCorreiosV2 = "importacao-correios-v2";

    public static IServiceCollection AddHangfire(this IServiceCollection services)
    {
        // VALIDAÇÃO CRÍTICA: Verificar se ConnectionString foi configurada
        if (string.IsNullOrWhiteSpace(DatabaseConfiguration.HangfireConnection))
        {
            var msg = "[ERRO] DatabaseConfiguration.HangfireConnection não foi inicializada! Hangfire não será configurado.";
            Console.WriteLine(msg);
            throw new InvalidOperationException(msg);
        }

        Console.WriteLine($"[HANGFIRE] Inicializando com ConnectionString: {DatabaseConfiguration.HangfireConnection.Substring(0, Math.Min(50, DatabaseConfiguration.HangfireConnection.Length))}...");

        // Registrar os jobs ANTES da configuração do Hangfire
        services.AddTransient<ImportarDadosCorreiosFullJob>();
        services.AddTransient<BaixarArquivosCorreiosJob>();
        services.AddTransient<DescompactarArquivosJob>();
        services.AddTransient<EnviarDadosJsonRabbitMQJob>();
        services.AddTransient<ImportacaoCorreiosV2Job>(); // Orquestrador V2
        services.AddTransient<VerificarTokenCorreiosJob>(); // Verificação de token

        try
        {
            services.AddHangfire((serviceProvider, configuration) => configuration
                .SetDataCompatibilityLevel(CompatibilityLevel.Version_180)
                .UseSimpleAssemblyNameTypeSerializer()
                .UseRecommendedSerializerSettings()
                .UseConsole(new Hangfire.Console.ConsoleOptions
                {
                    // NÃO salvar logs no banco (tabela SET) - apenas exibir no dashboard
                    FollowJobRetentionPolicy = false
                })
                .UseActivator(new Hangfire.AspNetCore.AspNetCoreJobActivator(serviceProvider.GetRequiredService<IServiceScopeFactory>()))
                .UseSqlServerStorage(DatabaseConfiguration.HangfireConnection));

            services.AddHangfireServer(options =>
            {
                options.WorkerCount = 50;
                options.Queues = new[] { "default" };
            });

            Console.WriteLine("[HANGFIRE] Configurado com sucesso!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[ERRO CRÍTICO] Falha ao configurar Hangfire: {ex.Message}");
            Console.WriteLine($"[ERRO] StackTrace: {ex.StackTrace}");
            throw; // Re-throw para impedir inicialização com Hangfire quebrado
        }

        ConfigureGlobalFilters();

        return services;
    }

    public static WebApplication AddHangfireApp(this WebApplication app)
    {
        var logger = app.Services.GetRequiredService<ILogger<WebApplication>>();
        var configuration = app.Configuration;

        try
        {
            logger.LogInformation("[HANGFIRE] Configurando Dashboard em {DashboardUrl}", DashboardUrl);
            ConfigureDashboard(app);

            logger.LogInformation("[HANGFIRE] Configurando Jobs Recorrentes");
            ConfigureRecurringJobs(logger, configuration);

            logger.LogInformation("[HANGFIRE] Inicializado com sucesso!");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "[ERRO CRÍTICO] Falha ao configurar Hangfire Dashboard/Jobs");
            throw;
        }

        return app;
    }

    private static void ConfigureGlobalFilters()
    {
        // Retry: 30min, 1h, 6h, 12h, 24h
        GlobalJobFilters.Filters.Add(new CustomRetryAttribute(30, 60, 360, 720, 1440));
    }

    private static void ConfigureDashboard(WebApplication app)
    {
        app.UseHangfireDashboard(DashboardUrl, new DashboardOptions
        {
            AppPath = DashboardUrl,
            DashboardTitle = "Hangfire Dashboard",
            DarkModeEnabled = true,
            Authorization = new[] { new HangfireBasicAuthFilter() },
            IgnoreAntiforgeryToken = true
        });
    }

    private static void ConfigureRecurringJobs(ILogger logger, IConfiguration configuration)
    {
        try
        {
            const string cronNever = HangfireCronsSettings.CronNunca; // 00:00 no dia 31 de fevereiro => nunca

            // Ler configurações dos workers
            var workersConfig = configuration.GetSection("HangfireWorkers").Get<HangfireWorkersSettings>()
                ?? new HangfireWorkersSettings();
            var crons = workersConfig.Crons ?? new HangfireCronsSettings();

            string CronOuNunca(string c) => string.IsNullOrWhiteSpace(c) ? cronNever : c;

            // Job Orquestrador V2 - Worker Principal
            if (workersConfig.ExibirImportacaoCorreiosV2)
            {
                var cron = CronOuNunca(crons.ImportacaoCorreiosV2);

                RecurringJob.AddOrUpdate<ImportacaoCorreiosV2Job>(
                    JobImportacaoCorreiosV2,
                    job => job.ExecuteAsync(null),
                    cron,
                    new RecurringJobOptions
                    {
                        TimeZone = TimeZoneInfo.Local
                    });

                Uninter.Core.V5.Log.Logger.Information(
                    $"Job recorrente configurado: {JobImportacaoCorreiosV2} - Cron '{cron}' - ORQUESTRADOR V2 (WORKER PRINCIPAL)");
            }

            if (workersConfig.ExibirImportarFull)
            {
                var cron = CronOuNunca(crons.ImportarFull);
                RecurringJob.AddOrUpdate<ImportarDadosCorreiosFullJob>(
                    JobImportarDadosCorreiosFull,
                    job => job.ExecuteAsync(null),
                    cron,
                    new RecurringJobOptions
                    {
                        TimeZone = TimeZoneInfo.Local
                    });

                Core.V5.Log.Logger.Information(
                    $"Job recorrente configurado: {JobImportarDadosCorreiosFull} - Cron '{cron}'");
            }

            if (workersConfig.ExibirBaixarArquivos)
            {
                var cron = CronOuNunca(crons.BaixarArquivos);
                RecurringJob.AddOrUpdate<BaixarArquivosCorreiosJob>(
                    JobBaixarArquivosCorreios,
                    job => job.ExecuteAsync(null),
                    cron,
                    new RecurringJobOptions
                    {
                        TimeZone = TimeZoneInfo.Local
                    });

                Core.V5.Log.Logger.Information(
                    $"Job recorrente configurado: {JobBaixarArquivosCorreios} - Cron '{cron}'");
            }

            if (workersConfig.ExibirDescompactar)
            {
                var cron = CronOuNunca(crons.Descompactar);
                RecurringJob.AddOrUpdate<DescompactarArquivosJob>(
                    JobDescompactarArquivos,
                    job => job.ExecuteAsync(null),
                    cron,
                    new RecurringJobOptions
                    {
                        TimeZone = TimeZoneInfo.Local
                    });

                Core.V5.Log.Logger.Information(
                   $"Job recorrente configurado: {JobDescompactarArquivos} - Cron '{cron}'");
            }

            if (workersConfig.ExibirEnviarRabbitMQ)
            {
                var cron = CronOuNunca(crons.EnviarRabbitMQ);
                RecurringJob.AddOrUpdate<EnviarDadosJsonRabbitMQJob>(
                    JobEnviarDadosJsonRabbitMQ,
                    job => job.ExecuteAsync(null),
                    cron,
                    new RecurringJobOptions
                    {
                        TimeZone = TimeZoneInfo.Local
                    });

                Core.V5.Log.Logger.Information(
                   $"Job recorrente configurado: {JobEnviarDadosJsonRabbitMQ} - Cron '{cron}'");
            }

            logger.LogInformation("Configuração dos workers concluída. Worker principal (V2): {Status}",
                workersConfig.ExibirImportacaoCorreiosV2 ? "ATIVO" : "DESATIVADO");

            if (workersConfig.ExibirVerificacaoToken)
            {
                var cronVerificarToken = CronOuNunca(crons.VerificacaoToken);

                RecurringJob.AddOrUpdate<VerificarTokenCorreiosJob>(
                    JobVerificacaoTokenCorreios,
                    job => job.ExecuteAsync(null),
                    cronVerificarToken,
                    new RecurringJobOptions
                    {
                        TimeZone = TimeZoneInfo.Local
                    });

                Core.V5.Log.Logger.Information(
                   $"Job recorrente configurado: {JobVerificacaoTokenCorreios} - Cron '{cronVerificarToken}' - VERIFICAR TOKEN");
            }

            logger.LogInformation("Job de verificação de token configurado e ativo");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Erro ao configurar jobs recorrentes");
            throw;
        }
    }
}
