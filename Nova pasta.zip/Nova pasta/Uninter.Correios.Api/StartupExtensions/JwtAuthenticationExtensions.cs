using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;

namespace Uninter.Correios.Api.StartupExtensions;

public static class JwtAuthenticationExtensions
{
    public static IServiceCollection AddJwtAuthentication(this IServiceCollection services, IHostEnvironment environment)
    {
        services.AddAuthentication(options =>
        {
            options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        })
        .AddJwtBearer(options =>
        {
            options.RequireHttpsMetadata = !environment.IsDevelopment();
            options.SaveToken = true;

            options.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = false,
                ValidateIssuer = false,
                ValidateAudience = false,
                ValidateLifetime = false,
                RequireExpirationTime = false,
                RequireSignedTokens = false,

                // Define qual claim será usado para Identity.Name
                // Tenta os claims mais comuns em ordem: unique_name, name, sub
                NameClaimType = "unique_name", // Padrão do ASP.NET Core Identity
                
                SignatureValidator = (token, parameters) =>
                {
                    var jwt = new System.IdentityModel.Tokens.Jwt.JwtSecurityToken(token);
                    return jwt;
                }
            };

            options.Events = new JwtBearerEvents
            {
                OnMessageReceived = context =>
                {
                    var authorization = context.Request.Headers.Authorization.ToString();

                    if (!string.IsNullOrEmpty(authorization))
                    {
                        // Remove "Bearer " se existir (case-insensitive: bearer, Bearer, BEARER, etc.)
                        if (authorization.StartsWith("Bearer ", System.StringComparison.OrdinalIgnoreCase))
                        {
                            context.Token = authorization.Substring(7).Trim(); // Remove "Bearer " (7 caracteres)
                        }
                        else
                        {
                            // Token enviado sem o prefixo "Bearer "
                            context.Token = authorization.Trim();
                        }
                    }

                    return System.Threading.Tasks.Task.CompletedTask;
                },
                OnAuthenticationFailed = context =>
                {
                    var logger = context.HttpContext.RequestServices.GetService<Microsoft.Extensions.Logging.ILogger<Program>>();
                    logger?.LogError($"Token authentication failed: {context.Exception.Message}");
                    return System.Threading.Tasks.Task.CompletedTask;
                },
                OnTokenValidated = context =>
                {
                    var logger = context.HttpContext.RequestServices.GetService<Microsoft.Extensions.Logging.ILogger<Program>>();
                    
                    // Obter o principal do token
                    var claimsIdentity = context.Principal?.Identity as System.Security.Claims.ClaimsIdentity;
                    
                    if (claimsIdentity != null)
                    {
                        // Log de todos os claims para debug
                        logger?.LogInformation("Claims do token:");
                        foreach (var claim in claimsIdentity.Claims)
                        {
                            var claimType = claim.Type?.Replace("\r", "").Replace("\n", "");
                            var claimValue = claim.Value?.Replace("\r", "").Replace("\n", "");
                            logger?.LogInformation("  - {ClaimType}: {ClaimValue}", claimType, claimValue);
                        }
                        
                        // Verificar se o Identity.Name está setado
                        var identityName = context.Principal?.Identity?.Name;
                        var identityNameLog = (identityName ?? "(null)").Replace("\r", "").Replace("\n", "");
                        logger?.LogInformation("Identity.Name = {IdentityName}", identityNameLog);
                        
                        // Se Identity.Name estiver null, tentar obter de outros claims comuns
                        if (string.IsNullOrEmpty(identityName))
                        {
                            // Tentar: unique_name -> name -> sub -> preferred_username
                            var nameClaim = claimsIdentity.FindFirst("unique_name") 
                                ?? claimsIdentity.FindFirst("name")
                                ?? claimsIdentity.FindFirst("sub")
                                ?? claimsIdentity.FindFirst("preferred_username")
                                ?? claimsIdentity.FindFirst(System.Security.Claims.ClaimTypes.Name)
                                ?? claimsIdentity.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier);
                            
                            if (nameClaim != null)
                            {
                                // Adicionar um claim do tipo Name (ClaimTypes.Name) se não existir
                                if (claimsIdentity.FindFirst(System.Security.Claims.ClaimTypes.Name) == null)
                                {
                                    claimsIdentity.AddClaim(new System.Security.Claims.Claim(
                                        System.Security.Claims.ClaimTypes.Name, 
                                        nameClaim.Value));
                                    
                                    var nameClaimValueLog = nameClaim.Value?.Replace("\r", "").Replace("\n", "");
                                    logger?.LogInformation("Claim 'Name' adicionado com valor: {NameClaimValue}", nameClaimValueLog);
                                }
                            }
                            else
                            {
                                logger?.LogWarning("Nenhum claim de nome de usuário encontrado no token!");
                            }
                        }
                    }
                    
                    logger?.LogInformation("Token validated successfully");
                    return System.Threading.Tasks.Task.CompletedTask;
                },
                OnChallenge = context =>
                {
                    var logger = context.HttpContext.RequestServices.GetService<Microsoft.Extensions.Logging.ILogger<Program>>();
                    var errorLog = context.Error?.Replace("\r", "").Replace("\n", "");
                    var descriptionLog = context.ErrorDescription?.Replace("\r", "").Replace("\n", "");
                    logger?.LogWarning("Authentication challenge: {Error}, {Description}", errorLog, descriptionLog);
                    return System.Threading.Tasks.Task.CompletedTask;
                }
            };
        });

        return services;
    }
}
