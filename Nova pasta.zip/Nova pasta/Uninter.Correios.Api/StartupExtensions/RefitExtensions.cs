using System;
using System.Net;
using System.Net.Http;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;

using Microsoft.Extensions.DependencyInjection;

using Refit;

using Uninter.Correios.CrossCutting;
using Uninter.Correios.CrossCutting.Configurations;
using Uninter.Correios.Domain.Handlers.Token;
using Uninter.Correios.Domain.Interfaces.Api;

namespace Uninter.Correios.Api.StartupExtensions;

public static class RefitExtensions
{
    public static IServiceCollection AddRefitClients(this IServiceCollection services, AppSettings appSettings)
    {
        var timeoutSeconds = appSettings.HttpClientTimeoutSeconds > 0 
            ? appSettings.HttpClientTimeoutSeconds 
            : 30; // Fallback para 30 segundos
        
        var timeout = TimeSpan.FromSeconds(timeoutSeconds);
        
        services.AddRefit<ITokenApi>(appSettings.TokenApiUrl, timeout);
        services.AddRefitWithHandler<INotificacoesApi, TokenApiHeaderHandler>(appSettings.NotificacoesApiUrl, timeout);
        services.AddRefit<IAccountApi>(appSettings.AccountApiUrl, timeout);

        // ICorreiosApi usa o handler padrão do sistema sem restrições de SSL personalizadas,
        // pois api.correios.com.br pode falhar com CheckCertificateRevocationList=true
        // ou com SslProtocols restrito a TLS 1.2.
        services
            .AddRefitClient<ICorreiosApi>()
            .ConfigureHttpClient(options =>
            {
                options.BaseAddress = new Uri(appSettings.CorreiosIntegracao.BaseUrl);
                options.Timeout = timeout;
                options.DefaultRequestHeaders.ConnectionClose = false;
            });

        return services;
    }

    private static IServiceCollection AddRefit<T>(this IServiceCollection services, string url, TimeSpan timeout) where T : class
    {
        services
            .AddRefitClient<T>()
            .ConfigureHttpClient((options) =>
            {
                options.BaseAddress = new Uri(url);
                options.Timeout = timeout;
                // Remover ConnectionClose para reutilizar conexões (mais rápido)
                options.DefaultRequestHeaders.ConnectionClose = false;
            })
            .ConfigurePrimaryHttpMessageHandler(_ => GetHandler());

        return services;
    }

    private static IServiceCollection AddRefitWithHandler<T1, THandler>(this IServiceCollection services, string url, TimeSpan timeout)
        where T1 : class
        where THandler : DelegatingHandler
    {
        services
            .AddRefitClient<T1>()
            .ConfigureHttpClient((options) =>
            {
                options.BaseAddress = new Uri(url);
                options.Timeout = timeout;
                // Remover ConnectionClose para reutilizar conexões (mais rápido)
                options.DefaultRequestHeaders.ConnectionClose = false;
            })
            .ConfigurePrimaryHttpMessageHandler(_ => GetHandler())
            .AddHttpMessageHandler<THandler>();

        return services;
    }


    private static HttpClientHandler GetHandler(params Certificado[] certificados)
    {
        // exemplo de carga de certificado, caso seja necess�rio para autentica��o m�tua

        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

        var httpClientHandler = new HttpClientHandler
        {
            SslProtocols = SslProtocols.Tls12,
            // Desabilitar CRL check para evitar lentidão em redes corporativas
            // CRL check pode adicionar 10-30 segundos de latência ou falhar completamente
            CheckCertificateRevocationList = false,
            // Configurações para melhor performance
            UseProxy = false,
            MaxConnectionsPerServer = 10
        };

        if (certificados != null && certificados.Length != 0)
        {
            foreach (var certificado in certificados)
            {
                httpClientHandler.ClientCertificates.Add(X509CertificateLoader.LoadPkcs12FromFile(
                        certificado.Path,
                        certificado.Password,
                        X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.MachineKeySet
                    ));
            }
        }

        return httpClientHandler;
    }
}
