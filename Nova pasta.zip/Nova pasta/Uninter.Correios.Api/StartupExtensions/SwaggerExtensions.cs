using System;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;

namespace Uninter.Correios.Api.StartupExtensions;

public static class SwaggerExtensions
{
    public static IServiceCollection AddSwagger(this IServiceCollection services, IWebHostEnvironment enviroment)
    {
        services.AddSwaggerGen(c =>
        {
            c.SwaggerDoc("v1", new OpenApiInfo
            {
                Title = $"Template API {enviroment.EnvironmentName}",
                Version = "v1",
                Description = "Template"
            });

            c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
            {
                In = ParameterLocation.Header,
                Description = "Insira o Bearer Token",
                Name = "Authorization",
                Type = SecuritySchemeType.ApiKey,
                Scheme = "Bearer"
            });

            c.AddSecurityRequirement(new OpenApiSecurityRequirement
            {
                {
                    new OpenApiSecurityScheme
                    {
                        Reference = new OpenApiReference
                        {
                            Type = ReferenceType.SecurityScheme,
                            Id = "Bearer"
                        }
                    },
                    Array.Empty<string>()
                }
            });

            c.IncludeXmlComments(string.Format(@"{0}\Swagger.xml", AppDomain.CurrentDomain.BaseDirectory));

        }); // Enable Swagger on Application on /Swagger

        return services;
    }

    public static WebApplication AddSwaggerApp(this WebApplication app)
    {
        if (!app.Environment.IsProduction())
        {
            app.UseDeveloperExceptionPage();
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Uninter.Correios.Api");
                c.InjectStylesheet("/swagger-ui/custom.css");
                c.InjectJavascript("/swagger-js/custom.js");
                c.DocumentTitle = $"Uninter.Correios.Api {app.Environment.EnvironmentName}";
            });
        }

        return app;
    }
}
