(function () {
    window.addEventListener("load", function () {
        setTimeout(function () {
            var linkIcon = document.createElement('link');
            linkIcon.type = 'image/png';
            linkIcon.rel = 'icon';
            linkIcon.href = '/swagger-ui/resources/favicon.ico';
            document.getElementsByTagName('head')[0].appendChild(linkIcon);
        });
    });
})();
