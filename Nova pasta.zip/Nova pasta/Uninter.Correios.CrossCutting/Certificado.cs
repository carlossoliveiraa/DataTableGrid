using System;
using System.Security.Cryptography.X509Certificates;

namespace Uninter.Correios.CrossCutting;

public class Certificado
{
    public string Path { get; set; }

    public string Password { get; set; }

    public X509Certificate2 X509Certificate2 { get; private set; }

    public void LoadCertificate()
    {
        if (X509Certificate2 != null)
            return;

        if (string.IsNullOrWhiteSpace(Path))
            throw new ArgumentException("Path precisa estar definido antes de carregar o certificado.");

        if (string.IsNullOrWhiteSpace(Password))
            throw new ArgumentException("Password precisa estar definido antes de carregar o certificado.");

        X509Certificate2 = X509CertificateLoader.LoadPkcs12FromFile(Path, Password, X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.MachineKeySet);
    }
}
