namespace Uninter.Correios.CrossCutting.Configurations;

/// <summary>
/// Configurações gerais da aplicação mapeadas do appsettings.json.
/// </summary>
public class AppSettings
{
    // Identificação da aplicação
    public string AplicacaoNome { get; set; }
    public string Ambiente { get; set; }
    public string EmailDEVQA { get; set; }

    // Caminhos de arquivos locais
    public string CaminhoProcessarArquivos { get; set; }
    public string CaminhoJson { get; set; }
    public string CaminhoArquivosZipados { get; set; }
    public string EnderecoArquivoCorreiosZip { get; set; }

    // Nomes de arquivos/subpastas usados na importação dos Correios
    public CorreiosArquivosSettings CorreiosArquivos { get; set; } = new();

    // URLs das APIs externas da Uninter
    public string NotificacoesApiUrl { get; set; }
    public string TokenApiUrl { get; set; }
    public string AccountApiUrl { get; set; }
    
    // Configurações de timeout (em segundos) para chamadas HTTP
    public int HttpClientTimeoutSeconds { get; set; } = 30;

    // Integração com os Correios (URL base + credenciais OAuth)
    public CorreiosIntegrationSettings CorreiosIntegracao { get; set; }

    // Controle dos workers do Hangfire
    public HangfireWorkersSettings HangfireWorkers { get; set; }

    // Notificações por email
    public EmailNotificationSettings EmailNotificationSettings { get; set; }
}
