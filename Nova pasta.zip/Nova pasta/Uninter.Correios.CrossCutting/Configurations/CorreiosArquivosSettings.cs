namespace Uninter.Correios.CrossCutting.Configurations;

/// <summary>
/// Nomes de arquivos e subpastas usadas durante o processo de importação dos Correios.
/// Todos os caminhos são relativos a <c>CaminhoProcessarArquivos</c>.
/// Os valores default refletem o que o sistema usava antes (chumbado em código).
/// </summary>
public class CorreiosArquivosSettings
{
    /// <summary>Nome do arquivo ZIP baixado dos Correios (ex.: eDNE_Basico.zip).</summary>
    public string NomeArquivoZip { get; set; } = "eDNE_Basico.zip";

    /// <summary>Timeout (em horas) para o download do arquivo dos Correios.</summary>
    public int DownloadTimeoutHoras { get; set; } = 2;

    /// <summary>Subpasta onde fica o ZIP baixado.</summary>
    public string PastaArquivosZipados { get; set; } = "ArquivoZipado";

    /// <summary>Subpasta de backup (usada dentro de <see cref="PastaArquivosZipados"/> e <see cref="PastaEntrada"/>).</summary>
    public string PastaBackup { get; set; } = "bkp";

    /// <summary>Subpasta onde os arquivos descompactados ficam.</summary>
    public string PastaEntrada { get; set; } = "Entrada";

    /// <summary>Subpasta de arquivos processados pela importação.</summary>
    public string PastaProcessado { get; set; } = "Processado";

    /// <summary>Subpasta de arquivos com erro durante a importação.</summary>
    public string PastaErro { get; set; } = "Erro";

    /// <summary>Subpasta onde os JSONs gerados são salvos.</summary>
    public string PastaJson { get; set; } = "Json";

    /// <summary>Subpasta para onde os JSONs são movidos após publicação no RabbitMQ.</summary>
    public string PastaJsonProcessado { get; set; } = "jsonProcessado";

    /// <summary>Pasta destino dos arquivos FULL após descompactação (dentro de <see cref="PastaEntrada"/>).</summary>
    public string PastaDescompactacaoFull { get; set; } = "eDNE_Basico_FULL";

    /// <summary>Pasta destino dos arquivos DELTA após descompactação (dentro de <see cref="PastaEntrada"/>).</summary>
    public string PastaDescompactacaoDelta { get; set; } = "eDNE_DELTA";

    /// <summary>Pasta usada pelo importador FULL.</summary>
    public string PastaImportacaoFull { get; set; } = "eDNE_Basico_FULL";

    /// <summary>Pasta usada pelo importador DELTA.</summary>
    public string PastaImportacaoDelta { get; set; } = "eDNE_Basico_Delta";

    /// <summary>Estimativa de registros usada pelo job de orquestração para notificações.</summary>
    public int EstimativaRegistrosImportados { get; set; } = 150000;
}
