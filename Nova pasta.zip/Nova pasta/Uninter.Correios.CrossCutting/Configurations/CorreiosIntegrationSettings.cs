namespace Uninter.Correios.CrossCutting.Configurations;

/// <summary>
/// Configurações completas da integração com a API dos Correios:
/// endereço base e credenciais OAuth necessárias para autenticação.
/// </summary>
public class CorreiosIntegrationSettings
{
    public string BaseUrl { get; set; }

    public string UserName { get; set; }

    public string ClientId { get; set; }

    public string ClientSecret { get; set; }

    public string GrantType { get; set; }

    public string Password { get; set; }
}
