namespace Uninter.Correios.CrossCutting.Configurations;

/// <summary>
/// Template HTML usado no envio de e-mail de fallback (rota /texto/add) quando o
/// template personalizado configurado na API de Notificações não está disponível.
/// </summary>
public static class EmailFallbackTemplate
{
    public const string AssuntoToken = "@Assunto";
    public const string ConteudoToken = "@Conteudo";

    public const string Html = @"<table width=""100%"" height=""100%"" align=""center"" bgcolor=""#eeebeb"" style=""padding:0;margin:0;background:#eeebeb;-webkit-text-size-adjust:none;-webkit-font-smoothing:antialiased;color:#6f6f6f;"">
  <tr>
    <td align=""center"" valign=""top"" style=""font-family:Arial,sans-serif;color:#6f6f6f;"">
      <table width=""600"" align=""center"">
        <tr>
          <td align=""center"">
            <!-- HEADER -->
            <table width=""100%"" bgcolor=""#002e5e"">
              <tr><td style=""font-size:15px;""></td></tr>
              <tr>
                <td style=""text-align:center;padding:15px 0;"">
                  <img src=""https://coreweblibraries.uninter.com/Styles/images/mail/logo_uninter-hor-b_t.png"" width=""175"" height=""40"" alt=""topo com logo"" border=""0"">
                </td>
              </tr>
              <tr>
                <td style=""font-size:10px;"">&nbsp;</td>
              </tr>
            </table>
            <!-- CONTEÚDO -->
            <table width=""100%"" bgcolor=""#ffffff"">
              <tr>
                <td style=""padding-top:15px;background:#ffffff;"">
                  <table width=""90%"" align=""center"">
                    <tr>
                      <td style=""text-align:left;color:#002e5e;font-size:23px;font-weight:400;"">
                        <p>Prezado Gestor,</p>
                      </td>
                    </tr>
                  </table>
                  <table width=""90%"" align=""center"">
                    <tr>
                      <td style=""text-align:left;color:#002e5e;font-size:20px;font-weight:600;padding-bottom:10px;"">
                        <p>@Assunto</p>
                      </td>
                    </tr>
                  </table>
                  <table width=""90%"" align=""center"">
                    <tr>
                      <td style=""text-align:left;color:#002e5e;font-size:18px;font-weight:400;white-space:pre-line;"">
                        <p>@Conteudo</p>
                      </td>
                    </tr>
                  </table>
                  <table width=""90%"" align=""center"">
                    <tr><td style=""font-size:10px;"">&nbsp;</td></tr>
                  </table>
                  <table width=""90%"" align=""center"">
                    <tr>
                      <td style=""text-align:right;color:#002e5e;font-size:18px;font-weight:400;"">
                        <p><strong>Suporte Técnico</strong></p>
                      </td>
                    </tr>
                  </table>
                  <br><br>
                  <!-- RODAPÉ -->
                  <table width=""100%"" bgcolor=""#363636"">
                    <tr><td style=""font-size:15px;""></td></tr>
                    <tr>
                      <td style=""color:#f0f0f0;font-size:14px;text-align:center;padding:4px 0;"">
                        <strong>© 2026 Uninter - Centro Universitário Internacional</strong>
                      </td>
                    </tr>
                    <tr>
                      <td style=""color:#f0f0f0;font-size:14px;text-align:center;padding-bottom:10px;"">
                        Este é um e-mail automático, por favor não responda.
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>";

    /// <summary>
    /// Aplica as substituições de <c>@Assunto</c> e <c>@Conteudo</c> ao template HTML.
    /// </summary>
    public static string Render(string assunto, string conteudo)
    {
        return Html
            .Replace(AssuntoToken, assunto ?? string.Empty)
            .Replace(ConteudoToken, conteudo ?? string.Empty);
    }
}
