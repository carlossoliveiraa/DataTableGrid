namespace Uninter.Correios.CrossCutting.Configurations;

/// <summary>
/// Configurações de notificação por email.
/// Cada tipo de evento usa o seu próprio template registrado na ferramenta de notificações,
/// recebendo as variáveis específicas documentadas em EmailTemplates/README.md.
/// </summary>
public class EmailNotificationSettings
{
    /// <summary>
    /// Endereço do remetente das notificações.
    /// </summary>
    public string Remetente { get; set; }

    /// <summary>
    /// Nome do template registrado para notificações de nova importação bem-sucedida.
    /// Variáveis esperadas: @DataImportacao, @NomeArquivo, @QuantidadeRegistros,
    /// @TempoProcessamento, @Ambiente.
    /// </summary>
    public string TemplateNovaImportacao { get; set; } = "Uninter.Correios.NovaImportacao";

    /// <summary>
    /// Nome do template registrado para notificações de falha de execução.
    /// Variáveis esperadas: @DataFalha, @NomeArquivo, @MensagemErro, @StackTrace, @Ambiente.
    /// </summary>
    public string TemplateFalhaExecucao { get; set; } = "Uninter.Correios.FalhaExecucao";

    /// <summary>
    /// Nome do template registrado para notificações de token próximo da expiração.
    /// Variáveis esperadas: @DiasRestantes, @DataExpiracao, @Ambiente.
    /// </summary>
    public string TemplateTokenExpiracao { get; set; } = "Uninter.Correios.TokenExpiracaoNormal";

    /// <summary>
    /// Habilita/desabilita globalmente o envio de notificações por email.
    /// </summary>
    public bool Habilitado { get; set; } = true;

    /// <summary>
    /// Lista de destinatários separados por vírgula ou ponto-e-vírgula.
    /// </summary>
    public string Destinatarios { get; set; }

    /// <summary>
    /// Dias de antecedência para alertar sobre a expiração do token dos Correios.
    /// </summary>
    public int DiasAntecedenciaTokenExpiracao { get; set; } = 15;
}
