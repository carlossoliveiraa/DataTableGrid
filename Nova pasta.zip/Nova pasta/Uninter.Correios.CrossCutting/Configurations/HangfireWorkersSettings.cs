namespace Uninter.Correios.CrossCutting.Configurations;

public class HangfireWorkersSettings
{
    public bool ExibirImportacaoCorreiosV2 { get; set; } = true;
    public bool ExibirBaixarArquivos { get; set; } = false;
    public bool ExibirDescompactar { get; set; } = false;
    public bool ExibirImportarFull { get; set; } = false;
    public bool ExibirImportarDelta { get; set; } = false;
    public bool ExibirEnviarRabbitMQ { get; set; } = false;
    public bool ExibirVerificacaoToken { get; set; } = false;

    /// <summary>
    /// Cron expressions de cada job. Quando vazio/nulo é usado o cron "nunca" (0 0 31 2 *).
    /// Exemplos:
    ///   "0 10 * * *"  -> todos os dias às 10h
    ///   "0 8  * * *"  -> todos os dias às 8h
    ///   "0 8  * * 1-5"-> de segunda a sexta às 8h
    ///   "0 */6 * * *" -> a cada 6 horas
    ///   "0 0 31 2 *"  -> nunca (dia 31 de fevereiro)
    /// </summary>
    public HangfireCronsSettings Crons { get; set; } = new();
}

public class HangfireCronsSettings
{
    /// <summary>Cron "nunca" usado como default em todos os jobs.</summary>
    public const string CronNunca = "0 0 31 2 *";

    public string ImportacaoCorreiosV2 { get; set; } = CronNunca;
    public string VerificacaoToken { get; set; } = CronNunca;
    public string ImportarFull { get; set; } = CronNunca;
    public string ImportarDelta { get; set; } = CronNunca;
    public string BaixarArquivos { get; set; } = CronNunca;
    public string Descompactar { get; set; } = CronNunca;
    public string EnviarRabbitMQ { get; set; } = CronNunca;
}
