namespace Uninter.Correios.CrossCutting.Constants;

/// <summary>
/// Constantes utilizadas no projeto de integração com os Correios.
/// </summary>
public static class CorreiosConstants
{
    /// <summary>
    /// Tamanho esperado do CEP (sem formatação).
    /// </summary>
    public const int CEP_LENGTH = 8;

    /// <summary>
    /// Tamanho máximo de itens por página nas consultas.
    /// </summary>
    public const int MAX_PAGE_SIZE = 50;

    /// <summary>
    /// Quantidade de dias para alertar sobre expiração de token.
    /// </summary>
    public const int TOKEN_EXPIRATION_WARNING_DAYS = 7;

    /// <summary>
    /// Prefixo do token Bearer para autenticação.
    /// </summary>
    public const string BEARER_PREFIX = "Bearer ";

    /// <summary>
    /// Mensagens de erro padrão.
    /// </summary>
    public static class ErrorMessages
    {
        public const string CEP_INVALIDO = "CEP inválido. Deve conter exatamente 8 dígitos numéricos.";
        public const string CEP_NAO_ENCONTRADO = "CEP não encontrado. Verifique se o CEP informado está correto e tente novamente.";
        public const string TOKEN_NAO_ENCONTRADO = "Token de autenticação dos Correios não encontrado ou expirado. Entre em contato com o administrador do sistema.";
        public const string PARAMETROS_BUSCA_INVALIDOS = "Para buscar endereços, informe obrigatoriamente a UF e a Localidade (cidade).";
        public const string UF_OBRIGATORIA = "A UF (Unidade Federativa) é obrigatória para consulta de endereços.";
        public const string UF_OBRIGATORIA_COM_LOGRADOURO = "UF é obrigatória quando Logradouro é informado.";
        public const string UF_OBRIGATORIA_COM_BAIRRO = "UF é obrigatória quando Bairro é informado.";
        public const string LOCALIDADE_OBRIGATORIA = "A Localidade (cidade) é obrigatória para consulta de endereços.";
        public const string LOCALIDADE_OBRIGATORIA_COM_BAIRRO = "Localidade é obrigatória quando Bairro é informado.";
        public const string UF_INVALIDA = "A UF deve conter exatamente 2 letras (ex: SP, RJ, MG).";
        public const string LOGRADOURO_COM_NUMEROS = "O campo 'logradouro' não deve conter números. Informe apenas o nome da rua/avenida.";
        public const string LOGRADOURO_COM_VIRGULAS = "O campo 'logradouro' não deve conter vírgulas ou números. Informe apenas o nome da rua/avenida.";
    }
}
