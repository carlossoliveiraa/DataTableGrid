using System;

namespace Uninter.Correios.CrossCutting.Contract;

public interface IAppLogger  
{
    void Information(string message, string? payload = null);
    void Warning(string message, string? payload = null, string? contractNotifications = null);
    void Error(string message, Exception exception, string? payload = null);
}
