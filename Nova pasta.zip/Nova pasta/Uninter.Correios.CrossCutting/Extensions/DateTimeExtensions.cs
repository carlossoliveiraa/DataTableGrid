using System;

namespace Uninter.Correios.CrossCutting.Extensions;

public static class DateTimeExtensions
{
    /// <summary>
    /// Verifica se a data já passou (está expirada).
    /// </summary>
    public static bool IsExpired(this DateTime dateTime)
    {
        return DateTime.UtcNow > dateTime;
    }

    /// <summary>
    /// Retorna quantos dias faltam até a data especificada.
    /// </summary>LogradouroHelper
    public static int DaysUntil(this DateTime dateTime)
    {
        return (dateTime - DateTime.UtcNow).Days;
    }

    /// <summary>
    /// Verifica se a data está próxima de expirar dentro do período especificado.
    /// </summary>
    public static bool IsExpiringWithin(this DateTime dateTime, int days)
    {
        var daysUntil = dateTime.DaysUntil();
        return daysUntil <= days && daysUntil > 0;
    }

    /// <summary>
    /// Converte DateTime para timestamp Unix.
    /// </summary>
    public static long ToUnixTimestamp(this DateTime dateTime)
    {
        var epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        return (long)(dateTime.ToUniversalTime() - epoch).TotalSeconds;
    }

    /// <summary>
    /// Converte timestamp Unix para DateTime.
    /// </summary>
    public static DateTime FromUnixTimestamp(this long timestamp)
    {
        var epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        return epoch.AddSeconds(timestamp);
    }

    /// <summary>
    /// Formata data no padrão brasileiro (dd/MM/yyyy).
    /// </summary>
    public static string ToDataBrasileira(this DateTime dateTime)
    {
        return dateTime.ToString("dd/MM/yyyy");
    }

    /// <summary>
    /// Formata data e hora no padrão brasileiro (dd/MM/yyyy HH:mm:ss).
    /// </summary>
    public static string ToDataHoraBrasileira(this DateTime dateTime)
    {
        return dateTime.ToString("dd/MM/yyyy HH:mm:ss");
    }
}
