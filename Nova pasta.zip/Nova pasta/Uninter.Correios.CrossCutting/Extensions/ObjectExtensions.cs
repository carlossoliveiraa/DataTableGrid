using System;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Xml;
using System.Xml.Serialization;

namespace Uninter.Correios.CrossCutting.Extensions;

public static class ObjectExtensions
{
    public static bool In<T>(this T obj, params T[] args)
    {
        return args.Contains(obj);
    }

    public static bool NotIn<T>(this T obj, params T[] args)
    {
        return !args.Contains(obj);
    }

    /// <summary>
    /// Serializa um objeto para JSON usando System.Text.Json.
    /// </summary>
    /// <remarks>
    /// Este método utiliza o System.Text.Json, que foi escolhido por seu melhor desempenho e integração nativa com o .NET.
    /// Ele substitui o uso do Newtonsoft.Json, reduzindo dependências externas e melhorando a eficiência.
    /// </remarks>
    /// <param name="obj">Objeto a ser serializado.</param>
    /// <returns>Representação JSON do objeto.</returns>
    public static string ToJson(this object obj)
    {
        return JsonSerializer.Serialize(obj, obj?.GetType() ?? typeof(object), JsonOptions());
    }

    public static string ToXml<T>(this T value)
    {
        if (Equals(value, default(T)))
            return string.Empty;

        var xmlserializer = new XmlSerializer(typeof(T));
        var settings = new XmlWriterSettings
        {
            Encoding = new UTF8Encoding(false), // false to omit the BOM
            Indent = true,
            OmitXmlDeclaration = false
        };

        using var stringWriter = new Utf8StringWriter();
        using var writer = XmlWriter.Create(stringWriter, settings);
        xmlserializer.Serialize(writer, value);
        return stringWriter.ToString();
    }

    public static T ToObject<T>(this string payload)
    {
        if (string.IsNullOrEmpty(payload))
            throw new ValidationException($"Erro ao converter para objeto {typeof(T)}: Payload nulo ou em branco");

        if (IsJson(payload))
        {
            return JsonSerializer.Deserialize<T>(payload, JsonOptions());
        }
        else if (IsXml(payload))
        {
            payload = payload.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
            payload = payload.Replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>", "");
            payload = payload.Replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
            using var stringReader = new StringReader(payload);
            var serializer = new XmlSerializer(typeof(T));
            return (T)serializer.Deserialize(stringReader);
        }
        else
        {
            throw new ValidationException("Payload n�o � um JSON ou XML v�lido. payload: " + payload);
        }
    }

    private static bool IsJson(string input)
    {
        input = input.Trim();
        return input.StartsWith('{') && input.EndsWith('}') || // object
               input.StartsWith('[') && input.EndsWith(']');   // array
    }

    private static bool IsXml(string input)
    {
        try
        {
            XmlDocument xmlDoc = new() { XmlResolver = null };
            xmlDoc.LoadXml(input);
            return true;
        }
        catch (XmlException)
        {
            return false;
        }
    }

    public static T Clone<T>(this T obj)
    {
        if (Equals(obj, default(T))) return default;

        return obj.ToJson().ToObject<T>();
    }

    public static string GetCacheKey(this object obj)
    {
        if (obj == null) throw new ValidationException("N�o � possivel gerar Chave de cache para obj nullo");
        var type = obj.GetType();
        var nameAndValue = string.Join('.', type.GetProperties().Select(x => x.Name + "=" + (x.GetValue(obj) ?? "null")));
        return $"{type.FullName}.{nameAndValue}";
    }

    private static JsonSerializerOptions JsonOptions()
    {
        return new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            WriteIndented = false
        };
    }
}

public class Utf8StringWriter : StringWriter
{
    public override Encoding Encoding => new UTF8Encoding(false); // false to omit the BOM
}
