using System;
using System.Linq;
using System.Text;
using System.Text.Json;

namespace Uninter.Correios.CrossCutting.Extensions;

public static class StringExtensions
{
    public static string NormalizeWhiteSpace(this string str)
    {
        var s = str.Trim();
        var iswhite = false;
        var sLength = s.Length;
        var sb = new StringBuilder(sLength);
        foreach (var c in s)
        {
            if (!char.IsWhiteSpace(c))
            {
                sb.Append(c);
                iswhite = false;
            }
            else
            {
                if (!iswhite)
                {
                    sb.Append(' ');
                    iswhite = true;
                }
            }
        }
        return sb.ToString();
    }

    public static string CleanTokenValue(this string? token)
    {
        if (string.IsNullOrWhiteSpace(token))
        {
            throw new ArgumentException("Token de autenticação dos Correios não foi informado.", nameof(token));
        }

        var cleaned = token.Trim().Trim('"', '\'');

        if (cleaned.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
        {
            cleaned = cleaned.Substring(7);
        }

        cleaned = cleaned.Replace("\"", string.Empty)
                         .Replace("'", string.Empty);

        cleaned = string.Concat(cleaned.Where(c => !char.IsWhiteSpace(c)));

        if (string.IsNullOrWhiteSpace(cleaned))
        {
            throw new ArgumentException("Token de autenticação dos Correios está vazio ou inválido após saneamento.", nameof(token));
        }

        return cleaned;
    }

    public static string NormalizeBearerToken(this string? token)
    {
        return $"Bearer {token.CleanTokenValue()}";
    }

    public static DateTime? TryGetJwtExpiration(this string? token)
    {
        try
        {
            var cleaned = token.CleanTokenValue();
            var parts = cleaned.Split('.');

            if (parts.Length != 3)
            {
                return null;
            }

            var payload = parts[1].Replace('-', '+').Replace('_', '/');
            var padding = payload.Length % 4;
            if (padding > 0)
            {
                payload = payload.PadRight(payload.Length + (4 - padding), '=');
            }

            var jsonBytes = Convert.FromBase64String(payload);
            using var document = JsonDocument.Parse(jsonBytes);

            if (!document.RootElement.TryGetProperty("exp", out var expElement) || !expElement.TryGetInt64(out var expSeconds))
            {
                return null;
            }

            return DateTimeOffset.FromUnixTimeSeconds(expSeconds).LocalDateTime;
        }
        catch
        {
            return null;
        }
    }
}
