using System.Linq;
using Uninter.Correios.CrossCutting.Constants;
using Uninter.Correios.CrossCutting.Helpers;

namespace Uninter.Correios.CrossCutting.Extensions;

/// <summary>
/// Extensões para validação e formatação de dados dos Correios.
/// </summary>
public static class ValidationExtensions
{
    /// <summary>
    /// Remove caracteres não numéricos do CEP.
    /// </summary>
    public static string LimparCep(this string cep)
    {
        if (string.IsNullOrWhiteSpace(cep))
            return string.Empty;

        return new string(cep.Where(char.IsDigit).ToArray());
    }

    /// <summary>
    /// Valida se o CEP possui formato correto (8 dígitos numéricos).
    /// </summary>
    public static bool IsCepValido(this string cep)
    {
        var cepLimpo = cep.LimparCep();
        return cepLimpo.Length == CorreiosConstants.CEP_LENGTH && cepLimpo.All(char.IsDigit);
    }

    /// <summary>
    /// Formata o CEP no padrão 00000-000.
    /// </summary>
    public static string FormatarCep(this string cep)
    {
        var cepLimpo = cep.LimparCep();

        if (cepLimpo.Length != CorreiosConstants.CEP_LENGTH)
            return string.Empty;

        return $"{cepLimpo.Substring(0, 5)}-{cepLimpo.Substring(5, 3)}";
    }

    /// <summary>
    /// Valida se a UF é válida (pertence aos estados brasileiros).
    /// </summary>
    public static bool IsUfValida(this string uf)
    {
        return UnidadeFederativaHelper.IsUfValida(uf);
    }

    /// <summary>
    /// Normaliza a UF (trim e uppercase).
    /// </summary>
    public static string NormalizarUf(this string uf)
    {
        return UnidadeFederativaHelper.Normalizar(uf);
    }
}
