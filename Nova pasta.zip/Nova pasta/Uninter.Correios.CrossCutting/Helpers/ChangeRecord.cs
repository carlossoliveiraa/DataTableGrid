using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;

namespace Uninter.Correios.CrossCutting.Helpers;

public class ChangeRecord
{
    public string Tabela { get; set; } = string.Empty;
    public string OperationType { get; set; } = string.Empty;
    public Dictionary<string, object?> ChavePrimaria { get; set; } = new();
    
    /// <summary>
    /// Valores antigos do registro (antes da atualização).
    /// Este campo NÃO é incluído no JSON exportado.
    /// </summary>
    [JsonIgnore]
    public Dictionary<string, object?> ValoresAntigos { get; set; } = new();
    
    public Dictionary<string, object?> ValoresNovos { get; set; } = new();
    public DateTime DataHora { get; set; } = DateTime.UtcNow;

    public IEnumerable<string> ObterCamposAlterados()
    {
        return ValoresAntigos.Keys.Intersect(ValoresNovos.Keys)
            .Where(key => !Equals(ValoresAntigos[key], ValoresNovos[key]));
    }
}
