namespace Uninter.Correios.CrossCutting.Helpers;

public class ChangeStats
{
    public string Tabela { get; set; } = string.Empty;
    public int TotalInserir { get; set; }
    public int TotalAtualizar { get; set; }
    public int TotalRemover { get; set; }
    public int TotalSemAlteracao { get; set; }
    public int TotalProcessado => TotalInserir + TotalAtualizar + TotalRemover + TotalSemAlteracao;
    public int TotalMudancas => TotalInserir + TotalAtualizar + TotalRemover;
}
