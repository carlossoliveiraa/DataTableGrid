using System;
using System.Collections.Generic;

namespace Uninter.Correios.CrossCutting.Helpers;

public static class ExceptionHelper
{
    public static List<string> GetInnerException(List<string> errors, Exception error)
    {
        if (error.InnerException != null)
        {
            errors.Add(error.InnerException.Message);
            errors = GetInnerException(errors, error.InnerException);
        }

        return errors;
    }

    public static string GetInnerException(Exception error)
    {
        var message = error.Message;

        if (error.InnerException != null)
            message += ", " + GetInnerException(error.InnerException);

        return message;
    }
}
