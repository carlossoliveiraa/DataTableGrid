using System;
using System.Security.Cryptography;
using System.Text;

namespace Uninter.Correios.CrossCutting.Helpers
{
    /// <summary>
    /// Calcula SHA256 hash para detecção de mudanças em registros
    /// </summary>
    public static class HashCalculator
    {
        /// <summary>
        /// Calcula SHA256 hash de uma string
        /// </summary>
        public static string CalcularSHA256(string input)
        {
            if (string.IsNullOrEmpty(input))
                return string.Empty;

            using var sha256 = SHA256.Create();
            var bytes = Encoding.UTF8.GetBytes(input);
            var hash = sha256.ComputeHash(bytes);
            return Convert.ToHexString(hash); // Retorna hex uppercase
        }

        /// <summary>
        /// Calcula hash combinando múltiplos valores (para um registro completo)
        /// </summary>
        public static string CalcularHashRegistro(params object?[] valores)
        {
            var sb = new StringBuilder(256);
            
            foreach (var valor in valores)
            {
                if (valor != null)
                {
                    sb.Append(valor.ToString());
                    sb.Append('|'); // Separador para evitar colisões
                }
                else
                {
                    sb.Append("NULL|");
                }
            }

            return CalcularSHA256(sb.ToString());
        }
    }
}
