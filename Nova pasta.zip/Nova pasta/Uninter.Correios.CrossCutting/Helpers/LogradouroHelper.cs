using System.Linq;
using System.Text.RegularExpressions;

namespace Uninter.Correios.CrossCutting.Helpers;

/// <summary>
/// Helper para validação e tratamento de logradouros.
/// </summary>
public static class LogradouroHelper
{
    /// <summary>
    /// Verifica se o logradouro contém números.
    /// </summary>
    /// <param name="logradouro">Nome do logradouro</param>
    /// <returns>True se contém números, False caso contrário</returns>
    public static bool ContemNumeros(string logradouro)
    {
        if (string.IsNullOrWhiteSpace(logradouro))
            return false;

        return logradouro.Any(char.IsDigit);
    }

    /// <summary>
    /// Verifica se o logradouro contém vírgulas.
    /// </summary>
    /// <param name="logradouro">Nome do logradouro</param>
    /// <returns>True se contém vírgulas, False caso contrário</returns>
    public static bool ContemVirgula(string logradouro)
    {
        if (string.IsNullOrWhiteSpace(logradouro))
            return false;

        return logradouro.Contains(',');
    }

    /// <summary>
    /// Obtém uma sugestão de logradouro removendo números e vírgulas.
    /// Exemplo: "Rua das Flores, 123" -> "Rua das Flores"
    /// </summary>
    /// <param name="logradouro">Logradouro original</param>
    /// <returns>Sugestão de logradouro limpo</returns>
    public static string ObterSugestao(string logradouro)
    {
        if (string.IsNullOrWhiteSpace(logradouro))
            return string.Empty;

        // Remove vírgulas e tudo que vem depois
        var semVirgula = logradouro.Split(',')[0].Trim();

        // Remove números e caracteres especiais, mantendo apenas letras e espaços
        var sugestao = Regex.Replace(semVirgula, @"[0-9\-\.\/]", "").Trim();

        // Remove espaços duplicados
        sugestao = Regex.Replace(sugestao, @"\s+", " ");

        return sugestao;
    }

    /// <summary>
    /// Valida se o logradouro está no formato correto (sem números e vírgulas).
    /// </summary>
    /// <param name="logradouro">Nome do logradouro</param>
    /// <returns>True se válido, False caso contrário</returns>
    public static bool IsValido(string logradouro)
    {
        if (string.IsNullOrWhiteSpace(logradouro))
            return true; // Campo opcional

        return !ContemNumeros(logradouro) && !ContemVirgula(logradouro);
    }
}
