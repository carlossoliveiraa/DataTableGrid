using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;

namespace Uninter.Correios.CrossCutting.Helpers;

public static class NetworkHelper
{
    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());

        foreach (var ip in host.AddressList)
            if (ip.AddressFamily == AddressFamily.InterNetwork)
                return host.HostName + " " + ip.ToString();

        return "";
    }

    public static string GetConnections()
    {
        var globalProperties = IPGlobalProperties.GetIPGlobalProperties();
        var iPv4Statistics = globalProperties.GetTcpIPv4Statistics();
        var iPv6Statistics = globalProperties.GetTcpIPv6Statistics();
        var currentConnections = iPv4Statistics.CurrentConnections + iPv6Statistics.CurrentConnections;

        return currentConnections.ToString();
    }
}
