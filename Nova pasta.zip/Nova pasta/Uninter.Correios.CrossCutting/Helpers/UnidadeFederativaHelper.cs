using System.Collections.Generic;
using System.Linq;

namespace Uninter.Correios.CrossCutting.Helpers;

/// <summary>
/// Helper para validação de Unidades Federativas (UF) brasileiras.
/// </summary>
public static class UnidadeFederativaHelper
{
    private static readonly HashSet<string> UfsBrasileiras = new()
    {
        "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA",
        "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN",
        "RS", "RO", "RR", "SC", "SP", "SE", "TO"
    };

    /// <summary>
    /// Verifica se a UF é válida (existe no Brasil).
    /// </summary>
    /// <param name="uf">Sigla da UF (2 letras)</param>
    /// <returns>True se a UF é válida, False caso contrário</returns>
    public static bool IsUfValida(string uf)
    {
        if (string.IsNullOrWhiteSpace(uf))
            return false;

        return UfsBrasileiras.Contains(uf.ToUpperInvariant().Trim());
    }

    /// <summary>
    /// Obtém todas as UFs válidas do Brasil.
    /// </summary>
    /// <returns>Lista com todas as siglas de UF</returns>
    public static IEnumerable<string> ObterTodasUFs()
    {
        return UfsBrasileiras.OrderBy(uf => uf);
    }

    /// <summary>
    /// Normaliza a UF (trim e uppercase).
    /// </summary>
    /// <param name="uf">UF para normalizar</param>
    /// <returns>UF normalizada</returns>
    public static string Normalizar(string uf)
    {
        return uf?.Trim().ToUpperInvariant() ?? string.Empty;
    }
}
