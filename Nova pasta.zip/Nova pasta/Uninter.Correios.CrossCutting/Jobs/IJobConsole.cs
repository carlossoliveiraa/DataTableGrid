namespace Uninter.Correios.CrossCutting.Jobs;

/// <summary>
/// Abstração de console para jobs em background. Permite que a camada de
/// serviço escreva mensagens de progresso sem depender de tecnologia
/// específica (Hangfire). A implementação concreta vive na camada Api.
/// </summary>
public interface IJobConsole
{
    /// <summary>Escreve uma linha no console do job.</summary>
    void EscreverLinha(string mensagem = "");

    /// <summary>Inicia uma barra de progresso (0-100). Pode retornar uma instância no-op.</summary>
    IJobProgressBar IniciarBarraProgresso();
}

/// <summary>
/// Barra de progresso associada a uma execução de job.
/// </summary>
public interface IJobProgressBar
{
    /// <summary>Define o valor atual em porcentagem (0-100).</summary>
    void DefinirValor(int porcentagem);
}
