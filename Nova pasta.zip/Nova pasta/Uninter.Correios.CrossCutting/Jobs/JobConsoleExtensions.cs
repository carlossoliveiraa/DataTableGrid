namespace Uninter.Correios.CrossCutting.Jobs;

/// <summary>
/// Métodos de conveniência para escrever mensagens formatadas em um <see cref="IJobConsole"/>.
/// Centraliza emojis e separadores visuais usados pelos jobs.
/// </summary>
public static class JobConsoleExtensions
{
    private const string LinhaSeparadora = "═══════════════════════════════════════════════════════════════";

    /// <summary>Escreve um cabeçalho destacado com linhas separadoras acima e abaixo.</summary>
    public static void Cabecalho(this IJobConsole console, string titulo)
    {
        console.EscreverLinha(LinhaSeparadora);
        console.EscreverLinha(titulo);
        console.EscreverLinha(LinhaSeparadora);
    }

    /// <summary>Escreve um banner em caixa dupla (╔═╗) — usado no início e fim de jobs grandes.</summary>
    public static void Banner(this IJobConsole console, string titulo)
    {
        var linha = new string('═', 64);
        console.EscreverLinha($"╔{linha}╗");
        console.EscreverLinha($"║ {titulo,-62} ║");
        console.EscreverLinha($"╚{linha}╝");
    }

    /// <summary>Escreve uma linha de etapa numerada com separadores.</summary>
    public static void Etapa(this IJobConsole console, int numero, string titulo)
    {
        console.EscreverLinha(LinhaSeparadora);
        console.EscreverLinha($"📍 ETAPA {numero}: {titulo}");
        console.EscreverLinha(LinhaSeparadora);
    }

    public static void Sucesso(this IJobConsole console, string mensagem) => console.EscreverLinha($"✅ {mensagem}");
    public static void Erro(this IJobConsole console, string mensagem) => console.EscreverLinha($"❌ {mensagem}");
    public static void Aviso(this IJobConsole console, string mensagem) => console.EscreverLinha($"⚠️  {mensagem}");
    public static void Info(this IJobConsole console, string mensagem) => console.EscreverLinha($"ℹ️  {mensagem}");
}
