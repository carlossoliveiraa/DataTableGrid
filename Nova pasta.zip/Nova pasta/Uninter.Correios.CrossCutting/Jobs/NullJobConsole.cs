namespace Uninter.Correios.CrossCutting.Jobs;

/// <summary>
/// Implementação no-op de <see cref="IJobConsole"/>. Útil quando o serviço é
/// invocado fora de um job em background (por exemplo: chamada via controller
/// ou em testes unitários).
/// </summary>
public sealed class NullJobConsole : IJobConsole
{
    public static readonly NullJobConsole Instance = new();

    private NullJobConsole() { }

    public void EscreverLinha(string mensagem = "") { }

    public IJobProgressBar IniciarBarraProgresso() => NullJobProgressBar.Instance;
}

internal sealed class NullJobProgressBar : IJobProgressBar
{
    public static readonly NullJobProgressBar Instance = new();
    private NullJobProgressBar() { }
    public void DefinirValor(int porcentagem) { }
}
