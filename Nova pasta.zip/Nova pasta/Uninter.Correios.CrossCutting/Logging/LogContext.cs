namespace Uninter.Correios.CrossCutting.Logging;

/// <summary>
/// Contextos padronizados de logging.
/// Use via <see cref="Uninter.Correios.CrossCutting.Contract.IAppLogger"/> para gerar
/// mensagens com prefixo "[Contexto] ..." de forma consistente.
/// </summary>
public static class LogContext
{
    public const string Atualizacao = "Atualizacao";
    public const string Cep = "CEP";
    public const string Configuracao = "Configuracao";
    public const string Email = "Email";
    public const string Endereco = "Endereco";
    public const string Hangfire = "Hangfire";
    public const string OAuth = "OAuth";
    public const string ZipCode = "ZipCode";
}
