using System;
using System.Collections.Generic;

namespace Uninter.Correios.CrossCutting.Messaging;

/// <summary>
/// Mensagem publicada no RabbitMQ com dados de mudanças do CEP.
/// Contém apenas os valores novos (pós-importação).
/// </summary>
public class ChangeRecordMessage
{
    /// <summary>
    /// Nome da tabela afetada (ex: Logradouro, Bairro, Localidade)
    /// </summary>
    public string Tabela { get; set; } = string.Empty;

    /// <summary>
    /// Tipo de operação realizada (INSERT ou UPDATE)
    /// </summary>
    public string OperationType { get; set; } = string.Empty;

    /// <summary>
    /// Chave primária do registro (ex: { "Id": "80060240" })
    /// </summary>
    public Dictionary<string, object?> ChavePrimaria { get; set; } = new();

    /// <summary>
    /// Valores do registro após a importação (valores novos)
    /// </summary>
    public Dictionary<string, object?> ValoresNovos { get; set; } = new();

    /// <summary>
    /// Data e hora da operação (UTC)
    /// </summary>
    public DateTime DataHora { get; set; } = DateTime.UtcNow;
}
