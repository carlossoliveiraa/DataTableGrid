namespace Uninter.Correios.CrossCutting.Messaging;

/// <summary>
/// Mensagem individual enviada para RabbitMQ com dados de CEP.
/// Formato esperado pelo consumidor para gravação na tabela CEPLocalidade.
/// </summary>
public class PostalInfo
{
    /// <summary>
    /// CEP sem formatação (apenas números).
    /// Exemplo: "60332800" (string com 8 dígitos)
    /// Grava em: CEPLocalidade.cep
    /// </summary>
    public string ZipCode { get; set; } = string.Empty;

    /// <summary>
    /// Código IBGE da cidade.
    /// Grava em: CEPLocalidade.cd_cidade
    /// </summary>
    public long CityId { get; set; }

    /// <summary>
    /// Nome do bairro.
    /// Grava em: CEPLocalidade.bairro
    /// </summary>
    public string District { get; set; } = string.Empty;

    /// <summary>
    /// Nome da rua/avenida/logradouro.
    /// Grava em: CEPLocalidade.logradouro
    /// </summary>
    public string Address { get; set; } = string.Empty;

    /// <summary>
    /// Número do endereço (string vazia "" se não houver).
    /// Grava em: CEPLocalidade.numero
    /// </summary>
    public string Number { get; set; } = string.Empty;

    /// <summary>
    /// Tipo de logradouro (1=Rua, 2=Avenida, etc).
    /// Grava em: CEPLocalidade.cd_tipo_localidade
    /// </summary>
    public int TypeId { get; set; }
}
