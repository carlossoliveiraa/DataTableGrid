using System;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using RabbitMQ.Client;

using Uninter.Correios.CrossCutting.Contract;

namespace Uninter.Correios.CrossCutting.Messaging;

/// <summary>
/// Publicador simples de mensagens no RabbitMQ.
/// Baseado no padrão usado em Uninter.Producer.Handler do projeto ZipCode.
/// Compatível com RabbitMQ.Client 7.x (IChannel API)
/// </summary>
public class RabbitMQPublisher : IDisposable
{
    private IConnection? _connection;
    private IChannel? _channel;
    private readonly RabbitMQSettings _settings;
    private readonly IAppLogger _logger;
    private bool _disposed;

    public RabbitMQPublisher(RabbitMQSettings settings, IAppLogger logger)
    {
        _settings = settings ?? throw new ArgumentNullException(nameof(settings));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Conecta ao RabbitMQ (lazy initialization)
    /// </summary>
    private async Task EnsureConnectionAsync()
    {
        if (_connection != null && _connection.IsOpen)
            return;

        try
        {
            var factory = new ConnectionFactory
            {
                UserName = _settings.Username,
                Password = _settings.Password,
                Port = _settings.Port,
                AutomaticRecoveryEnabled = true,
                NetworkRecoveryInterval = TimeSpan.FromSeconds(10)
            };

            // Suporte a múltiplos hosts (failover)
            var hosts = _settings.Hosts.Split(',', StringSplitOptions.RemoveEmptyEntries);
            var hostList = new System.Collections.Generic.List<string>();
            foreach (var host in hosts)
            {
                hostList.Add(host.Trim());
            }

            _connection = await factory.CreateConnectionAsync(hostList, _settings.Platform);
            _channel = await _connection.CreateChannelAsync();

            // Declarar exchange (idempotente)
            await _channel.ExchangeDeclareAsync(
                exchange: _settings.Exchange,
                type: ExchangeType.Topic,
                durable: true,
                autoDelete: false);

            _logger.Information($"RabbitMQ - Conectado ao exchange: {_settings.Exchange}");
        }
        catch (Exception ex)
        {
            _logger.Error("RabbitMQ - Falha ao conectar", ex);
            throw;
        }
    }

    /// <summary>
    /// Publica uma mensagem tipada no RabbitMQ (async).
    /// Equivalente ao _producer.Publish<T>(message) do ZipCode.
    /// </summary>
    /// <typeparam name="T">Tipo da mensagem</typeparam>
    /// <param name="message">Objeto a ser publicado</param>
    /// <param name="routingKey">Routing key (opcional, usa nome do tipo por padrão)</param>
    public async Task PublishAsync<T>(T message, string? routingKey = null) where T : class
    {
        if (message == null)
            throw new ArgumentNullException(nameof(message));

        await EnsureConnectionAsync();

        if (_channel == null || !_channel.IsOpen)
            throw new InvalidOperationException("Canal RabbitMQ não está aberto");

        try
        {
            // Serializar para JSON (PascalCase - formato esperado pelo consumer)
            var json = JsonSerializer.Serialize(message, new JsonSerializerOptions
            {
                WriteIndented = false,
                PropertyNamingPolicy = null, // PascalCase (mantém nomes originais das propriedades)
                DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
                Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            });

            _logger.Information($"RabbitMQ - JSON a enviar: {json}");
            
            var body = Encoding.UTF8.GetBytes(json);

            // Routing key: DEVE vir configurada, não usar nome do tipo
            if (string.IsNullOrWhiteSpace(routingKey))
                throw new InvalidOperationException($"RoutingKey não pode ser vazia. Configure RabbitMQ:RoutingKey no appsettings.");
            
            var key = routingKey;

            // Propriedades da mensagem (API v7)
            // IMPORTANTE: "Type" é a basic property AMQP (IBasicProperties.Type),
            // NÃO um header. O EasyNetQ 0.50.x dos consumidores (AX, Quinto
            // Elemento, Registry) usa essa property para fazer dispatch para o
            // handler correto. Se vier vazia ou com valor diferente do esperado,
            // os consumidores descartam a mensagem com ack silencioso.
            var properties = new BasicProperties
            {
                Persistent = true,
                ContentType = "application/json",
                ContentEncoding = "utf-8",
                DeliveryMode = DeliveryModes.Persistent,
                Type = _settings.MessageType,
                Timestamp = new AmqpTimestamp(DateTimeOffset.UtcNow.ToUnixTimeSeconds())
            };

            // Publicar (API v7)
            await _channel.BasicPublishAsync(
                exchange: _settings.Exchange,
                routingKey: key,
                mandatory: false,
                basicProperties: properties,
                body: body);

            _logger.Information($"RabbitMQ - Mensagem publicada: {key} ({body.Length} bytes)");
        }
        catch (Exception ex)
        {
            _logger.Error($"RabbitMQ - Falha ao publicar mensagem de tipo {typeof(T).Name}", ex);
            throw;
        }
    }

    /// <summary>
    /// Versão síncrona para compatibilidade (usa Task.Run internamente)
    /// </summary>
    public void Publish<T>(T message, string? routingKey = null) where T : class
    {
        PublishAsync(message, routingKey).GetAwaiter().GetResult();
    }

    public void Dispose()
    {
        if (_disposed)
            return;

        try
        {
            if (_channel != null)
            {
                _channel.CloseAsync().GetAwaiter().GetResult();
                _channel.Dispose();
            }
            
            if (_connection != null)
            {
                _connection.CloseAsync().GetAwaiter().GetResult();
                _connection.Dispose();
            }
        }
        catch (Exception ex)
        {
            _logger.Warning($"RabbitMQ - Erro ao fechar conexão: {ex.Message}");
        }
        finally
        {
            _disposed = true;
        }
    }
}
