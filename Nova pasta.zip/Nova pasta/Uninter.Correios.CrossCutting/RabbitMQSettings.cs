namespace Uninter.Correios.CrossCutting;

/// <summary>
/// Configurações do RabbitMQ para publicação de mensagens.
/// Baseado no padrão usado em Uninter.ZipCode.Api
/// </summary>
public class RabbitMQSettings
{
    /// <summary>
    /// Hosts do RabbitMQ separados por vírgula (ex: corp-queue-003,corp-queue-004)
    /// </summary>
    public string Hosts { get; set; } = string.Empty;

    /// <summary>
    /// Porta do RabbitMQ (padrão: 5672)
    /// </summary>
    public int Port { get; set; } = 5672;

    /// <summary>
    /// Usuário para autenticação
    /// </summary>
    public string Username { get; set; } = string.Empty;

    /// <summary>
    /// Senha para autenticação
    /// </summary>
    public string Password { get; set; } = string.Empty;

    /// <summary>
    /// Exchange principal (ex: zipcode.pre, zipcode.prod)
    /// </summary>
    public string Exchange { get; set; } = string.Empty;

    /// <summary>
    /// Routing key para direcionar mensagens para fila específica (ex: P0)
    /// </summary>
    public string RoutingKey { get; set; } = string.Empty;

    /// <summary>
    /// Prefixo do ambiente (ex: pre, prod)
    /// </summary>
    public string Prefix { get; set; } = string.Empty;

    /// <summary>
    /// Nome da plataforma publicadora
    /// </summary>
    public string Platform { get; set; } = "UninterCorreiosPublisher";

    /// <summary>
    /// Habilita confirmação de publicação
    /// </summary>
    public bool PublisherConfirms { get; set; } = true;

    /// <summary>
    /// Valor da propriedade AMQP "type" (basic property, NÃO header).
    /// Usado pelo EasyNetQ dos consumidores (AX, Quinto Elemento, Registry)
    /// para fazer dispatch para o handler correto. Formato EasyNetQ:
    /// "TypeFullName:AssemblyName".
    /// Padrão: "Uninter.Exchange.ZipCode.PostalInfo:Uninter.Exchange.ZipCode".
    /// </summary>
    public string MessageType { get; set; } = "Uninter.Exchange.ZipCode.PostalInfo:Uninter.Exchange.ZipCode";

    /// <summary>
    /// Monta a connection string no formato esperado pelo RabbitMQ.Client
    /// </summary>
    public string GetConnectionString()
    {
        return $"host={Hosts};port={Port};username={Username};password={Password};platform={Platform};publisherConfirms={PublisherConfirms.ToString().ToLower()}";
    }
}
