namespace Uninter.Correios.CrossCutting.Result;

/// <summary>
/// Resultado padronizado para operações da camada de serviço.
/// Permite expressar sucesso, falha de validação/negócio e recurso não encontrado
/// sem precisar lançar exceções para fluxos esperados.
/// </summary>
/// <typeparam name="T">Tipo do dado retornado em caso de sucesso.</typeparam>
public sealed class ServiceResult<T>
{
    public T Data { get; }
    public string Error { get; }
    public bool NotFound { get; }
    public bool Success => Error is null;

    private ServiceResult(T data, string error, bool notFound)
    {
        Data = data;
        Error = error;
        NotFound = notFound;
    }

    public static ServiceResult<T> Ok(T data) => new(data, null, false);

    public static ServiceResult<T> Fail(string error) => new(default, error, false);

    public static ServiceResult<T> NotFoundResult(string error) => new(default, error, true);
}
