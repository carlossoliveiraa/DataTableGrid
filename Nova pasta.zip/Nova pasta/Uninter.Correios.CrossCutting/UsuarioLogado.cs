namespace Uninter.Correios.CrossCutting;

/// <summary>
/// Classe para armazenar informações do usuário logado no contexto da requisição.
/// </summary>
public class UsuarioLogado
{
    /// <summary>
    /// ID da pessoa autenticada extraído do token JWT.
    /// </summary>
    public int PessoaId { get; set; }

    /// <summary>
    /// Nome do usuário autenticado (extraído do Identity.Name).
    /// </summary>
    public string? UserName { get; set; }
}
