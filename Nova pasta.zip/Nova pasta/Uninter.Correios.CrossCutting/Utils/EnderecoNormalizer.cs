using System;
using System.Collections.Generic;

namespace Uninter.Correios.CrossCutting.Utils;

/// <summary>
/// Classe responsável por normalizar nomes de endereços com capitalização adequada.
/// </summary>
public static class EnderecoNormalizer
{
   
    private static readonly HashSet<string> PalavrasMinusculas = new(StringComparer.OrdinalIgnoreCase)
    {
        "de", "da", "do", "das", "dos", "e", "a", "o", "as", "os", "em", "para", "com", "por", "ao", "à", "às"
    };

  
    public static string Normalizar(string? texto)
    {
        if (string.IsNullOrWhiteSpace(texto))
            return texto ?? string.Empty;
               
        var palavras = texto.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        var resultado = new List<string>();

        for (int i = 0; i < palavras.Length; i++)
        {
            var palavra = palavras[i].Trim();
            if (string.IsNullOrEmpty(palavra))
                continue;
                        
            if (PalavrasMinusculas.Contains(palavra) && i > 0)
            {
                resultado.Add(palavra.ToLowerInvariant());
            }
            else
            {               
                var palavraCapitalizada = char.ToUpperInvariant(palavra[0]) + palavra.Substring(1).ToLowerInvariant();
                resultado.Add(palavraCapitalizada);
            }
        }

        return string.Join(" ", resultado);
    }

    /// <summary>
    /// Normaliza múltiplos campos de endereço.
    /// </summary>
    public static (string? logradouro, string? nomeLogradouro, string? bairro, string? localidade) 
        NormalizarCamposEndereco(string? logradouro, string? nomeLogradouro, string? bairro, string? localidade)
    {
        return (
            Normalizar(logradouro),
            Normalizar(nomeLogradouro),
            Normalizar(bairro),
            Normalizar(localidade)
        );
    }
}
