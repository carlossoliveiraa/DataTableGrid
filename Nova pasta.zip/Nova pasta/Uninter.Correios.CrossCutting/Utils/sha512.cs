using System.Text;

namespace Uninter.Correios.CrossCutting.Utils;

public class Sha512
{
    private readonly string _hash;

    public Sha512(string input)
    {
        var bytes = Encoding.UTF8.GetBytes(input);
        var hashedInputBytes = System.Security.Cryptography.SHA512.HashData(bytes);

        // Convert to text
        // StringBuilder Capacity is 128, because 512 bits / 8 bits in byte * 2 symbols for byte
        var hashedInputStringBuilder = new System.Text.StringBuilder(128);
        foreach (var b in hashedInputBytes)
            hashedInputStringBuilder.Append(b.ToString("X2"));
        _hash = hashedInputStringBuilder.ToString();
    }

    public override string ToString()
    {
        return _hash;
    }
}
