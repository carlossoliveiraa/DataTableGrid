namespace Uninter.Correios.Domain.Enum;

public enum ConnType
{
    Single,
    Multiple
}
