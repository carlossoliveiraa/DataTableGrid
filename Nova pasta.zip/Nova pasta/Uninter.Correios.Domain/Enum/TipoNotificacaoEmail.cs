namespace Uninter.Correios.Domain.Enum;

/// <summary>
/// Tipos de notificação por email suportados pelo serviço de notificações.
/// </summary>
public enum TipoNotificacaoEmail
{
    NovaImportacao,
    FalhaExecucao,
    TokenExpiracao
}
