using System;
using System.Threading;
using System.Threading.Tasks;
using Uninter.Correios.CrossCutting.Extensions;
using Uninter.Correios.Domain.Interfaces.Infra;

namespace Uninter.Correios.Domain.Handlers.Token;

/// <summary>
/// Cache singleton para o token de autenticação dos Correios.
/// Carrega o token uma vez na inicialização da aplicação e mantém em memória.
/// Thread-safe: leituras usam um snapshot imutável; escritas (Inicializar/Recarregar)
/// publicam o snapshot atomicamente e são serializadas por SemaphoreSlim.
/// </summary>
public class CorreiosTokenCache : ICorreiosTokenCache
{
    private sealed record TokenSnapshot(string Token, DateTime? ExpiraEm);

    private static readonly TokenSnapshot Vazio = new(string.Empty, null);

    private TokenSnapshot _snapshot = Vazio;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private volatile bool _foiInicializado;

    /// <summary>
    /// Inicializa o cache do token buscando do banco de dados.
    /// Idempotente: chamadas subsequentes após sucesso retornam imediatamente.
    /// </summary>
    public async Task InicializarAsync(ICorreiosConfiguracaoRepository configuracaoRepository)
    {
        if (_foiInicializado)
        {
            return;
        }

        await _gate.WaitAsync();
        try
        {
            if (_foiInicializado)
            {
                return;
            }

            await CarregarSnapshotAsync(configuracaoRepository);
            _foiInicializado = true;
        }
        finally
        {
            _gate.Release();
        }
    }

    /// <summary>
    /// Obtém o token do cache (sem consultar o banco de dados).
    /// </summary>
    public string ObterToken()
    {
        var snapshot = Volatile.Read(ref _snapshot);

        if (!_foiInicializado || string.IsNullOrEmpty(snapshot.Token))
        {
            throw new InvalidOperationException(
                "Cache de token não foi inicializado. Certifique-se se as stored procedures estao na base de dados");
        }

        if (snapshot.ExpiraEm.HasValue && snapshot.ExpiraEm.Value <= DateTime.Now)
        {
            throw new InvalidOperationException(
                $"Token dos Correios expirou em {snapshot.ExpiraEm.Value:dd/MM/yyyy HH:mm}. Atualize o token no banco de dados e reinicie a aplicação");
        }

        return snapshot.Token;
    }

    /// <summary>
    /// Verifica se o cache foi inicializado.
    /// </summary>
    public bool FoiInicializado() => _foiInicializado;

    /// <summary>
    /// Obtém a data de expiração do token em cache.
    /// </summary>
    public DateTime? ObterDataExpiracao() => Volatile.Read(ref _snapshot).ExpiraEm;

    /// <summary>
    /// Força o recarregamento do token a partir do banco de dados,
    /// permitindo renovar o cache sem reiniciar a aplicação.
    /// O snapshot anterior continua atendendo leituras concorrentes até a publicação atômica do novo.
    /// </summary>
    public async Task RecarregarAsync(ICorreiosConfiguracaoRepository configuracaoRepository)
    {
        await _gate.WaitAsync();
        try
        {
            await CarregarSnapshotAsync(configuracaoRepository);
            _foiInicializado = true;
        }
        finally
        {
            _gate.Release();
        }
    }

    private async Task CarregarSnapshotAsync(ICorreiosConfiguracaoRepository configuracaoRepository)
    {
        var configuracao = await configuracaoRepository.ObterTokenAtivoAsync()
            ?? throw new InvalidOperationException("Token dos Correios não encontrado no banco de dados");

        if (!configuracao.EstaValido())
        {
            throw new InvalidOperationException("Token dos Correios está expirado ou inativo");
        }

        var novo = new TokenSnapshot(
            Token: configuracao.Token.CleanTokenValue(),
            ExpiraEm: configuracao.Token.TryGetJwtExpiration() ?? configuracao.ExpiraEm);

        Volatile.Write(ref _snapshot, novo);
    }
}
