using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using Uninter.Correios.Domain.Interfaces.Api;
using Uninter.Correios.Domain.Request.Token;
using Uninter.Correios.Domain.Response.Token;

namespace Uninter.Correios.Domain.Handlers.Token;

public class TokenApiHeaderHandler(ITokenApi tokenApi) : DelegatingHandler
{
    private readonly ITokenApi _tokenApi = tokenApi ?? throw new ArgumentNullException(nameof(tokenApi));
    private TokenJwtResponse _cachedToken;
    private readonly Lock _tokenLock = new();


    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        string username = ConsultaUsernamePorAlgumaRegra(request);
        var token = await GetTokenAsync(username).ConfigureAwait(false);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.Token);

        return await base.SendAsync(request, cancellationToken).ConfigureAwait(false);
    }

    private async Task<TokenJwtResponse> GetTokenAsync(string username)
    {
        lock (_tokenLock)
        {
            if (_cachedToken?.Expiration > DateTime.UtcNow)
                return _cachedToken;
        }

        _cachedToken = await GetTokenJwtResponse(username).ConfigureAwait(false);

        return _cachedToken;
    }

    private async Task<TokenJwtResponse> GetTokenJwtResponse(string username)
    {
        var tokenResponse = await _tokenApi.GetTokenJwtAsync(new TokenJwtRequest { UserName = username }).ConfigureAwait(false);

        return tokenResponse.Data;
    }

    private static string ConsultaUsernamePorAlgumaRegra(HttpRequestMessage request)
    {
        var username = "SistemasInternos";

        if (request.RequestUri.ToString().Contains("financeiroapi"))
            username = "Financeiro";
        else if (request.RequestUri.ToString().Contains("v1/GetCriarArquivo"))
            username = "CriarArquivo";
        return username;
    }
}
