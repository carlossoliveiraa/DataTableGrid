using Refit;
using System.Threading.Tasks;
using Uninter.Correios.Domain.Request.Api;
using Uninter.Correios.Domain.Response.Api;

namespace Uninter.Correios.Domain.Interfaces.Api;

/// <summary>
/// Interface Refit para comunicação com a Account API
/// </summary>
public interface IAccountApi
{
    /// <summary>
    /// Autentica um usuário via RU e senha
    /// </summary>
    /// <param name="request">Dados de autenticação (RU, senha, sistema)</param>
    /// <returns>Resposta com token JWT e tempo de expiração</returns>
    [Post("/v1/authenticate/ru")]
    [Headers("Content-Type: application/json")]
    Task<ResponseApi<AccountResponse>> AuthenticateRu([Body(BodySerializationMethod.Serialized)] AuthenticateRuCommand request);
}
