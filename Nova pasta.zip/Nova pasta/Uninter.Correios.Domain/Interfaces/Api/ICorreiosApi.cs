using System.Threading.Tasks;
using Refit;
using Uninter.Correios.Domain.Response.Api;

namespace Uninter.Correios.Domain.Interfaces.Api;

/// <summary>
/// Interface Refit para integração com a API dos Correios.
/// </summary>
public interface ICorreiosApi
{
    /// <summary>
    /// Consulta um CEP específico na API dos Correios.
    /// </summary>
    /// <param name="cep">CEP sem formatação (apenas números, 8 dígitos).</param>
    /// <param name="token">Token de autenticação Bearer.</param>
    /// <returns>Dados do endereço correspondente ao CEP.</returns>
    [Get("/cep/v2/enderecos/{cep}")]
    Task<EnderecoResponse> ConsultarCepAsync(
        string cep,
        [Header("Authorization")] string token);

    /// <summary>
    /// Lista endereços com base em filtros (UF, localidade, bairro, logradouro).
    /// Retorna modelo paginado da API v2 dos Correios.
    /// </summary>
    /// <param name="queryParams">Parâmetros de busca que serão convertidos em query string.</param>
    /// <param name="token">Token de autenticação Bearer.</param>
    /// <returns>Resultado paginado com lista de endereços.</returns>
    [Get("/cep/v2/enderecos")]
    Task<PagedModelEnderecoResponse> ListarEnderecosAsync(
        [Query] Request.Api.ListaEnderecosQueryParams queryParams,
        [Header("Authorization")] string token);

    /// <summary>
    /// Verifica a data de atualização dos dados na API dos Correios.
    /// </summary>
    /// <param name="token">Token de autenticação Bearer.</param>
    /// <returns>Objeto com a data de última atualização.</returns>
    [Get("/cep/v1/atualizacao")]
    Task<CorreiosAtualizacaoResponse> VerificarAtualizacaoAsync(
        [Header("Authorization")] string token);
}
