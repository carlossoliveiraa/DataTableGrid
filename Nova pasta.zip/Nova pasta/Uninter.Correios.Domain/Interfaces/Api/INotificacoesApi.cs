using Refit;
using System;
using System.Threading.Tasks;
using Uninter.Correios.Domain.Request.Api.Notificacoes.Email;
using Uninter.Correios.Domain.Response.Api;

namespace Uninter.Correios.Domain.Interfaces.Api;

public interface INotificacoesApi
{
    [Post("/v1/email/fila/integracao/personalizado/add")]
    Task<ResponseApiResponse<Guid>> EnviarEmailPersonalizado([Body(BodySerializationMethod.Serialized)] EmailFilaPersonalizadoRequest command);

    [Post("/v1/email/fila/integracao/personalizado/assunto/add")]
    Task<ResponseApiResponse<Guid>> EnviarEmailPersonalizadoAssunto([Body(BodySerializationMethod.Serialized)] EmailFilaPersonalizadoAssuntoRequest command);

    [Post("/v1/email/fila/integracao/texto/add")]
    Task<ResponseApiResponse<Guid>> EnviarEmailTexto([Body(BodySerializationMethod.Serialized)] EmailFilaTextoRequest command);

    [Get("/v1/email/template/integracao/viewbynome/{nome}")]
    Task<ResponseApiResponse<string>> BuscarConteudoHtml(string nome);
}
