using Refit;
using System.Threading.Tasks;
using Uninter.Correios.Domain.Request.Token;
using Uninter.Correios.Domain.Response.Token;

namespace Uninter.Correios.Domain.Interfaces.Api;

public interface ITokenApi
{
    [Post("/api/tokenJWT")]
    Task<TokenApiResponse> GetTokenJwtAsync([Body] TokenJwtRequest request);
}
