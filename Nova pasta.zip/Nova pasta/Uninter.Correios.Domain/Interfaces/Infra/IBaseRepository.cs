using System.Collections.Generic;
using System.Threading.Tasks;

namespace Uninter.Correios.Domain.Interfaces.Infra;

public interface IBaseRepository<TEntity>
{
    Task<int> InserirAsync(TEntity parameters);
    Task<bool> AtualizarAsync(TEntity parameters);
    Task<bool> DeletarAsync(int id);
    Task<TEntity> ConsultarPorIdAsync(int id);
    Task<IEnumerable<TEntity>> ConsultarTodosAsync();
    Task<bool> IdValidoAsync(int id);
}
