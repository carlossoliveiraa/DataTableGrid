using System;
using System.Data;
using Uninter.Correios.Domain.Enum;

namespace Uninter.Correios.Domain.Interfaces.Infra;

public interface IConnectionManager : IDisposable
{
    IDbTransaction Trans { get; set; }

    ConnType Type { get; set; }

    Lazy<IDbConnection> Conn { get; set; }

    void BeginMultiTransaction();

    void BeginTransaction();

    void Rollback();

    void CommitAll();

    void Commit();
}
