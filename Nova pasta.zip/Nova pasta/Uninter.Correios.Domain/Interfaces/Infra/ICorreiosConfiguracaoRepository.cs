using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Uninter.Correios.Domain.Models;
using Uninter.Correios.Domain.Request.ConfiguracaoAplicacao;

namespace Uninter.Correios.Domain.Interfaces.Infra;

/// <summary>
/// Interface para repositório de configuração dos Correios.
/// </summary>
public interface ICorreiosConfiguracaoRepository
{
    /// <summary>
    /// Obtém o token ativo e válido do banco de dados.
    /// </summary>
    Task<CorreiosConfiguracao> ObterTokenAtivoAsync();

    /// <summary>
    /// Obtém uma configuração específica por ID.
    /// </summary>
    Task<CorreiosConfiguracao> ObterPorIdAsync(int id);

    /// <summary>
    /// Verifica se existe um token válido no banco de dados.
    /// </summary>
    Task<bool> PossuiTokenValidoAsync();

    /// <summary>
    /// Atualiza a data de último uso do token.
    /// </summary>
    Task AtualizarUltimoUsoAsync(int id);

    /// <summary>
    /// Atualiza a data de atualização dos Correios.
    /// </summary>
    Task AtualizarDataAtualizacaoCorreiosAsync(int id, DateTime dataAtualizacaoCorreios);

    // ── CRUD ──────────────────────────────────────────────────────────────

    /// <summary>Lista todos os registros (ativos e inativos).</summary>
    Task<IEnumerable<CorreiosConfiguracao>> ListarTodosAsync();

    /// <summary>Insere nova configuração e desativa as anteriores.</summary>
    Task<int> InserirAsync(CorreiosConfiguracaoInserirRequest request);

    /// <summary>Atualiza token, IP, expiração e observação de um registro existente.</summary>
    Task AtualizarAsync(int id, CorreiosConfiguracaoAtualizarRequest request);

    /// <summary>Exclusão lógica: seta Ativo = 0.</summary>
    Task ExcluirLogicoAsync(int id);
}
