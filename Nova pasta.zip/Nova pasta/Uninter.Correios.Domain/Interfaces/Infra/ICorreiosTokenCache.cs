using System;
using System.Threading.Tasks;
using Uninter.Correios.Domain.Models;

namespace Uninter.Correios.Domain.Interfaces.Infra;

/// <summary>
/// Interface para cache do token de autenticação dos Correios.
/// </summary>
public interface ICorreiosTokenCache
{
    /// <summary>
    /// Inicializa o cache do token buscando do banco de dados.
    /// Deve ser chamado apenas uma vez no startup da aplicação.
    /// </summary>
    Task InicializarAsync(ICorreiosConfiguracaoRepository configuracaoRepository);

    /// <summary>
    /// Obtém o token do cache (sem consultar o banco de dados).
    /// </summary>
    /// <returns>Token de autenticação dos Correios.</returns>
    string ObterToken();

    /// <summary>
    /// Verifica se o cache foi inicializado.
    /// </summary>
    bool FoiInicializado();

    /// <summary>
    /// Obtém a data de expiração do token em cache.
    /// </summary>
    DateTime? ObterDataExpiracao();

    /// <summary>
    /// Força o recarregamento do token a partir do banco de dados,
    /// permitindo renovar o cache sem reiniciar a aplicação.
    /// </summary>
    Task RecarregarAsync(ICorreiosConfiguracaoRepository configuracaoRepository);
}
