using System.Collections.Generic;
using System.Threading.Tasks;
using Uninter.Correios.CrossCutting.Helpers;
using Uninter.Correios.Domain.Models.ImportV2;

namespace Uninter.Correios.Domain.Interfaces.Infra;

public interface IZipCodeImportRepository
{
    Task LimparStagingAsync();

    Task BulkInsertLocalidadesAsync(IEnumerable<Localidade> localidades);
    Task BulkInsertBairrosAsync(IEnumerable<Bairro> bairros);
    Task BulkInsertLogradourosAsync(IEnumerable<Logradouro> logradouros, string uf);
    Task BulkInsertCaixasPostaisAsync(IEnumerable<CaixaPostal> caixas);
    Task BulkInsertGrandesUsuariosAsync(IEnumerable<GrdUsuario> usuarios);
    Task BulkInsertUnidadesOperacionaisAsync(IEnumerable<UnidadeOper> unidades);

    Task<(int inserted, int updated, int unchanged, List<ChangeRecord> mudancas)> MergeLogradourosAsync();
    Task<(int inserted, int updated, int unchanged, List<ChangeRecord> mudancas)> MergeCaixasPostaisAsync();
    Task<(int inserted, int updated, int unchanged, List<ChangeRecord> mudancas)> MergeGrandesUsuariosAsync();
    Task<(int inserted, int updated, int unchanged, List<ChangeRecord> mudancas)> MergeUnidadesOperacionaisAsync();
}
