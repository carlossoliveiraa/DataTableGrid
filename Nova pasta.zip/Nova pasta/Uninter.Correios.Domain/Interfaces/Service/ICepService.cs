using System.Threading.Tasks;
using Uninter.Correios.Domain.Models;
using Uninter.Correios.Domain.Request.Cep;

namespace Uninter.Correios.Domain.Interfaces.Service;

/// <summary>
/// Interface do serviço de consulta de CEP.
/// </summary>
public interface ICepService
{
    /// <summary>
    /// Consulta um CEP na API dos Correios.
    /// </summary>
    /// <param name="request">Request contendo o CEP a ser consultado.</param>
    /// <returns>Endereco correspondente ao CEP ou null se não encontrado.</returns>
    Task<Endereco> ConsultarCepAsync(ConsultarCepRequest request);
}
