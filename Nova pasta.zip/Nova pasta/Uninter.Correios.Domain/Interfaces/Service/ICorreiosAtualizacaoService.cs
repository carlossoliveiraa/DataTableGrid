using System;
using System.Threading.Tasks;
using Uninter.Correios.Domain.Response.Api;

namespace Uninter.Correios.Domain.Interfaces.Service;

/// <summary>
/// Interface para verificação de atualizações da API dos Correios.
/// </summary>
public interface ICorreiosAtualizacaoService
{
    /// <summary>
    /// Verifica se há atualização disponível na API dos Correios comparando 
    /// com a última data armazenada no banco de dados.
    /// </summary>
    /// <returns>True se houver atualização disponível, False caso contrário.</returns>
    Task<bool> VerificarSeHaAtualizacaoAsync();

    /// <summary>
    /// Verifica se há atualização disponível na API dos Correios.
    /// Se a data no banco estiver NULL (primeira execução), chama a API e retorna (true, true, dataCorreios).
    /// Se tiver data, compara com a API e retorna (haAtualizacao, false, dataCorreios).
    /// A data retornada deve ser usada para gravar no banco ao final da importação.
    /// </summary>
    /// <returns>Tupla com (haAtualizacao, primeiraExecucao, dataAtualizacaoCorreios)</returns>
    Task<(bool haAtualizacao, bool primeiraExecucao, DateTime? dataAtualizacaoCorreios)> VerificarEGravarDataInicialSeNecessarioAsync();

    /// <summary>
    /// Grava a data de atualização dos Correios no banco diretamente, sem chamar a API novamente.
    /// Use esta sobrecarga quando já tiver a data obtida em VerificarEGravarDataInicialSeNecessarioAsync.
    /// </summary>
    Task AtualizarDataAtualizacaoAsync(DateTime dataAtualizacaoCorreios);

    /// <summary>
    /// Consulta a API dos Correios para obter a data atual e grava no banco.
    /// Use quando não houver data disponível de verificação prévia (ex: jobs independentes).
    /// </summary>
    Task AtualizarDataAtualizacaoAsync();
}
