using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Uninter.Correios.Domain.Request.ConfiguracaoAplicacao;
using Uninter.Correios.Domain.Response.ConfiguracaoAplicacao;

namespace Uninter.Correios.Domain.Interfaces.Service;

public interface ICorreiosConfiguracaoService
{
    Task<IEnumerable<CorreiosConfiguracaoResponse>> ListarTodosAsync();
    Task<CorreiosConfiguracaoResponse> ObterPorIdAsync(int id);
    Task<int> InserirAsync(CorreiosConfiguracaoInserirRequest request);
    Task AtualizarAsync(int id, string token, string? observacao = null);
    Task ExcluirLogicoAsync(int id);

    /// <summary>
    /// Recarrega o cache de token dos Correios a partir do banco de dados
    /// e retorna a nova data de expiração do token em cache.
    /// </summary>
    Task<DateTime?> RecarregarTokenCacheAsync();
}
