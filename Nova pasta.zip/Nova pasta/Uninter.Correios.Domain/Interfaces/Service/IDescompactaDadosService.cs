using System.Threading.Tasks;
using Hangfire.Server;

namespace Uninter.Correios.Domain.Interfaces.Service;

/// <summary>
/// Serviço responsável pela descompactação de arquivos ZIP.
/// </summary>
public interface IDescompactaDadosService
{
    /// <summary>
    /// Descompacta todos os arquivos ZIP da pasta de rede para a pasta de entrada.
    /// </summary>
    /// <param name="context">Contexto do Hangfire para exibir progresso (opcional)</param>
    Task UnzipAsync(PerformContext context = null);
}
