using System;
using System.Threading.Tasks;
using Uninter.Correios.Domain.Enum;
using Uninter.Correios.Domain.Models;

namespace Uninter.Correios.Domain.Interfaces.Service;

/// <summary>
/// Serviço para envio de notificações por email sobre eventos do sistema.
/// Todos os tipos compartilham um único template e um único método de envio,
/// diferenciando-se apenas pelos dados que compõem o conteúdo.
/// </summary>
public interface IEmailNotificationService
{
    /// <summary>
    /// Envia uma notificação por email do tipo informado.
    /// O assunto e o conteúdo são montados internamente conforme o tipo.
    /// </summary>
    Task EnviarEmailAsync(TipoNotificacaoEmail tipo, EmailDadosNotificacao dados);

    /// <summary>
    /// Verifica se o token está dentro da janela de antecedência configurada
    /// e dispara o email de expiração quando aplicável.
    /// </summary>
    Task VerificarEEnviarEmailTokenExpiracaoAsync(DateTime dataExpiracao);
}
