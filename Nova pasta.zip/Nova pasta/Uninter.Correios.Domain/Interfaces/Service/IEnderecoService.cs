#nullable enable

using System.Threading.Tasks;
using Uninter.Correios.Domain.Request.Api;
using Uninter.Correios.Domain.Response.Api;

namespace Uninter.Correios.Domain.Interfaces.Service;

/// <summary>
/// Interface para serviço de consulta de endereços.
/// </summary>
public interface IEnderecoService
{
    /// <summary>
    /// Lista endereços com base em filtros (UF, localidade, bairro, logradouro).
    /// </summary>
    /// <param name="queryParams">Parâmetros de filtro e paginação.</param>
    /// <returns>Resultado paginado com lista de endereços encontrados.</returns>
    Task<(PagedModelEnderecoResponse? Resultado, string? Erro)> ListarEnderecosAsync(
        ListaEnderecosQueryParams queryParams);
}
