using System.Threading.Tasks;
using Hangfire.Server;

namespace Uninter.Correios.Domain.Interfaces.Service;

/// <summary>
/// Interface para envio de dados JSON para fila RabbitMQ.
/// </summary>
public interface IEnviarDadosJsonRabbitMQService
{
    /// <summary>
    /// Lê os arquivos JSON da pasta e processa para envio ao RabbitMQ.
    /// </summary>
    /// <param name="context">Contexto do Hangfire para logs no dashboard</param>
    Task ProcessarArquivosJsonAsync(PerformContext? context = null);
}
