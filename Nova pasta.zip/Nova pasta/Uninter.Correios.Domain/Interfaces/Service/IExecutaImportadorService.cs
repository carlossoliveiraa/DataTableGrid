using System.Threading.Tasks;
using Hangfire.Server;
using Uninter.Correios.Domain.Models;

namespace Uninter.Correios.Domain.Interfaces.Service;

/// <summary>
/// Serviço responsável pela execução da importação dos dados do eDNE V3.
/// </summary>
public interface IExecutaImportadorService
{
    /// <summary>
    /// Executa a importação completa dos arquivos do eDNE V3.
    /// </summary>
    /// <param name="context">Contexto do Hangfire para exibir progresso (opcional)</param>
    Task<ImportacaoResultado> ExecutarAsync(PerformContext context = null);
    
    /// <summary>
    /// Executa a importação dos arquivos de uma subpasta específica (Full ou Delta).
    /// </summary>
    /// <param name="tipoImportacao">Tipo de importação: "full" ou "delta"</param>
    /// <param name="context">Contexto do Hangfire para exibir progresso (opcional)</param>
    Task<ImportacaoResultado> ExecutarPorTipoAsync(string tipoImportacao, PerformContext context = null);
}
