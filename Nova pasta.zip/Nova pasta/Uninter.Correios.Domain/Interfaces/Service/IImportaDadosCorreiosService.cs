using System.Threading.Tasks;
using Hangfire.Server;

namespace Uninter.Correios.Domain.Interfaces.Service;

/// <summary>
/// Serviço responsável pelo download dos arquivos dos Correios.
/// </summary>
public interface IImportaDadosCorreiosService
{
    /// <summary>
    /// Faz o download do arquivo ZIP dos Correios e extrai na pasta de trabalho.
    /// </summary>
    /// <param name="context">Contexto do Hangfire para exibir progresso (opcional)</param>
    Task DownloadAsync(PerformContext context = null);

    /// <summary>
    /// Faz o download e já executa a importação em sequência.
    /// </summary>
    /// <param name="context">Contexto do Hangfire para exibir progresso (opcional)</param>
    Task DownloadEExecutarAsync(PerformContext context = null);
}
