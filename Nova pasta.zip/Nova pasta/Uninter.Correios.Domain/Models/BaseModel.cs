using System;

/// <summary>
/// Classe base para todas as entidades do domínio.
/// </summary>
/// <remarks>
/// Contém propriedades comuns que são herdadas por outras entidades, como informações de criação e atualização.
/// </remarks>
public class BaseModel
{
    /// <summary>
    /// Data de criação do registro.
    /// </summary>
    public DateTime DataCriacao { get; set; }

    /// <summary>
    /// Identificador do usuário que criou o registro.
    /// </summary>
    public int CriadoPor { get; set; }

    /// <summary>
    /// Data da última alteração do registro.
    /// </summary>
    public DateTime? DataAlteracao { get; set; }

    /// <summary>
    /// Identificador do usuário que realizou a última alteração.
    /// </summary>
    public int? AtualizadoPor { get; set; }
}
