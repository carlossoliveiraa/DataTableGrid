using System;
using Uninter.Correios.CrossCutting.Constants;
using Uninter.Correios.CrossCutting.Extensions;

namespace Uninter.Correios.Domain.Models;

/// <summary>
/// Entidade que armazena a configuração de autenticação da API dos Correios.
/// </summary>
public class CorreiosConfiguracao
{
    public int Id { get; set; }
    public string Token { get; set; } = string.Empty;
    public string EnderecoIp { get; set; } = string.Empty;
    public DateTime CriadoEm { get; set; }
    public DateTime AtualizadoEm { get; set; }
    public DateTime ExpiraEm { get; set; }
    public bool Ativo { get; set; }
    public string Observacao { get; set; }
    public string CriadoPor { get; set; }
    public DateTime? DataAtualizacaoCorreios { get; set; }

    /// <summary>
    /// Verifica se o token está expirado.
    /// </summary>
    public bool EstaExpirado() => ExpiraEm.IsExpired();

    /// <summary>
    /// Verifica se o token é válido (ativo e não expirado).
    /// </summary>
    public bool EstaValido() => Ativo && !EstaExpirado();

    /// <summary>
    /// Retorna quantos dias faltam para o token expirar.
    /// </summary>
    public int DiasParaExpirar() => ExpiraEm.DaysUntil();

    /// <summary>
    /// Verifica se o token está próximo de expirar (conforme constante configurada).
    /// </summary>
    public bool ProximoDeExpirar() => ExpiraEm.IsExpiringWithin(CorreiosConstants.TOKEN_EXPIRATION_WARNING_DAYS);
}
