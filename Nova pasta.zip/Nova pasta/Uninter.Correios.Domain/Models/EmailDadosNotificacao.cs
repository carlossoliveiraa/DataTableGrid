using System;

namespace Uninter.Correios.Domain.Models;

/// <summary>
/// Dados opcionais que podem compor o conteúdo de uma notificação por email.
/// Cada tipo de notificação utiliza apenas os campos que lhe são relevantes.
/// </summary>
public class EmailDadosNotificacao
{
    // Comuns
    public string NomeArquivo { get; set; }

    // NovaImportacao
    public DateTime? DataImportacao { get; set; }
    public int QuantidadeRegistros { get; set; }
    public TimeSpan TempoProcessamento { get; set; }

    // FalhaExecucao
    public DateTime? DataFalha { get; set; }
    public string MensagemErro { get; set; }
    public string StackTrace { get; set; }

    // TokenExpiracao
    public DateTime? DataExpiracao { get; set; }
    public int DiasRestantes { get; set; }
}
