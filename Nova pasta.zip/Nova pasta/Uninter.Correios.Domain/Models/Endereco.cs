using System.Collections.Generic;

namespace Uninter.Correios.Domain.Models;

/// <summary>
/// Representa um endereço retornado pela API dos Correios.
/// </summary>
public class Endereco
{
    public string Cep { get; set; } = string.Empty;
    public string Uf { get; set; } = string.Empty;
    public string Localidade { get; set; } = string.Empty;
    public string Bairro { get; set; }
    public string Logradouro { get; set; }
    public string TipoLogradouro { get; set; }
    public string Complemento { get; set; }
    public int? NumeroLocalidade { get; set; }
    public int? TipoCep { get; set; }
    public string Lado { get; set; }
    public int? NumeroInicial { get; set; }
    public int? NumeroFinal { get; set; }
    public string NomeLogradouro { get; set; }
    public string Abreviatura { get; set; }
    public string CodigoIbge { get; set; }

    /// <summary>
    /// Retorna o endereço completo formatado.
    /// </summary>
    public string ObterEnderecoCompleto()
    {
        var partes = new List<string>();

        if (!string.IsNullOrEmpty(TipoLogradouro))
            partes.Add(TipoLogradouro);

        if (!string.IsNullOrEmpty(Logradouro))
            partes.Add(Logradouro);

        if (!string.IsNullOrEmpty(Complemento))
            partes.Add($"- {Complemento}");

        if (!string.IsNullOrEmpty(Bairro))
            partes.Add($", {Bairro}");

        if (!string.IsNullOrEmpty(Localidade))
            partes.Add($", {Localidade}");

        if (!string.IsNullOrEmpty(Uf))
            partes.Add($"- {Uf}");

        if (!string.IsNullOrEmpty(Cep))
            partes.Add($"CEP: {FormatarCep(Cep)}");

        return string.Join(" ", partes);
    }

    /// <summary>
    /// Formata o CEP com hífen (00000-000).
    /// </summary>
    public static string FormatarCep(string cep)
    {
        if (string.IsNullOrEmpty(cep) || cep.Length != 8)
            return cep;

        return $"{cep.Substring(0, 5)}-{cep.Substring(5)}";
    }

    /// <summary>
    /// Verifica se o endereço possui numeração.
    /// </summary>
    public bool PossuiNumeracao() => NumeroInicial.HasValue || NumeroFinal.HasValue;

    /// <summary>
    /// Retorna a faixa de numeração formatada.
    /// </summary>
    public string ObterFaixaNumeracao()
    {
        if (!NumeroInicial.HasValue && !NumeroFinal.HasValue)
            return null;

        if (NumeroInicial.HasValue && NumeroFinal.HasValue)
            return $"{NumeroInicial} a {NumeroFinal}";

        if (NumeroInicial.HasValue)
            return $"A partir de {NumeroInicial}";

        return $"Até {NumeroFinal}";
    }
}
