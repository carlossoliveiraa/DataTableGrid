using Uninter.Correios.CrossCutting.Helpers;

namespace Uninter.Correios.Domain.Models.ImportV2
{
    public class Bairro
    {
        public Bairro() { }

        public int BaiNu { get; set; }
        public string UfeSg { get; set; }
        public int LocNu { get; set; }
        public string BaiNo { get; set; }
        public string BaiNoAbrev { get; set; }

        /// <summary>
        /// Calcula SHA256 hash de todos os campos para detecção de mudanças
        /// </summary>
        public string CalcularHash()
        {
            return HashCalculator.CalcularHashRegistro(
                BaiNu,
                UfeSg,
                LocNu,
                BaiNo,
                BaiNoAbrev
            );
        }
    }
}