using Uninter.Correios.CrossCutting.Helpers;

namespace Uninter.Correios.Domain.Models.ImportV2
{
    public class CaixaPostal
    {
        public CaixaPostal() { }

        public int CpcNu { get; set; }
        public string UfeSg { get; set; }
        public int LocNu { get; set; }
        public string CpcNo { get; set; }
        public string CpcEndereco { get; set; }
        public string Cep { get; set; }

        /// <summary>
        /// Calcula SHA256 hash de todos os campos para detecção de mudanças
        /// </summary>
        public string CalcularHash()
        {
            return HashCalculator.CalcularHashRegistro(
                CpcNu,
                UfeSg,
                LocNu,
                CpcNo,
                CpcEndereco,
                Cep
            );
        }
    }
}