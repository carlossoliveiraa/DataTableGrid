using Uninter.Correios.CrossCutting.Helpers;

namespace Uninter.Correios.Domain.Models.ImportV2
{
    public class GrdUsuario
    {
        public GrdUsuario() { }

        public int GruNu { get; set; }
        public string UfeSg { get; set; }
        public int LocNu { get; set; }
        public int BaiNu { get; set; }
        public int? LogNu { get; set; }
        public string GruNo { get; set; }
        public string GruEndereco { get; set; }
        public string Cep { get; set; }
        public string GruNoAbrev { get; set; }

        /// <summary>
        /// Calcula SHA256 hash de todos os campos para detecção de mudanças
        /// </summary>
        public string CalcularHash()
        {
            return HashCalculator.CalcularHashRegistro(
                GruNu,
                UfeSg,
                LocNu,
                BaiNu,
                LogNu,
                GruNo,
                GruEndereco,
                Cep,
                GruNoAbrev
            );
        }
    }
}