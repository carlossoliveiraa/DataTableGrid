using Uninter.Correios.CrossCutting.Helpers;

namespace Uninter.Correios.Domain.Models.ImportV2
{
    public class Localidade
    {
        public Localidade() { }

        public int LocNu { get; set; }
        public string UfeSg { get; set; }
        public string LocNo { get; set; }
        public string Cep { get; set; }
        public string LocInSit { get; set; }
        public string LocInTipoLoc { get; set; }
        public int LocNuSub { get; set; }
        public string LocNoAbrev { get; set; }
        public int MunNu { get; set; }

        /// <summary>
        /// Calcula SHA256 hash de todos os campos para detecção de mudanças
        /// </summary>
        public string CalcularHash()
        {
            return HashCalculator.CalcularHashRegistro(
                LocNu,
                UfeSg,
                LocNo,
                Cep,
                LocInSit,
                LocInTipoLoc,
                LocNuSub,
                LocNoAbrev,
                MunNu
            );
        }
    }
}