using Uninter.Correios.CrossCutting.Helpers;

namespace Uninter.Correios.Domain.Models.ImportV2
{
    public class Logradouro
    {
        public Logradouro() { }

        public int LogNu { get; set; }
        public string UfeSg { get; set; }
        public int LocNu { get; set; }
        public int BaiNuIni { get; set; }
        public int BaiNuFim { get; set; }
        public string LogNo { get; set; }
        public string LogComplemento { get; set; }
        public string Cep { get; set; }
        public string TloTx { get; set; }
        public string LogStaTlo { get; set; }
        public string LogNoAbrev { get; set; }

        /// <summary>
        /// Calcula SHA256 hash de todos os campos para detecção de mudanças
        /// </summary>
        public string CalcularHash()
        {
            return HashCalculator.CalcularHashRegistro(
                LogNu,
                UfeSg,
                LocNu,
                BaiNuIni,
                BaiNuFim,
                LogNo,
                LogComplemento,
                Cep,
                TloTx,
                LogStaTlo,
                LogNoAbrev
            );
        }
    }
}