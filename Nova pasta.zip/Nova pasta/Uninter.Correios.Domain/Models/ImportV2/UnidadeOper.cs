using Uninter.Correios.CrossCutting.Helpers;

namespace Uninter.Correios.Domain.Models.ImportV2
{
    public class UnidadeOper
    {
        public UnidadeOper() { }

        public int UopNu { get; set; }
        public string UfeSg { get; set; }
        public int LocNu{ get; set; }
        public int BaiNu { get; set; }
        public int? LogNu { get; set; }
        public string UopNo { get; set; }
        public string UopEndereco { get; set; }
        public string Cep { get; set; }
        public string UopInCp { get; set; }
        public string UopNoAbrev { get; set; }

        /// <summary>
        /// Calcula SHA256 hash de todos os campos para detecção de mudanças
        /// </summary>
        public string CalcularHash()
        {
            return HashCalculator.CalcularHashRegistro(
                UopNu,
                UfeSg,
                LocNu,
                BaiNu,
                LogNu,
                UopNo,
                UopEndereco,
                Cep,
                UopInCp,
                UopNoAbrev
            );
        }
    }
}