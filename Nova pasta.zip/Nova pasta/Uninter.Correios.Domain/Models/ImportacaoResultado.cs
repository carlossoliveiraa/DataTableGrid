namespace Uninter.Correios.Domain.Models;

/// <summary>
/// Resultado consolidado de uma execução de importação dos Correios.
/// </summary>
public sealed record ImportacaoResultado(
    int TotalInseridos,
    int TotalAtualizados,
    int TotalInalterados)
{
    /// <summary>
    /// Soma de inseridos + atualizados + inalterados.
    /// </summary>
    public int TotalProcessados => TotalInseridos + TotalAtualizados + TotalInalterados;

    public static ImportacaoResultado Vazio => new(0, 0, 0);
}
