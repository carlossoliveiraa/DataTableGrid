using System.Collections.Generic;

namespace Uninter.Correios.Domain.Models;

public class ResultadoPaginado<TEntity>
{
    public IEnumerable<TEntity> Registros { get; set; }
    public int NumeroPagina { get; set; }
    public int TamanhoPagina { get; set; }
    public int TotalRegistros { get; set; }
    public int TotalPaginas { get; set; }
}
