namespace Uninter.Correios.Domain.Request.Api;

/// <summary>
/// Comando para autenticação via RU na Account API
/// </summary>
public class AuthenticateRuCommand
{
    public int ru { get; set; }
    public string senha { get; set; }
    public string sistema { get; set; }
    public string recaptchaToken { get; set; }
}
