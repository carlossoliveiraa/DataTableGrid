#pragma warning disable CS8632
using System.Collections.Generic;

namespace Uninter.Correios.Domain.Request.Api;

/// <summary>
/// Parâmetros de consulta para listar endereços na API dos Correios.
/// Baseado na documentação oficial da API v2 dos Correios.
/// </summary>
public class ListaEnderecosQueryParams
{
    // ========================================
    // FILTROS PRINCIPAIS
    // ========================================

    /// <summary>
    /// Lista de CEPs para filtrar. Ex: ["01310100", "01310200"]
    /// </summary>
    public List<string>? Cep { get; set; }

    /// <summary>
    /// Unidade Federativa (sigla). Ex: "SP", "RJ"
    /// </summary>
    public string? Uf { get; set; }

    /// <summary>
    /// Nome da localidade/cidade. Ex: "São Paulo"
    /// </summary>
    public string? Localidade { get; set; }

    /// <summary>
    /// Nome do bairro.
    /// </summary>
    public string? Bairro { get; set; }

    /// <summary>
    /// Nome do logradouro (APENAS nome da rua, SEM números ou vírgulas).
    /// Ex: "Paulista" (correto) vs "Paulista, 100" (incorreto)
    /// </summary>
    public string? Logradouro { get; set; }

    /// <summary>
    /// Tipo do logradouro. Ex: "Rua", "Avenida", "Travessa"
    /// </summary>
    public string? TipoLogradouro { get; set; }

    // ========================================
    // FILTROS AVANÇADOS
    // ========================================

    /// <summary>
    /// Sigla da unidade operacional dos Correios.
    /// </summary>
    public string? SiglaUnidade { get; set; }

    /// <summary>
    /// Tipo do CEP. Ex: 1 = Logradouro, 2 = Localidade, etc.
    /// </summary>
    public int? TipoCEP { get; set; }

    /// <summary>
    /// Filtro por Clique (agência de atendimento).
    /// </summary>
    public string? Clique { get; set; }

    /// <summary>
    /// Filtro por Caixa Postal.
    /// </summary>
    public string? CaixaPostal { get; set; }

    /// <summary>
    /// Filtro por Locker.
    /// </summary>
    public string? Locker { get; set; }

    /// <summary>
    /// Filtro por Agência Modular.
    /// </summary>
    public string? AgenciaModular { get; set; }

    /// <summary>
    /// CEP inicial para filtro de faixa.
    /// </summary>
    public string? CepInicial { get; set; }

    /// <summary>
    /// CEP final para filtro de faixa.
    /// </summary>
    public string? CepFinal { get; set; }

    /// <summary>
    /// Número do bairro (código interno).
    /// </summary>
    public int? NumeroBairro { get; set; }

    /// <summary>
    /// Número da caixa postal.
    /// </summary>
    public int? NumeroCaixaPostal { get; set; }

    // ========================================
    // PAGINAÇÃO
    // ========================================

    /// <summary>
    /// Número da página (começa em 0). Padrão: 0
    /// </summary>
    public int Page { get; set; } = 0;

    /// <summary>
    /// Quantidade de itens por página. Padrão: 50, Máximo: 2000
    /// </summary>
    public int Size { get; set; } = 50;

    /// <summary>
    /// Ordenação dos resultados. Ex: ["logradouro,asc", "uf,desc"]
    /// </summary>
    public List<string>? Sort { get; set; }
}
