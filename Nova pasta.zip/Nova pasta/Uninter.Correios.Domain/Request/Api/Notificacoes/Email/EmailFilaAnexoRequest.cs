namespace Uninter.Correios.Domain.Request.Api.Notificacoes.Email;

public class EmailFilaAnexoRequest
{
    public string CaminhoAbsolutoArquivo { get; set; }
}
