using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace Uninter.Correios.Domain.Request.Api.Notificacoes.Email;

public class EmailFilaPersonalizadoRequest
{
    public string Destinatario { get; set; }

    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public string ResponderPara { get; set; }

    public string NomeTemplate { get; set; }
    public string JsonReplaceVariaveis { get; set; } = string.Empty;

    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public DateTime? AgendarEnvioPara { get; set; }

    public IEnumerable<EmailFilaAnexoRequest> Anexos { get; set; }
}
