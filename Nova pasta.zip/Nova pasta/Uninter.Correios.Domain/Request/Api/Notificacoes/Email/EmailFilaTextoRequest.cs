using System.Collections.Generic;

namespace Uninter.Correios.Domain.Request.Api.Notificacoes.Email;

public class EmailFilaTextoRequest
{
    public string Assunto { get; set; }
    public string Destinatario { get; set; }
    public string ConteudoTexto { get; set; }
    public string NomeSistemaOrigem { get; set; }
    public IEnumerable<EmailFilaAnexoRequest> Anexos { get; set; }
}
