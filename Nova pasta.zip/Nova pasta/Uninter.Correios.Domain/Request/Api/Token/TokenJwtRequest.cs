namespace Uninter.Correios.Domain.Request.Api.Token;

public record TokenJwtRequest
(
    string UserName
);
