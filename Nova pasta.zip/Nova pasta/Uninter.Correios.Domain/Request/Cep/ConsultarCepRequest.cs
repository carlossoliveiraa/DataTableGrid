namespace Uninter.Correios.Domain.Request.Cep;

/// <summary>
/// Request para consulta de CEP.
/// </summary>
public record ConsultarCepRequest
(
    string Cep
);
