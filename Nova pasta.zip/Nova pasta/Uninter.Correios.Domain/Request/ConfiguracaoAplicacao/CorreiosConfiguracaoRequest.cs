using System;
using Uninter.Correios.CrossCutting.Extensions;
using Uninter.Correios.CrossCutting.Helpers;

namespace Uninter.Correios.Domain.Request.ConfiguracaoAplicacao;

public class CorreiosConfiguracaoInserirRequest
{
    public string Token { get; }
    public string EnderecoIp { get; }
    public DateTime ExpiraEm { get; }
    public string? Observacao { get; }
    public string? CriadoPor { get; }

    public CorreiosConfiguracaoInserirRequest(string token, string? observacao = null, string? criadoPor = null)
    {
        if (string.IsNullOrWhiteSpace(token))
            throw new ArgumentException("Token é obrigatório.", nameof(token));

        Token = token.CleanTokenValue();
        EnderecoIp = NetworkHelper.GetLocalIPAddress();
        ExpiraEm = token.TryGetJwtExpiration() ?? DateTime.Now.AddDays(180);
        Observacao = observacao;
        CriadoPor = criadoPor;
    }
}

public class CorreiosConfiguracaoAtualizarRequest
{
    public string Token { get; }
    public string EnderecoIp { get; }
    public DateTime ExpiraEm { get; }
    public string? Observacao { get; }

    public CorreiosConfiguracaoAtualizarRequest(string token, string? observacao = null)
    {
        if (string.IsNullOrWhiteSpace(token))
            throw new ArgumentException("Token é obrigatório.", nameof(token));

        Token = token.CleanTokenValue();
        EnderecoIp = NetworkHelper.GetLocalIPAddress();
        ExpiraEm = token.TryGetJwtExpiration() ?? DateTime.Now.AddDays(180);
        Observacao = observacao;
    }
}
