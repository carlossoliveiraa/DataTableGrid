using System.Text.Json.Serialization;

namespace Uninter.Correios.Domain.Request.Token;

public class TokenJwtRequest
{
    [JsonPropertyName("userName")]
    public string UserName { get; set; }
}
