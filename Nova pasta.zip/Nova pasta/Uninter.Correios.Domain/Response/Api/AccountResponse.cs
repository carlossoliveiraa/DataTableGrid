using Newtonsoft.Json;

namespace Uninter.Correios.Domain.Response.Api;

/// <summary>
/// Resposta da autenticação na Account API
/// </summary>
public class AccountResponse
{
    [JsonProperty("token")]
    public string Token { get; set; }

    [JsonProperty("expires")]
    public int Expires { get; set; }
}
