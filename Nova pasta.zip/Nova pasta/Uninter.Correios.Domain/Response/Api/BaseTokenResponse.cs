namespace Uninter.Correios.Domain.Response.Api;

public record BaseTokenResponse(
    string AccessToken,
    string TokenType,
    int ExpiresIn
);
