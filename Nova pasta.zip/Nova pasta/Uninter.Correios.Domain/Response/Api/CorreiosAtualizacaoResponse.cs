using System;
using System.Text.Json.Serialization;

namespace Uninter.Correios.Domain.Response.Api;

/// <summary>
/// Response da API dos Correios para verificação de atualização.
/// Endpoint: GET /cep/v1/atualizacao
/// </summary>
public class CorreiosAtualizacaoResponse
{
    /// <summary>
    /// Data da última atualização disponível na API dos Correios.
    /// </summary>
    [JsonPropertyName("atualizadoEm")]
    public DateTime AtualizadoEm { get; set; }

    /// <summary>
    /// Verifica se a data retornada é mais recente que uma data de referência.
    /// </summary>
    public bool EhMaisRecenteQue(DateTime? dataReferencia)
    {
        if (!dataReferencia.HasValue)
            return true; // Se não tem data de referência, sempre é mais recente

        return AtualizadoEm > dataReferencia.Value;
    }
}
