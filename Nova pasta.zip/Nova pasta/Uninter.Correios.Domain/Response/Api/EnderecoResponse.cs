using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Uninter.Correios.Domain.Response.Api;

/// <summary>
/// Response da API dos Correios para consulta de CEP individual.
/// </summary>
public class EnderecoResponse
{
    [JsonPropertyName("cep")]
    public string Cep { get; set; }

    [JsonPropertyName("uf")]
    public string Uf { get; set; }

    [JsonPropertyName("localidade")]
    public string Localidade { get; set; }

    [JsonPropertyName("locNoSem")]
    public string LocalidadeSemAcentuacao { get; set; }

    [JsonPropertyName("locNu")]
    public int? NumeroLocalidade { get; set; }

    [JsonPropertyName("localidadeSubordinada")]
    public string LocalidadeSubordinada { get; set; }

    [JsonPropertyName("logradouro")]
    public string Logradouro { get; set; }

    [JsonPropertyName("tipoLogradouro")]
    public string TipoLogradouro { get; set; }

    [JsonPropertyName("logradouroDNEC")]
    public string LogradouroDNEC { get; set; }

    [JsonPropertyName("logradouroTextoAdicional")]
    public string LogradouroTextoAdicional { get; set; }

    [JsonPropertyName("logradouroTexto")]
    public string LogradouroTexto { get; set; }

    [JsonPropertyName("complemento")]
    public string Complemento { get; set; }

    [JsonPropertyName("bairro")]
    public string Bairro { get; set; }

    [JsonPropertyName("baiNu")]
    public int? NumeroBairro { get; set; }

    [JsonPropertyName("nomeUnidade")]
    public string NomeUnidade { get; set; }

    [JsonPropertyName("tipoCep")]
    public int? TipoCep { get; set; }

    [JsonPropertyName("numeroLocalidade")]
    public int? NumeroLocalidadeAlternativo { get; set; }

    [JsonPropertyName("situacao")]
    public string Situacao { get; set; }

    [JsonPropertyName("tipoCPFavorecido")]
    public List<int> TiposCPFavorecidos { get; set; }

    [JsonPropertyName("lado")]
    public string Lado { get; set; }

    [JsonPropertyName("numeroInicial")]
    public int? NumeroInicial { get; set; }

    [JsonPropertyName("numeroFinal")]
    public int? NumeroFinal { get; set; }

    [JsonPropertyName("nomeLogradouro")]
    public string NomeLogradouro { get; set; }

    [JsonPropertyName("abreviatura")]
    public string Abreviatura { get; set; }

    [JsonPropertyName("codigoIbge")]
    public string CodigoIbge { get; set; }
}
