#pragma warning disable CS8632
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Uninter.Correios.Domain.Response.Api;

/// <summary>
/// Response paginado da API dos Correios v2 para listagem de endereços.
/// Inclui informações de paginação e links HATEOAS.
/// </summary>
public class PagedModelEnderecoResponse
{
    /// <summary>
    /// Lista de endereços retornados.
    /// </summary>
    [JsonPropertyName("itens")]
    public List<EnderecoItemResponse> Itens { get; set; } = new();

    /// <summary>
    /// Links HATEOAS para navegação entre páginas.
    /// </summary>
    [JsonPropertyName("links")]
    public List<LinkResponse> Links { get; set; } = new();

    /// <summary>
    /// Informações de paginação (total de elementos, páginas, etc).
    /// </summary>
    [JsonPropertyName("page")]
    public PagedModelInfo Page { get; set; } = new();
}

/// <summary>
/// Item individual de endereço na lista.
/// </summary>
public class EnderecoItemResponse
{
    [JsonPropertyName("cep")]
    public string Cep { get; set; } = string.Empty;

    [JsonPropertyName("uf")]
    public string Uf { get; set; } = string.Empty;

    [JsonPropertyName("numeroLocalidade")]
    public int? NumeroLocalidade { get; set; }

    [JsonPropertyName("localidade")]
    public string Localidade { get; set; }

    [JsonPropertyName("logradouro")]
    public string Logradouro { get; set; }

    [JsonPropertyName("tipoLogradouro")]
    public string TipoLogradouro { get; set; }

    [JsonPropertyName("nomeLogradouro")]
    public string NomeLogradouro { get; set; }

    [JsonPropertyName("numeroLogradouro")]
    public string NumeroLogradouro { get; set; }

    [JsonPropertyName("complemento")]
    public string Complemento { get; set; }

    [JsonPropertyName("abreviatura")]
    public string Abreviatura { get; set; }

    [JsonPropertyName("bairro")]
    public string Bairro { get; set; }

    [JsonPropertyName("distrito")]
    public string Distrito { get; set; }

    [JsonPropertyName("numeroLocalidadeSuperior")]
    public int? NumeroLocalidadeSuperior { get; set; }

    [JsonPropertyName("localidadeSuperior")]
    public string LocalidadeSuperior { get; set; }

    [JsonPropertyName("nome")]
    public string Nome { get; set; }

    [JsonPropertyName("siglaUnidade")]
    public string SiglaUnidade { get; set; }

    [JsonPropertyName("tipoCEP")]
    public int? TipoCEP { get; set; }

    [JsonPropertyName("cepAnterior")]
    public string CepAnterior { get; set; }

    [JsonPropertyName("cepUnidadeOperacional")]
    public string CepUnidadeOperacional { get; set; }

    [JsonPropertyName("lado")]
    public string Lado { get; set; }

    [JsonPropertyName("numeroInicial")]
    public long? NumeroInicial { get; set; }

    [JsonPropertyName("numeroFinal")]
    public long? NumeroFinal { get; set; }

    [JsonPropertyName("clique")]
    public string Clique { get; set; }

    [JsonPropertyName("caixasPostais")]
    public List<FaixaCaixaPostalResponse> CaixasPostais { get; set; }

    [JsonPropertyName("locker")]
    public string Locker { get; set; }

    [JsonPropertyName("agenciaModular")]
    public string AgenciaModular { get; set; }

    [JsonPropertyName("codigoIbge")]
    public string CodigoIbge { get; set; }

    [JsonPropertyName("txMsg")]
    public string TxMsg { get; set; }

    [JsonPropertyName("inSituacaoLocalidade")]
    public string InSituacaoLocalidade { get; set; }

    [JsonPropertyName("dtFinalVigencia")]
    public DateTime? DtFinalVigencia { get; set; }
}

/// <summary>
/// Faixa de caixa postal.
/// </summary>
public class FaixaCaixaPostalResponse
{
    [JsonPropertyName("nuInicial")]
    public int NuInicial { get; set; }

    [JsonPropertyName("nuFinal")]
    public int NuFinal { get; set; }
}

/// <summary>
/// Informações de paginação do resultado.
/// </summary>
public class PagedModelInfo
{
    [JsonPropertyName("size")]
    public long Size { get; set; }

    [JsonPropertyName("totalElements")]
    public long TotalElements { get; set; }

    [JsonPropertyName("totalPages")]
    public long TotalPages { get; set; }

    [JsonPropertyName("number")]
    public long Number { get; set; }
}

/// <summary>
/// Link HATEOAS para navegação.
/// </summary>
public class LinkResponse
{
    [JsonPropertyName("href")]
    public string Href { get; set; }

    [JsonPropertyName("hreflang")]
    public string Hreflang { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("type")]
    public string Type { get; set; }

    [JsonPropertyName("deprecation")]
    public string Deprecation { get; set; }

    [JsonPropertyName("profile")]
    public string Profile { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; }

    [JsonPropertyName("templated")]
    public bool Templated { get; set; }
}
