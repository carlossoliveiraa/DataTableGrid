namespace Uninter.Correios.Domain.Response.Api;

/// <summary>
/// Wrapper padrão de resposta das APIs
/// </summary>
/// <typeparam name="T">Tipo de dados da resposta</typeparam>
public class ResponseApi<T>
{
    public bool Success { get; set; }
    public T Data { get; set; }
    public string[] Errors { get; set; }
}
