namespace Uninter.Correios.Domain.Response.Api;

public record ResponseApiResponse<T>
(
    bool Success,
    T Data
);
