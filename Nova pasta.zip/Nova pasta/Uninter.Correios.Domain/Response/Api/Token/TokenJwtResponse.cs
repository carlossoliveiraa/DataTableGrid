using System;

namespace Uninter.Correios.Domain.Response.Api.Token;

public record TokenJwtResponse
(
    string Token,
    DateTime Expiration
);
