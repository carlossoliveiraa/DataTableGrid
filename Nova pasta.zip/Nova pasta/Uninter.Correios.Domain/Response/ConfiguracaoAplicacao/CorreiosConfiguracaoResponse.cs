using System;

namespace Uninter.Correios.Domain.Response.ConfiguracaoAplicacao;

public class CorreiosConfiguracaoResponse
{
    public int Id { get; set; }
    public string Token { get; set; }
    public string EnderecoIp { get; set; }
    public DateTime CriadoEm { get; set; }
    public DateTime AtualizadoEm { get; set; }
    public DateTime ExpiraEm { get; set; }
    public bool Ativo { get; set; }
    public string Observacao { get; set; }
    public string CriadoPor { get; set; }
    public DateTime? DataAtualizacaoCorreios { get; set; }
    public bool EstaExpirado { get; set; }
    public int DiasParaExpirar { get; set; }
}
