using System.Collections.Generic;

namespace Uninter.Correios.Domain.Response;

/// <summary>
/// Response padrão para retorno de mensagens de erro ou sucesso.
/// </summary>
public class MessageResponse
{
    /// <summary>
    /// Lista de mensagens.
    /// </summary>
    public List<string> Msgs { get; set; } = new();
}
