using System;
using System.Text.Json.Serialization;

namespace Uninter.Correios.Domain.Response.Token;

public class TokenJwtResponse
{
    [JsonPropertyName("token")]
    public string Token { get; set; }

    [JsonPropertyName("expiration")]
    public DateTime Expiration { get; set; }
}

public class TokenApiResponse
{
    [JsonPropertyName("success")]
    public bool Success { get; set; }

    [JsonPropertyName("data")]
    public TokenJwtResponse Data { get; set; }
}
