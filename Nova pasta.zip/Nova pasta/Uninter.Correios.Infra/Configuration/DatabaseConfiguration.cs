namespace Uninter.Correios.Infra.Configuration;

public static class DatabaseConfiguration
{
    public static string TemplateConnection { get; set; }
    public static string PermissaoConnection { get; set; }
    public static string HangfireConnection { get; set; }
    public static string ZipCodeConnection { get; set; }
}
