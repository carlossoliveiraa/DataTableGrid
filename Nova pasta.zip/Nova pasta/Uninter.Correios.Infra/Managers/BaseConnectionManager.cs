using System;
using System.Data;

namespace Uninter.Correios.Infra.Managers;

public abstract class BaseConnectionManager(IDbConnection dbConnection) : IDisposable
{
    public Lazy<IDbConnection> conn = new(() => OpenConnection(dbConnection));
    public IDbTransaction trans;
    public ConnType type = ConnType.Single;

    public void BeginMultiTransaction()
    {
        type = ConnType.Multiple;
        if (trans == null || trans.Connection == null)
            trans = conn.Value.BeginTransaction();
    }

    public void BeginTransaction()
    {
        if (trans == null || trans.Connection == null)
            trans = conn.Value.BeginTransaction();
    }

    public void Rollback()
    {
        trans.Rollback();
    }

    public void CommitAll()
    {
        try
        {
            trans.Commit();
        }
        catch
        {
            trans.Rollback();
            throw;
        }
        finally
        {
            trans.Dispose();
            trans = null;
        }
    }

    public void Commit()
    {
        if (type == ConnType.Multiple)
            return;
        try
        {
            trans.Commit();
        }
        catch
        {
            trans.Rollback();
            throw;
        }
        finally
        {
            trans.Dispose();
            trans = null;
        }
    }

    public void Dispose()
    {
        trans?.Dispose();
        trans = null;

        conn?.Value.Dispose();
        conn = null;
        GC.SuppressFinalize(this);
    }

    public enum ConnType
    {
        Single,
        Multiple
    }

    private static IDbConnection OpenConnection(IDbConnection connection)
    {
        if (connection.State != ConnectionState.Open) connection.Open();

        return connection;
    }
}
