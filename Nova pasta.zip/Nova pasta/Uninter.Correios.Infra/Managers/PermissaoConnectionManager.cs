using System.Data;

namespace Uninter.Correios.Infra.Managers;

public class PermissaoConnectionManager(IDbConnection dbConnection) : BaseConnectionManager(dbConnection) { }
