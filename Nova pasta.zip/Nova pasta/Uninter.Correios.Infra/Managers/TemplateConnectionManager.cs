using System.Data;

namespace Uninter.Correios.Infra.Managers;

public class TemplateConnectionManager(IDbConnection dbConnection) : BaseConnectionManager(dbConnection) { }
