using System.Data;

namespace Uninter.Correios.Infra.Managers;

public class ZipCodeConnectionManager(IDbConnection dbConnection) : BaseConnectionManager(dbConnection) { }
