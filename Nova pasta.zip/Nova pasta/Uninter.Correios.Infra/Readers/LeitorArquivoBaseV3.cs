using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Uninter.Correios.Infra.Readers;

/// <summary>
/// Leitor V3 - Zero Allocation Parsing com Span&lt;T&gt;
/// Encoding Windows-1252 (padrão Windows pt-BR - mesma extração do Windows Explorer)
/// </summary>
public abstract class LeitorArquivoBaseV3<T> where T : class
{
    protected readonly string CaminhoArquivo;
    protected readonly char Delimitador;
    private const int MaxCampos = 20;

    protected LeitorArquivoBaseV3(string caminhoArquivo, char delimitador = '@')
    {
        CaminhoArquivo = caminhoArquivo;
        Delimitador = delimitador;

        if (!File.Exists(caminhoArquivo))
            throw new FileNotFoundException($"Arquivo não encontrado: {caminhoArquivo}");
    }

    public async IAsyncEnumerable<T> LerArquivoAsync()
    {
        using var reader = new StreamReader(
            CaminhoArquivo,
            Encoding.GetEncoding(1252), // Windows-1252 (ANSI pt-BR) - mesmo encoding da extração
            detectEncodingFromByteOrderMarks: false,
            bufferSize: 65536
        );

        string? linha;
        while ((linha = await reader.ReadLineAsync()) != null)
        {
            if (string.IsNullOrWhiteSpace(linha))
                continue;

            var item = ProcessarLinhaComSpan(linha);
            if (item != null)
                yield return item;
        }
    }

    private T? ProcessarLinhaComSpan(string linha)
    {
        ReadOnlySpan<char> span = linha.AsSpan();
        Span<Range> campos = stackalloc Range[MaxCampos];
        int count = span.Split(campos, Delimitador);
        return ProcessarCampos(span, campos, count);
    }

    protected abstract T? ProcessarCampos(ReadOnlySpan<char> linha, Span<Range> campos, int count);

    protected static string ObterValor(ReadOnlySpan<char> linha, Span<Range> campos, int indice, int maxLength = 0)
    {
        if (indice >= campos.Length) return string.Empty;
        var campo = linha[campos[indice]];
        if (campo.IsWhiteSpace()) return string.Empty;
        
        var valor = campo.Trim().ToString();
        
        // Truncar se maxLength > 0 e valor excede o limite
        if (maxLength > 0 && valor.Length > maxLength)
        {
            // Log opcional: caso queira rastrear truncamentos
            // System.Diagnostics.Debug.WriteLine($"[TRUNCADO] Campo {indice}: '{valor}' -> '{valor.Substring(0, maxLength)}' (max: {maxLength})");
            return valor.Substring(0, maxLength);
        }
        
        return valor;
    }

    protected static int ObterInteiro(ReadOnlySpan<char> linha, Span<Range> campos, int indice)
    {
        if (indice >= campos.Length) return 0;
        var campo = linha[campos[indice]].Trim();
        return int.TryParse(campo, out int resultado) ? resultado : 0;
    }

    protected static int? ObterInteiroNulavel(ReadOnlySpan<char> linha, Span<Range> campos, int indice)
    {
        if (indice >= campos.Length) return null;
        var campo = linha[campos[indice]].Trim();
        if (campo.IsEmpty || campo.IsWhiteSpace()) return null;
        return int.TryParse(campo, out int resultado) ? resultado : null;
    }
}
