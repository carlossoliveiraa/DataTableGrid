using System;
using Uninter.Correios.Domain.Models.ImportV2;

namespace Uninter.Correios.Infra.Readers;

public class LeitorBairroV3 : LeitorArquivoBaseV3<Bairro>
{
    public LeitorBairroV3(string caminhoArquivo) : base(caminhoArquivo) { }

    protected override Bairro? ProcessarCampos(ReadOnlySpan<char> linha, Span<Range> campos, int count)
    {
        // LOG_BAIRRO.TXT: BAI_NU@UFE_SG@LOC_NU@BAI_NO@BAI_NO_ABREV
        if (count < 5) return null;

        return new Bairro
        {
            BaiNu      = ObterInteiro(linha, campos, 0),
            UfeSg      = ObterValor(linha, campos, 1, 2),
            LocNu      = ObterInteiro(linha, campos, 2),
            BaiNo      = ObterValor(linha, campos, 3, 72),
            BaiNoAbrev = ObterValor(linha, campos, 4, 36)
        };
    }
}
