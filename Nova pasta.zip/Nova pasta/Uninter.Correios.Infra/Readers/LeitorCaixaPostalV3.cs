using System;
using Uninter.Correios.Domain.Models.ImportV2;

namespace Uninter.Correios.Infra.Readers;

public class LeitorCaixaPostalV3 : LeitorArquivoBaseV3<CaixaPostal>
{
    public LeitorCaixaPostalV3(string caminhoArquivo) : base(caminhoArquivo) { }

    protected override CaixaPostal? ProcessarCampos(ReadOnlySpan<char> linha, Span<Range> campos, int count)
    {
        // LOG_CPC.TXT: CPC_NU@UFE_SG@LOC_NU@CPC_NO@CPC_ENDERECO@CEP
        if (count < 6) return null;

        return new CaixaPostal
        {
            CpcNu       = ObterInteiro(linha, campos, 0),
            UfeSg       = ObterValor(linha, campos, 1, 2),
            LocNu       = ObterInteiro(linha, campos, 2),
            CpcNo       = ObterValor(linha, campos, 3, 72),
            CpcEndereco = ObterValor(linha, campos, 4, 100),
            Cep         = ObterValor(linha, campos, 5, 8)
        };
    }
}
