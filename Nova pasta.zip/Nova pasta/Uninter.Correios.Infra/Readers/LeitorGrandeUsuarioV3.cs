using System;
using Uninter.Correios.Domain.Models.ImportV2;

namespace Uninter.Correios.Infra.Readers;

public class LeitorGrandeUsuarioV3 : LeitorArquivoBaseV3<GrdUsuario>
{
    public LeitorGrandeUsuarioV3(string caminhoArquivo) : base(caminhoArquivo) { }

    protected override GrdUsuario? ProcessarCampos(ReadOnlySpan<char> linha, Span<Range> campos, int count)
    {
        // LOG_GRANDE_USUARIO.TXT: GRU_NU@UFE_SG@LOC_NU@BAI_NU@LOG_NU@GRU_NO@GRU_ENDERECO@CEP@GRU_NO_ABREV
        if (count < 9) return null;

        return new GrdUsuario
        {
            GruNu       = ObterInteiro(linha, campos, 0),
            UfeSg       = ObterValor(linha, campos, 1, 2),
            LocNu       = ObterInteiro(linha, campos, 2),
            BaiNu       = ObterInteiroNulavel(linha, campos, 3) ?? 0,
            LogNu       = ObterInteiroNulavel(linha, campos, 4) ?? 0,
            GruNo       = ObterValor(linha, campos, 5, 72),
            GruEndereco = ObterValor(linha, campos, 6, 100),
            Cep         = ObterValor(linha, campos, 7, 8),
            GruNoAbrev  = ObterValor(linha, campos, 8, 36)
        };
    }
}
