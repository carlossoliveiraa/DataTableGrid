using System;
using Uninter.Correios.Domain.Models.ImportV2;

namespace Uninter.Correios.Infra.Readers;

public class LeitorLocalidadeV3 : LeitorArquivoBaseV3<Localidade>
{
    public LeitorLocalidadeV3(string caminhoArquivo) : base(caminhoArquivo) { }

    protected override Localidade? ProcessarCampos(ReadOnlySpan<char> linha, Span<Range> campos, int count)
    {
        // LOG_LOCALIDADE.TXT: LOC_NU@UFE_SG@LOC_NO@CEP@LOC_IN_SIT@LOC_IN_TIPO_LOC@LOC_NU_SUB@LOC_NO_ABREV@MUN_NU
        if (count < 9) return null;

        return new Localidade
        {
            LocNu        = ObterInteiro(linha, campos, 0),
            UfeSg         = ObterValor(linha, campos, 1, 2),
            LocNo         = ObterValor(linha, campos, 2, 72),
            Cep           = ObterValor(linha, campos, 3, 8),
            LocInSit      = ObterValor(linha, campos, 4, 1),
            LocInTipoLoc  = ObterValor(linha, campos, 5, 1),
            LocNuSub      = ObterInteiro(linha, campos, 6),
            LocNoAbrev    = ObterValor(linha, campos, 7, 36),
            MunNu        = ObterInteiro(linha, campos, 8)
        };
    }
}
