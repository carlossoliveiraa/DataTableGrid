using System;
using Uninter.Correios.Domain.Models.ImportV2;

namespace Uninter.Correios.Infra.Readers;

public class LeitorLogradouroV3 : LeitorArquivoBaseV3<Logradouro>
{
    public LeitorLogradouroV3(string caminhoArquivo) : base(caminhoArquivo) { }

    protected override Logradouro? ProcessarCampos(ReadOnlySpan<char> linha, Span<Range> campos, int count)
    {
        // LOG_LOGRADOURO_*.TXT: LOG_NU@UFE_SG@LOC_NU@BAI_NU_INI@BAI_NU_FIM@LOG_NO@LOG_COMPLEMENTO@CEP@TLO_TX@LOG_STA_TLO@LOG_NO_ABREV
        if (count < 11) return null;

        return new Logradouro
        {
            LogNu          = ObterInteiro(linha, campos, 0),
            UfeSg          = ObterValor(linha, campos, 1, 2),
            LocNu          = ObterInteiro(linha, campos, 2),
            BaiNuIni       = ObterInteiroNulavel(linha, campos, 3) ?? 0,
            BaiNuFim       = ObterInteiroNulavel(linha, campos, 4) ?? 0,
            LogNo          = ObterValor(linha, campos, 5, 100),
            LogComplemento = ObterValor(linha, campos, 6, 100),
            Cep            = ObterValor(linha, campos, 7, 8),
            TloTx          = ObterValor(linha, campos, 8, 36),
            LogStaTlo      = ObterValor(linha, campos, 9, 1),
            LogNoAbrev     = ObterValor(linha, campos, 10, 36)
        };
    }
}
