using System;
using Uninter.Correios.Domain.Models.ImportV2;

namespace Uninter.Correios.Infra.Readers;

public class LeitorUnidadeOperacionalV3 : LeitorArquivoBaseV3<UnidadeOper>
{
    public LeitorUnidadeOperacionalV3(string caminhoArquivo) : base(caminhoArquivo) { }

    protected override UnidadeOper? ProcessarCampos(ReadOnlySpan<char> linha, Span<Range> campos, int count)
    {
        // LOG_UNID_OPER.TXT: UOP_NU@UFE_SG@LOC_NU@BAI_NU@LOG_NU@UOP_NO@UOP_ENDERECO@CEP@UOP_IN_CP@UOP_NO_ABREV
        if (count < 10) return null;

        return new UnidadeOper
        {
            UopNu       = ObterInteiro(linha, campos, 0),
            UfeSg       = ObterValor(linha, campos, 1, 2),
            LocNu       = ObterInteiro(linha, campos, 2),
            BaiNu       = ObterInteiroNulavel(linha, campos, 3) ?? 0,
            LogNu       = ObterInteiroNulavel(linha, campos, 4) ?? 0,
            UopNo       = ObterValor(linha, campos, 5, 100),
            UopEndereco = ObterValor(linha, campos, 6, 100),
            Cep         = ObterValor(linha, campos, 7, 8),
            UopInCp     = ObterValor(linha, campos, 8, 1),
            UopNoAbrev  = ObterValor(linha, campos, 9, 36)
        };
    }
}
