using Dapper;

using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using Uninter.Correios.Domain.Interfaces.Infra;
using Uninter.Correios.Domain.Models;
using Uninter.Correios.Infra.Managers;

namespace Uninter.Correios.Infra.Repositories;

public class BaseRepository<TEntity>(BaseConnectionManager connectionManager) : IBaseRepository<TEntity>
{
    protected readonly BaseConnectionManager _connectionManager = connectionManager;

    public IDbConnection Conn => _connectionManager.conn.Value;
    public IDbTransaction Trans => _connectionManager.trans;

    public static string GetProcedureName(string operation) => $"{typeof(TEntity).Name}_{operation}";

    public virtual async Task<int> InserirAsync(TEntity parameters)
    {
        BeginTransaction();
        try
        {
            var procName = GetProcedureName("Inserir");
            var id = await Conn.ExecuteScalarAsync<int>(procName, parameters, Trans, commandType: CommandType.StoredProcedure);
            Commit();
            return id;
        }
        catch
        {
            Rollback();
            throw;
        }
    }

    public virtual async Task<bool> AtualizarAsync(TEntity parameters)
    {
        BeginTransaction();
        try
        {
            var procName = GetProcedureName("Atualizar");
            var linhas = await Conn.ExecuteAsync(procName, parameters, Trans, commandType: CommandType.StoredProcedure);
            Commit();
            return linhas > 0;
        }
        catch
        {
            Rollback();
            throw;
        }
    }

    public virtual async Task<bool> DeletarAsync(int id)
    {
        BeginTransaction();
        try
        {
            var procName = GetProcedureName("Deletar");
            await Conn.ExecuteAsync(procName, new { Id = id }, Trans, commandType: CommandType.StoredProcedure);
            Commit();
            return true;
        }
        catch
        {
            Rollback();
            throw;
        }
    }

    public virtual async Task<TEntity> ConsultarPorIdAsync(int id)
    {
        var procName = GetProcedureName("Consultar");
        return await Conn.QueryFirstOrDefaultAsync<TEntity>(procName, new { Id = id }, commandType: CommandType.StoredProcedure);
    }

    /// <summary>
    /// Método responsável por consultar todos os registros de uma entidade no banco de dados.
    /// </summary>
    /// <remarks>
    /// Este método utiliza o Dapper para executar uma procedure armazenada no banco de dados.
    /// A procedure é gerada dinamicamente com base no nome da entidade e na operação "Consultar".
    /// </remarks>
    /// <returns>
    /// Retorna uma coleção IEnumerable contendo os registros da entidade consultada.
    /// </returns>
    public virtual async Task<IEnumerable<TEntity>> ConsultarTodosAsync()
    {
        // Obtém o nome da procedure correspondente à operação "Consultar" para a entidade.
        var procName = GetProcedureName("Consultar");

        // Executa a procedure e retorna os resultados como uma coleção IEnumerable.
        return await Conn.QueryAsync<TEntity>(procName, commandType: CommandType.StoredProcedure);
    }

    public virtual async Task<bool> IdValidoAsync(int id)
    {
        var procName = GetProcedureName("IdValido");
        return await Conn.QueryFirstOrDefaultAsync<bool>(procName, new { Id = id }, commandType: CommandType.StoredProcedure);
    }

    public void BeginTransaction() => _connectionManager.BeginTransaction();
    public void Rollback() => _connectionManager.Rollback();
    public void Commit() => _connectionManager.Commit();
}
