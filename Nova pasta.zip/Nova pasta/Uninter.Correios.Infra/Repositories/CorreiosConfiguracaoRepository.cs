using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using Dapper;
using Uninter.Correios.Domain.Interfaces.Infra;
using Uninter.Correios.Domain.Models;
using Uninter.Correios.Domain.Request.ConfiguracaoAplicacao;
using Uninter.Correios.Infra.Managers;

namespace Uninter.Correios.Infra.Repositories;

/// <summary>
/// Repositório para acesso aos dados de configuração dos Correios.
/// </summary>
public class CorreiosConfiguracaoRepository : ICorreiosConfiguracaoRepository
{
    private readonly ZipCodeConnectionManager _connectionManager;

    public CorreiosConfiguracaoRepository(ZipCodeConnectionManager connectionManager)
    {
        _connectionManager = connectionManager;
    }

    private IDbConnection Conn => _connectionManager.conn.Value;

    /// <summary>
    /// Obtém o token ativo e válido do banco de dados.
    /// </summary>
    public async Task<CorreiosConfiguracao> ObterTokenAtivoAsync()
    {
        try
        {
            var resultado = await Conn.QueryFirstOrDefaultAsync<CorreiosConfiguracao>(
                "usp_CorreiosConfiguracao_ObterTokenAtivo",
                commandType: CommandType.StoredProcedure);

            return resultado;
        }
        catch (Exception ex)
        {
            throw new Exception($"Erro ao obter token ativo dos Correios: {ex.Message}", ex);
        }
    }

    /// <summary>
    /// Obtém uma configuração específica por ID.
    /// </summary>
    public async Task<CorreiosConfiguracao> ObterPorIdAsync(int id)
    {
        try
        {
            var resultado = await Conn.QueryFirstOrDefaultAsync<CorreiosConfiguracao>(
                "usp_CorreiosConfiguracao_ObterPorId",
                new { Id = id },
                commandType: CommandType.StoredProcedure);

            return resultado;
        }
        catch (Exception ex)
        {
            throw new Exception($"Erro ao obter configuração dos Correios por ID: {ex.Message}", ex);
        }
    }

    /// <summary>
    /// Verifica se existe um token válido no banco de dados.
    /// </summary>
    public async Task<bool> PossuiTokenValidoAsync()
    {
        try
        {
            var resultado = await Conn.QueryFirstOrDefaultAsync<bool>(
                "usp_CorreiosConfiguracao_PossuiTokenValido",
                commandType: CommandType.StoredProcedure);

            return resultado;
        }
        catch (Exception ex)
        {
            throw new Exception($"Erro ao verificar se possui token válido: {ex.Message}", ex);
        }
    }

    /// <summary>
    /// Atualiza a data de último uso do token.
    /// </summary>
    public async Task AtualizarUltimoUsoAsync(int id)
    {
        try
        {
            await Conn.ExecuteAsync(
                "usp_CorreiosConfiguracao_AtualizarUltimoUso",
                new { Id = id },
                commandType: CommandType.StoredProcedure);
        }
        catch (Exception ex)
        {
            throw new Exception($"Erro ao atualizar último uso do token: {ex.Message}", ex);
        }
    }

    /// <summary>
    /// Atualiza a data de atualização dos Correios.
    /// </summary>
    public async Task AtualizarDataAtualizacaoCorreiosAsync(int id, DateTime dataAtualizacaoCorreios)
    {
        try
        {
            await Conn.ExecuteAsync(
                "usp_CorreiosConfiguracao_AtualizarDataAtualizacaoCorreios",
                new { Id = id, DataAtualizacaoCorreios = dataAtualizacaoCorreios },
                commandType: CommandType.StoredProcedure);
        }
        catch (Exception ex)
        {
            throw new Exception($"Erro ao atualizar data de atualização dos Correios: {ex.Message}", ex);
        }
    }

    // ── CRUD ──────────────────────────────────────────────────────────────

    public async Task<IEnumerable<CorreiosConfiguracao>> ListarTodosAsync()
    {
        try
        {
            return await Conn.QueryAsync<CorreiosConfiguracao>(
                "usp_CorreiosConfiguracao_ListarTodos",
                commandType: CommandType.StoredProcedure);
        }
        catch (Exception ex)
        {
            throw new Exception($"Erro ao listar configurações dos Correios: {ex.Message}", ex);
        }
    }

    public async Task<int> InserirAsync(CorreiosConfiguracaoInserirRequest request)
    {
        try
        {
            return await Conn.QuerySingleAsync<int>(
                "usp_CorreiosConfiguracao_Inserir",
                new
                {
                    request.Token,
                    request.EnderecoIp,
                    request.ExpiraEm,
                    request.Observacao,
                    request.CriadoPor
                },
                commandType: CommandType.StoredProcedure);
        }
        catch (Exception ex)
        {
            throw new Exception($"Erro ao inserir configuração dos Correios: {ex.Message}", ex);
        }
    }

    public async Task AtualizarAsync(int id, CorreiosConfiguracaoAtualizarRequest request)
    {
        try
        {
            await Conn.ExecuteAsync(
                "usp_CorreiosConfiguracao_Atualizar",
                new
                {
                    Id = id,
                    request.Token,
                    request.EnderecoIp,
                    request.ExpiraEm,
                    request.Observacao
                },
                commandType: CommandType.StoredProcedure);
        }
        catch (Exception ex)
        {
            throw new Exception($"Erro ao atualizar configuração dos Correios: {ex.Message}", ex);
        }
    }

    public async Task ExcluirLogicoAsync(int id)
    {
        try
        {
            await Conn.ExecuteAsync(
                "usp_CorreiosConfiguracao_ExcluirLogico",
                new { Id = id },
                commandType: CommandType.StoredProcedure);
        }
        catch (Exception ex)
        {
            throw new Exception($"Erro ao excluir configuração dos Correios: {ex.Message}", ex);
        }
    }
}
