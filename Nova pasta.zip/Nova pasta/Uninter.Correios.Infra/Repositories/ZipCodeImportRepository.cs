using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Threading.Tasks;
using Uninter.Correios.CrossCutting.Helpers;
using Uninter.Correios.Domain.Interfaces.Infra;
using Uninter.Correios.Domain.Models.ImportV2;
using Uninter.Correios.Infra.Configuration;

namespace Uninter.Correios.Infra.Repositories;

/// <summary>
/// Repositório de importação eDNE (Correios) para o banco ZipCode.
/// Estratégia: TRUNCATE staging → SqlBulkCopy → MERGE com hash SHA256.
/// </summary>
public class ZipCodeImportRepository : IZipCodeImportRepository
{
    private readonly string _stringConexao;
    private const int BatchSize = 10_000;
    private const int BulkCopyTimeout = 600;
    private const int MergeTimeout = 3600;

    public ZipCodeImportRepository()
    {
        _stringConexao = DatabaseConfiguration.ZipCodeConnection
            ?? throw new InvalidOperationException("ZipCodeConnection não configurada.");
    }

    private SqlConnection CriarConexao()
    {
        var builder = new SqlConnectionStringBuilder(_stringConexao)
        {
            ConnectTimeout = 120,
            CommandTimeout = 0,
            Pooling = true,
            MinPoolSize = 5,
            MaxPoolSize = 100,
            PacketSize = 32768,
            MultipleActiveResultSets = true
        };
        return new SqlConnection(builder.ConnectionString);
    }

    #region 1. TRUNCATE Staging

    public async Task LimparStagingAsync()
    {
        await using var conn = CriarConexao();
        await conn.OpenAsync();

        await using var cmd = new SqlCommand("usp_ZipCodeImport_LimparStaging", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandTimeout = 300;
        await cmd.ExecuteNonQueryAsync();
    }

    #endregion

    #region 2. SqlBulkCopy

    public async Task BulkInsertLocalidadesAsync(IEnumerable<Localidade> localidades)
    {
        var dataTable = CriarDataTableLocalidades(localidades);

        await using var conn = CriarConexao();
        await conn.OpenAsync();

        using var bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, null)
        {
            DestinationTableName = "LOG_LOCALIDADE",
            BatchSize = BatchSize,
            BulkCopyTimeout = BulkCopyTimeout,
            EnableStreaming = true
        };

        bulkCopy.ColumnMappings.Add("LOC_NU", "LOC_NU");
        bulkCopy.ColumnMappings.Add("UFE_SG", "UFE_SG");
        bulkCopy.ColumnMappings.Add("LOC_NO", "LOC_NO");
        bulkCopy.ColumnMappings.Add("CEP", "CEP");
        bulkCopy.ColumnMappings.Add("LOC_IN_SIT", "LOC_IN_SIT");
        bulkCopy.ColumnMappings.Add("LOC_IN_TIPO_LOC", "LOC_IN_TIPO_LOC");
        bulkCopy.ColumnMappings.Add("LOC_NU_SUB", "LOC_NU_SUB");
        bulkCopy.ColumnMappings.Add("LOC_NO_ABREV", "LOC_NO_ABREV");
        bulkCopy.ColumnMappings.Add("MUN_NU", "MUN_NU");
        bulkCopy.ColumnMappings.Add("RowHash", "RowHash");

        await bulkCopy.WriteToServerAsync(dataTable);
    }

    public async Task BulkInsertBairrosAsync(IEnumerable<Bairro> bairros)
    {
        var dataTable = CriarDataTableBairros(bairros);

        await using var conn = CriarConexao();
        await conn.OpenAsync();

        using var bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, null)
        {
            DestinationTableName = "LOG_BAIRRO",
            BatchSize = BatchSize,
            BulkCopyTimeout = BulkCopyTimeout,
            EnableStreaming = true
        };

        bulkCopy.ColumnMappings.Add("BAI_NU", "BAI_NU");
        bulkCopy.ColumnMappings.Add("UFE_SG", "UFE_SG");
        bulkCopy.ColumnMappings.Add("LOC_NU", "LOC_NU");
        bulkCopy.ColumnMappings.Add("BAI_NO", "BAI_NO");
        bulkCopy.ColumnMappings.Add("BAI_NO_ABREV", "BAI_NO_ABREV");
        bulkCopy.ColumnMappings.Add("RowHash", "RowHash");

        await bulkCopy.WriteToServerAsync(dataTable);
    }

    public async Task BulkInsertLogradourosAsync(IEnumerable<Logradouro> logradouros, string uf)
    {
        var dataTable = CriarDataTableLogradouros(logradouros);

        await using var conn = CriarConexao();
        await conn.OpenAsync();

        using var bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, null)
        {
            DestinationTableName = "LOG_LOGRADOURO",
            BatchSize = BatchSize,
            BulkCopyTimeout = BulkCopyTimeout,
            EnableStreaming = true
        };

        bulkCopy.ColumnMappings.Add("LOG_NU", "LOG_NU");
        bulkCopy.ColumnMappings.Add("UFE_SG", "UFE_SG");
        bulkCopy.ColumnMappings.Add("LOC_NU", "LOC_NU");
        bulkCopy.ColumnMappings.Add("BAI_NU_INI", "BAI_NU_INI");
        bulkCopy.ColumnMappings.Add("BAI_NU_FIM", "BAI_NU_FIM");
        bulkCopy.ColumnMappings.Add("LOG_NO", "LOG_NO");
        bulkCopy.ColumnMappings.Add("LOG_COMPLEMENTO", "LOG_COMPLEMENTO");
        bulkCopy.ColumnMappings.Add("CEP", "CEP");
        bulkCopy.ColumnMappings.Add("TLO_TX", "TLO_TX");
        bulkCopy.ColumnMappings.Add("LOG_STA_TLO", "LOG_STA_TLO");
        bulkCopy.ColumnMappings.Add("LOG_NO_ABREV", "LOG_NO_ABREV");
        bulkCopy.ColumnMappings.Add("RowHash", "RowHash");

        await bulkCopy.WriteToServerAsync(dataTable);
    }

    public async Task BulkInsertCaixasPostaisAsync(IEnumerable<CaixaPostal> caixas)
    {
        var dataTable = CriarDataTableCaixasPostais(caixas);

        await using var conn = CriarConexao();
        await conn.OpenAsync();

        using var bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, null)
        {
            DestinationTableName = "LOG_CPC",
            BatchSize = BatchSize,
            BulkCopyTimeout = BulkCopyTimeout,
            EnableStreaming = true
        };

        bulkCopy.ColumnMappings.Add("CPC_NU", "CPC_NU");
        bulkCopy.ColumnMappings.Add("UFE_SG", "UFE_SG");
        bulkCopy.ColumnMappings.Add("LOC_NU", "LOC_NU");
        bulkCopy.ColumnMappings.Add("CPC_NO", "CPC_NO");
        bulkCopy.ColumnMappings.Add("CPC_ENDERECO", "CPC_ENDERECO");
        bulkCopy.ColumnMappings.Add("CEP", "CEP");
        bulkCopy.ColumnMappings.Add("RowHash", "RowHash");

        await bulkCopy.WriteToServerAsync(dataTable);
    }

    public async Task BulkInsertGrandesUsuariosAsync(IEnumerable<GrdUsuario> usuarios)
    {
        var dataTable = CriarDataTableGrandesUsuarios(usuarios);

        await using var conn = CriarConexao();
        await conn.OpenAsync();

        using var bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, null)
        {
            DestinationTableName = "LOG_GRANDE_USUARIO",
            BatchSize = BatchSize,
            BulkCopyTimeout = BulkCopyTimeout,
            EnableStreaming = true
        };

        bulkCopy.ColumnMappings.Add("GRU_NU", "GRU_NU");
        bulkCopy.ColumnMappings.Add("UFE_SG", "UFE_SG");
        bulkCopy.ColumnMappings.Add("LOC_NU", "LOC_NU");
        bulkCopy.ColumnMappings.Add("BAI_NU", "BAI_NU");
        bulkCopy.ColumnMappings.Add("LOG_NU", "LOG_NU");
        bulkCopy.ColumnMappings.Add("GRU_NO", "GRU_NO");
        bulkCopy.ColumnMappings.Add("GRU_ENDERECO", "GRU_ENDERECO");
        bulkCopy.ColumnMappings.Add("CEP", "CEP");
        bulkCopy.ColumnMappings.Add("GRU_NO_ABREV", "GRU_NO_ABREV");
        bulkCopy.ColumnMappings.Add("RowHash", "RowHash");

        await bulkCopy.WriteToServerAsync(dataTable);
    }

    public async Task BulkInsertUnidadesOperacionaisAsync(IEnumerable<UnidadeOper> unidades)
    {
        var dataTable = CriarDataTableUnidadesOperacionais(unidades);

        await using var conn = CriarConexao();
        await conn.OpenAsync();

        using var bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, null)
        {
            DestinationTableName = "LOG_UNID_OPER",
            BatchSize = BatchSize,
            BulkCopyTimeout = BulkCopyTimeout,
            EnableStreaming = true
        };

        bulkCopy.ColumnMappings.Add("UOP_NU", "UOP_NU");
        bulkCopy.ColumnMappings.Add("UFE_SG", "UFE_SG");
        bulkCopy.ColumnMappings.Add("LOC_NU", "LOC_NU");
        bulkCopy.ColumnMappings.Add("BAI_NU", "BAI_NU");
        bulkCopy.ColumnMappings.Add("LOG_NU", "LOG_NU");
        bulkCopy.ColumnMappings.Add("UOP_NO", "UOP_NO");
        bulkCopy.ColumnMappings.Add("UOP_ENDERECO", "UOP_ENDERECO");
        bulkCopy.ColumnMappings.Add("CEP", "CEP");
        bulkCopy.ColumnMappings.Add("UOP_IN_CP", "UOP_IN_CP");
        bulkCopy.ColumnMappings.Add("UOP_NO_ABREV", "UOP_NO_ABREV");
        bulkCopy.ColumnMappings.Add("RowHash", "RowHash");

        await bulkCopy.WriteToServerAsync(dataTable);
    }

    #endregion

    #region 3. MERGE LOG_* → PostalCode

    public async Task<(int inserted, int updated, int unchanged, List<ChangeRecord> mudancas)> MergeLogradourosAsync()
    {
        await using var conn = CriarConexao();
        await conn.OpenAsync();

        await using var cmd = new SqlCommand("usp_ZipCodeImport_MergeLogradouros", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandTimeout = MergeTimeout;

        int inserted = 0, updated = 0;
        var mudancas = new List<ChangeRecord>();

        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            var action = reader.GetString(0);
            var cep = reader.GetString(1);

            if (action == "INSERT")
            {
                inserted++;
                var newCityId = reader.IsDBNull(3) ? (long?)null : reader.GetInt64(3);
                var newDistrict = reader.IsDBNull(5) ? null : reader.GetString(5);
                var newAddress = reader.IsDBNull(7) ? null : reader.GetString(7);
                var newTypeId = reader.IsDBNull(9) ? (int?)null : reader.GetInt32(9);

                mudancas.Add(new ChangeRecord
                {
                    Tabela = "PostalCode",
                    OperationType = "INSERT",
                    ChavePrimaria = new Dictionary<string, object?> { { "Id", cep } },
                    ValoresAntigos = new Dictionary<string, object?>(),
                    ValoresNovos = new Dictionary<string, object?>
                    {
                        { "Id", cep },
                        { "CityId", newCityId },
                        { "District", newDistrict },
                        { "Address", newAddress },
                        { "TypeId", newTypeId }
                    },
                    DataHora = DateTime.UtcNow
                });
            }
            else if (action == "UPDATE")
            {
                updated++;
                var oldCityId = reader.IsDBNull(2) ? (long?)null : reader.GetInt64(2);
                var newCityId = reader.IsDBNull(3) ? (long?)null : reader.GetInt64(3);
                var oldDistrict = reader.IsDBNull(4) ? null : reader.GetString(4);
                var newDistrict = reader.IsDBNull(5) ? null : reader.GetString(5);
                var oldAddress = reader.IsDBNull(6) ? null : reader.GetString(6);
                var newAddress = reader.IsDBNull(7) ? null : reader.GetString(7);
                var oldTypeId = reader.IsDBNull(8) ? (int?)null : reader.GetInt32(8);
                var newTypeId = reader.IsDBNull(9) ? (int?)null : reader.GetInt32(9);

                mudancas.Add(new ChangeRecord
                {
                    Tabela = "PostalCode",
                    OperationType = "UPDATE",
                    ChavePrimaria = new Dictionary<string, object?> { { "Id", cep } },
                    ValoresAntigos = new Dictionary<string, object?>
                    {
                        { "Id", cep },
                        { "CityId", oldCityId },
                        { "District", oldDistrict },
                        { "Address", oldAddress },
                        { "TypeId", oldTypeId }
                    },
                    ValoresNovos = new Dictionary<string, object?>
                    {
                        { "Id", cep },
                        { "CityId", newCityId },
                        { "District", newDistrict },
                        { "Address", newAddress },
                        { "TypeId", newTypeId }
                    },
                    DataHora = DateTime.UtcNow
                });
            }
        }

        await reader.NextResultAsync();
        await reader.ReadAsync();
        var totalSource = reader.GetInt32(0);
        var unchanged = totalSource - (inserted + updated);

        return (inserted, updated, unchanged, mudancas);
    }

    public async Task<(int inserted, int updated, int unchanged, List<ChangeRecord> mudancas)> MergeCaixasPostaisAsync()
    {
        await using var conn = CriarConexao();
        await conn.OpenAsync();

        await using var cmd = new SqlCommand("usp_ZipCodeImport_MergeCaixasPostais", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandTimeout = MergeTimeout;

        int inserted = 0, updated = 0;
        var mudancas = new List<ChangeRecord>();

        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            var action = reader.GetString(0);
            var cep = reader.GetString(1);

            if (action == "INSERT")
            {
                inserted++;
                mudancas.Add(new ChangeRecord
                {
                    Tabela = "PostalCode",
                    OperationType = "INSERT",
                    ChavePrimaria = new Dictionary<string, object?> { { "Id", cep } },
                    ValoresAntigos = new Dictionary<string, object?>(),
                    ValoresNovos = new Dictionary<string, object?>
                    {
                        { "Id", cep },
                        { "CityId", reader.IsDBNull(3) ? null : reader.GetInt64(3) },
                        { "District", reader.IsDBNull(5) ? null : reader.GetString(5) },
                        { "Address", reader.IsDBNull(7) ? null : reader.GetString(7) },
                        { "TypeId", reader.IsDBNull(9) ? null : reader.GetInt32(9) }
                    },
                    DataHora = DateTime.UtcNow
                });
            }
            else if (action == "UPDATE")
            {
                updated++;
                mudancas.Add(new ChangeRecord
                {
                    Tabela = "PostalCode",
                    OperationType = "UPDATE",
                    ChavePrimaria = new Dictionary<string, object?> { { "Id", cep } },
                    ValoresAntigos = new Dictionary<string, object?>
                    {
                        { "Id", cep },
                        { "CityId", reader.IsDBNull(2) ? null : reader.GetInt64(2) },
                        { "District", reader.IsDBNull(4) ? null : reader.GetString(4) },
                        { "Address", reader.IsDBNull(6) ? null : reader.GetString(6) },
                        { "TypeId", reader.IsDBNull(8) ? null : reader.GetInt32(8) }
                    },
                    ValoresNovos = new Dictionary<string, object?>
                    {
                        { "Id", cep },
                        { "CityId", reader.IsDBNull(3) ? null : reader.GetInt64(3) },
                        { "District", reader.IsDBNull(5) ? null : reader.GetString(5) },
                        { "Address", reader.IsDBNull(7) ? null : reader.GetString(7) },
                        { "TypeId", reader.IsDBNull(9) ? null : reader.GetInt32(9) }
                    },
                    DataHora = DateTime.UtcNow
                });
            }
        }

        await reader.NextResultAsync();
        await reader.ReadAsync();
        var totalSource = reader.GetInt32(0);
        var unchanged = totalSource - (inserted + updated);

        return (inserted, updated, unchanged, mudancas);
    }

    public async Task<(int inserted, int updated, int unchanged, List<ChangeRecord> mudancas)> MergeGrandesUsuariosAsync()
    {
        await using var conn = CriarConexao();
        await conn.OpenAsync();

        await using var cmd = new SqlCommand("usp_ZipCodeImport_MergeGrandesUsuarios", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandTimeout = MergeTimeout;

        int inserted = 0, updated = 0;
        var mudancas = new List<ChangeRecord>();

        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            var action = reader.GetString(0);
            var cep = reader.GetString(1);

            if (action == "INSERT")
            {
                inserted++;
                mudancas.Add(new ChangeRecord
                {
                    Tabela = "PostalCode",
                    OperationType = "INSERT",
                    ChavePrimaria = new Dictionary<string, object?> { { "Id", cep } },
                    ValoresAntigos = new Dictionary<string, object?>(),
                    ValoresNovos = new Dictionary<string, object?>
                    {
                        { "Id", cep },
                        { "CityId", reader.IsDBNull(3) ? null : reader.GetInt64(3) },
                        { "District", reader.IsDBNull(5) ? null : reader.GetString(5) },
                        { "Address", reader.IsDBNull(7) ? null : reader.GetString(7) },
                        { "TypeId", reader.IsDBNull(9) ? null : reader.GetInt32(9) }
                    },
                    DataHora = DateTime.UtcNow
                });
            }
            else if (action == "UPDATE")
            {
                updated++;
                mudancas.Add(new ChangeRecord
                {
                    Tabela = "PostalCode",
                    OperationType = "UPDATE",
                    ChavePrimaria = new Dictionary<string, object?> { { "Id", cep } },
                    ValoresAntigos = new Dictionary<string, object?>
                    {
                        { "Id", cep },
                        { "CityId", reader.IsDBNull(2) ? null : reader.GetInt64(2) },
                        { "District", reader.IsDBNull(4) ? null : reader.GetString(4) },
                        { "Address", reader.IsDBNull(6) ? null : reader.GetString(6) },
                        { "TypeId", reader.IsDBNull(8) ? null : reader.GetInt32(8) }
                    },
                    ValoresNovos = new Dictionary<string, object?>
                    {
                        { "Id", cep },
                        { "CityId", reader.IsDBNull(3) ? null : reader.GetInt64(3) },
                        { "District", reader.IsDBNull(5) ? null : reader.GetString(5) },
                        { "Address", reader.IsDBNull(7) ? null : reader.GetString(7) },
                        { "TypeId", reader.IsDBNull(9) ? null : reader.GetInt32(9) }
                    },
                    DataHora = DateTime.UtcNow
                });
            }
        }

        await reader.NextResultAsync();
        await reader.ReadAsync();
        var totalSource = reader.GetInt32(0);
        var unchanged = totalSource - (inserted + updated);

        return (inserted, updated, unchanged, mudancas);
    }

    public async Task<(int inserted, int updated, int unchanged, List<ChangeRecord> mudancas)> MergeUnidadesOperacionaisAsync()
    {
        await using var conn = CriarConexao();
        await conn.OpenAsync();

        await using var cmd = new SqlCommand("usp_ZipCodeImport_MergeUnidadesOperacionais", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandTimeout = MergeTimeout;

        int inserted = 0, updated = 0;
        var mudancas = new List<ChangeRecord>();

        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            var action = reader.GetString(0);
            var cep = reader.GetString(1);

            if (action == "INSERT")
            {
                inserted++;
                mudancas.Add(new ChangeRecord
                {
                    Tabela = "PostalCode",
                    OperationType = "INSERT",
                    ChavePrimaria = new Dictionary<string, object?> { { "Id", cep } },
                    ValoresAntigos = new Dictionary<string, object?>(),
                    ValoresNovos = new Dictionary<string, object?>
                    {
                        { "Id", cep },
                        { "CityId", reader.IsDBNull(3) ? null : reader.GetInt64(3) },
                        { "District", reader.IsDBNull(5) ? null : reader.GetString(5) },
                        { "Address", reader.IsDBNull(7) ? null : reader.GetString(7) },
                        { "TypeId", reader.IsDBNull(9) ? null : reader.GetInt32(9) }
                    },
                    DataHora = DateTime.UtcNow
                });
            }
            else if (action == "UPDATE")
            {
                updated++;
                mudancas.Add(new ChangeRecord
                {
                    Tabela = "PostalCode",
                    OperationType = "UPDATE",
                    ChavePrimaria = new Dictionary<string, object?> { { "Id", cep } },
                    ValoresAntigos = new Dictionary<string, object?>
                    {
                        { "Id", cep },
                        { "CityId", reader.IsDBNull(2) ? null : reader.GetInt64(2) },
                        { "District", reader.IsDBNull(4) ? null : reader.GetString(4) },
                        { "Address", reader.IsDBNull(6) ? null : reader.GetString(6) },
                        { "TypeId", reader.IsDBNull(8) ? null : reader.GetInt32(8) }
                    },
                    ValoresNovos = new Dictionary<string, object?>
                    {
                        { "Id", cep },
                        { "CityId", reader.IsDBNull(3) ? null : reader.GetInt64(3) },
                        { "District", reader.IsDBNull(5) ? null : reader.GetString(5) },
                        { "Address", reader.IsDBNull(7) ? null : reader.GetString(7) },
                        { "TypeId", reader.IsDBNull(9) ? null : reader.GetInt32(9) }
                    },
                    DataHora = DateTime.UtcNow
                });
            }
        }

        await reader.NextResultAsync();
        await reader.ReadAsync();
        var totalSource = reader.GetInt32(0);
        var unchanged = totalSource - (inserted + updated);

        return (inserted, updated, unchanged, mudancas);
    }

    #endregion

    #region 4. DataTable Helpers

    private static DataTable CriarDataTableLocalidades(IEnumerable<Localidade> localidades)
    {
        var dt = new DataTable();
        dt.Columns.Add("LOC_NU", typeof(int));
        dt.Columns.Add("UFE_SG", typeof(string));
        dt.Columns.Add("LOC_NO", typeof(string));
        dt.Columns.Add("CEP", typeof(string));
        dt.Columns.Add("LOC_IN_SIT", typeof(string));
        dt.Columns.Add("LOC_IN_TIPO_LOC", typeof(string));
        dt.Columns.Add("LOC_NU_SUB", typeof(string));
        dt.Columns.Add("LOC_NO_ABREV", typeof(string));
        dt.Columns.Add("MUN_NU", typeof(string));
        dt.Columns.Add("RowHash", typeof(string));

        foreach (var loc in localidades)
        {
            var hash = HashCalculator.CalcularHashRegistro(
                loc.LocNu, loc.UfeSg, loc.LocNo, loc.Cep, loc.LocInSit,
                loc.LocInTipoLoc, loc.LocNuSub, loc.LocNoAbrev, loc.MunNu
            );
            dt.Rows.Add(
                loc.LocNu,
                loc.UfeSg ?? "",
                loc.LocNo ?? "",
                loc.Cep ?? "",
                loc.LocInSit ?? "",
                loc.LocInTipoLoc ?? "",
                loc.LocNuSub.ToString(),
                loc.LocNoAbrev ?? "",
                loc.MunNu.ToString(),
                hash
            );
        }
        return dt;
    }

    private static DataTable CriarDataTableBairros(IEnumerable<Bairro> bairros)
    {
        var dt = new DataTable();
        dt.Columns.Add("BAI_NU", typeof(int));
        dt.Columns.Add("UFE_SG", typeof(string));
        dt.Columns.Add("LOC_NU", typeof(int));
        dt.Columns.Add("BAI_NO", typeof(string));
        dt.Columns.Add("BAI_NO_ABREV", typeof(string));
        dt.Columns.Add("RowHash", typeof(string));

        foreach (var bai in bairros)
        {
            var hash = HashCalculator.CalcularHashRegistro(
                bai.BaiNu, bai.UfeSg, bai.LocNu, bai.BaiNo, bai.BaiNoAbrev
            );
            dt.Rows.Add(
                bai.BaiNu,
                bai.UfeSg ?? "",
                bai.LocNu,
                bai.BaiNo ?? "",
                bai.BaiNoAbrev ?? "",
                hash
            );
        }
        return dt;
    }

    private static DataTable CriarDataTableLogradouros(IEnumerable<Logradouro> logradouros)
    {
        var dt = new DataTable();
        dt.Columns.Add("LOG_NU", typeof(int));
        dt.Columns.Add("UFE_SG", typeof(string));
        dt.Columns.Add("LOC_NU", typeof(int));
        dt.Columns.Add("BAI_NU_INI", typeof(int));
        dt.Columns.Add("BAI_NU_FIM", typeof(int));
        dt.Columns.Add("LOG_NO", typeof(string));
        dt.Columns.Add("LOG_COMPLEMENTO", typeof(string));
        dt.Columns.Add("CEP", typeof(string));
        dt.Columns.Add("TLO_TX", typeof(string));
        dt.Columns.Add("LOG_STA_TLO", typeof(string));
        dt.Columns.Add("LOG_NO_ABREV", typeof(string));
        dt.Columns.Add("RowHash", typeof(string));

        foreach (var log in logradouros)
        {
            var hash = HashCalculator.CalcularHashRegistro(
                log.LogNu, log.UfeSg, log.LocNu, log.BaiNuIni, log.BaiNuFim,
                log.LogNo, log.LogComplemento, log.Cep, log.TloTx, log.LogStaTlo, log.LogNoAbrev
            );
            dt.Rows.Add(
                log.LogNu,
                log.UfeSg ?? "",
                log.LocNu,
                log.BaiNuIni == 0 ? (object)DBNull.Value : log.BaiNuIni,
                log.BaiNuFim == 0 ? (object)DBNull.Value : log.BaiNuFim,
                log.LogNo ?? "",
                log.LogComplemento ?? "",
                log.Cep ?? "",
                log.TloTx ?? "",
                log.LogStaTlo ?? "",
                log.LogNoAbrev ?? "",
                hash
            );
        }
        return dt;
    }

    private static DataTable CriarDataTableCaixasPostais(IEnumerable<CaixaPostal> caixas)
    {
        var dt = new DataTable();
        dt.Columns.Add("CPC_NU", typeof(int));
        dt.Columns.Add("UFE_SG", typeof(string));
        dt.Columns.Add("LOC_NU", typeof(int));
        dt.Columns.Add("CPC_NO", typeof(string));
        dt.Columns.Add("CPC_ENDERECO", typeof(string));
        dt.Columns.Add("CEP", typeof(string));
        dt.Columns.Add("RowHash", typeof(string));

        foreach (var cpc in caixas)
        {
            var hash = HashCalculator.CalcularHashRegistro(
                cpc.CpcNu, cpc.UfeSg, cpc.LocNu, cpc.CpcNo, cpc.CpcEndereco, cpc.Cep
            );
            dt.Rows.Add(
                cpc.CpcNu,
                cpc.UfeSg ?? "",
                cpc.LocNu,
                cpc.CpcNo ?? "",
                cpc.CpcEndereco ?? "",
                cpc.Cep ?? "",
                hash
            );
        }
        return dt;
    }

    private static DataTable CriarDataTableGrandesUsuarios(IEnumerable<GrdUsuario> usuarios)
    {
        var dt = new DataTable();
        dt.Columns.Add("GRU_NU", typeof(int));
        dt.Columns.Add("UFE_SG", typeof(string));
        dt.Columns.Add("LOC_NU", typeof(int));
        dt.Columns.Add("BAI_NU", typeof(int));
        dt.Columns.Add("LOG_NU", typeof(int));
        dt.Columns.Add("GRU_NO", typeof(string));
        dt.Columns.Add("GRU_ENDERECO", typeof(string));
        dt.Columns.Add("CEP", typeof(string));
        dt.Columns.Add("GRU_NO_ABREV", typeof(string));
        dt.Columns.Add("RowHash", typeof(string));

        foreach (var gru in usuarios)
        {
            var hash = HashCalculator.CalcularHashRegistro(
                gru.GruNu, gru.UfeSg, gru.LocNu, gru.BaiNu, gru.LogNu,
                gru.GruNo, gru.GruEndereco, gru.Cep, gru.GruNoAbrev
            );
            dt.Rows.Add(
                gru.GruNu,
                gru.UfeSg ?? "",
                gru.LocNu,
                gru.BaiNu == 0 ? (object)DBNull.Value : gru.BaiNu,
                gru.LogNu == 0 ? (object)DBNull.Value : gru.LogNu,
                gru.GruNo ?? "",
                gru.GruEndereco ?? "",
                gru.Cep ?? "",
                gru.GruNoAbrev ?? "",
                hash
            );
        }
        return dt;
    }

    private static DataTable CriarDataTableUnidadesOperacionais(IEnumerable<UnidadeOper> unidades)
    {
        var dt = new DataTable();
        dt.Columns.Add("UOP_NU", typeof(int));
        dt.Columns.Add("UFE_SG", typeof(string));
        dt.Columns.Add("LOC_NU", typeof(int));
        dt.Columns.Add("BAI_NU", typeof(int));
        dt.Columns.Add("LOG_NU", typeof(int));
        dt.Columns.Add("UOP_NO", typeof(string));
        dt.Columns.Add("UOP_ENDERECO", typeof(string));
        dt.Columns.Add("CEP", typeof(string));
        dt.Columns.Add("UOP_IN_CP", typeof(string));
        dt.Columns.Add("UOP_NO_ABREV", typeof(string));
        dt.Columns.Add("RowHash", typeof(string));

        foreach (var uop in unidades)
        {
            var hash = HashCalculator.CalcularHashRegistro(
                uop.UopNu, uop.UfeSg, uop.LocNu, uop.BaiNu, uop.LogNu,
                uop.UopNo, uop.UopEndereco, uop.Cep, uop.UopInCp, uop.UopNoAbrev
            );
            dt.Rows.Add(
                uop.UopNu,
                uop.UfeSg ?? "",
                uop.LocNu,
                uop.BaiNu == 0 ? (object)DBNull.Value : uop.BaiNu,
                uop.LogNu == 0 ? (object)DBNull.Value : uop.LogNu,
                uop.UopNo ?? "",
                uop.UopEndereco ?? "",
                uop.Cep ?? "",
                uop.UopInCp ?? "",
                uop.UopNoAbrev ?? "",
                hash
            );
        }
        return dt;
    }

    #endregion
}
