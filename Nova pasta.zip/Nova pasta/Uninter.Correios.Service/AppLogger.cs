using System;

using Uninter.Core.V5.Log;
using Uninter.Correios.CrossCutting.Contract;

namespace Uninter.Correios.Service;

public class AppLogger : IAppLogger
{
    public void Information(string message, string? payload = null)
        => Logger.Information(message, payload);

    public void Warning(string message, string? payload = null, string? contractNotifications = null)
        => Logger.Warning(message, payload, contractNotifications);

    public void Error(string message, Exception exception, string? payload = null)
        => Logger.Error(message, exception, payload);
}
