using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;

using Microsoft.Data.SqlClient;
using Microsoft.Extensions.DependencyInjection;

using Uninter.Correios.CrossCutting;
using Uninter.Correios.CrossCutting.Contract;
using Uninter.Correios.Domain.Handlers.Token;
using Uninter.Correios.Domain.Interfaces.Infra;
using Uninter.Correios.Domain.Interfaces.Service;
using Uninter.Correios.Infra.Configuration;
using Uninter.Correios.Infra.Managers;
using Uninter.Correios.Infra.Repositories;
using Uninter.Correios.Service.Services;

namespace Uninter.Correios.Service;

public static class ApplicationModule
{
    private const string NAMESPACEBASE = "Uninter.Correios";

    public static void RegisterServices(IServiceCollection services)
    {
        // Registro explícito dos tipos genéricos base
        services.AddScoped(typeof(IBaseRepository<>), typeof(BaseRepository<>));

        // Registro do cache de token dos Correios como Singleton
        services.AddSingleton<ICorreiosTokenCache, CorreiosTokenCache>();

        // Logger wrapper sobre Uninter.Core.V5.Log.Logger estático
        services.AddSingleton<IAppLogger, AppLogger>();

        // Assemblies relevantes para o AutoInjector
        var assemblies = AppDomain.CurrentDomain.GetAssemblies()
            .Where(x => x.ManifestModule.Name.Contains(NAMESPACEBASE))
            .ToList();

        // Registro automático de repositórios e serviços específicos
        AutoInjector(services, assemblies, "Infra");
        AutoInjector(services, assemblies, "Service");

        // Registro explícito de dependências auxiliares
        services.AddScoped(sp => new PermissaoConnectionManager(new SqlConnection(DatabaseConfiguration.PermissaoConnection)));

        // Serviços para Hangfire
       
        services.AddScoped<IImportaDadosCorreiosService, ImportaDadosCorreiosService>();
        services.AddScoped<IDescompactaDadosService, DescompactaDadosService>();
        services.AddScoped<IExecutaImportadorService, ExecutaImportadorService>();
        services.AddScoped<IEnviarDadosJsonRabbitMQService, EnviarDadosJsonRabbitMQService>();
        services.AddSingleton(sp => new TemplateConnectionManager(new SqlConnection(DatabaseConfiguration.TemplateConnection)));
        services.AddSingleton(sp => new ZipCodeConnectionManager(new SqlConnection(DatabaseConfiguration.ZipCodeConnection)));
        services.AddScoped<UsuarioLogado>();
        services.AddTransient<TokenApiHeaderHandler>();
    }

    /// <summary>
    /// Registra automaticamente implementa��es concretas para interfaces espec�ficas do dom�nio.
    /// Ignora tipos base e gen�ricos abertos.
    /// </summary>
    private static void AutoInjector(IServiceCollection services, IEnumerable<Assembly> assemblies, string prefix)
    {
        var serviceAssembly = assemblies.FirstOrDefault(x => x.ManifestModule.Name.Contains(prefix));
        if (serviceAssembly == null)
            return;

        foreach (var type in serviceAssembly.ExportedTypes)
        {
            // Ignora tipos base e genéricos abertos
            if (type.Name.StartsWith("Base") || type.IsAbstract || type.IsGenericTypeDefinition)
                continue;

            var interfaces = type.GetInterfaces()
                .Where(x => x.Namespace != null && x.Namespace.Contains(NAMESPACEBASE) && !x.IsGenericType)
                .ToList();

            if (interfaces.Count == 0)
                continue;

            // Registra cada interface específica encontrada
            foreach (var iface in interfaces)
            {
                services.AddScoped(iface, type);
            }
        }
    }
}
