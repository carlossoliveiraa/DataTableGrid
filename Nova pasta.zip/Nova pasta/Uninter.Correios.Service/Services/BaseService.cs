using FluentValidation;
using System.Threading.Tasks;

namespace Uninter.Correios.Service.Services;

public class BaseService
{
    internal static void Validate<T>(T obj, AbstractValidator<T> validator)
    {
        if (Equals(obj, default(T)))
            throw new ValidationException("Objeto Inv�lido!");

        validator.ValidateAndThrow(obj);
    }

    internal static async Task ValidateAsync<T>(T obj, AbstractValidator<T> validator)
    {
        if (Equals(obj, default(T)))
            throw new ValidationException("Objeto Inv�lido!");

        await validator.ValidateAndThrowAsync(obj);
    }
}
