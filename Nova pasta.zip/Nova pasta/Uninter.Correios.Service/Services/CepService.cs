using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Refit;
using Uninter.Core.V5.Log;
using Uninter.Correios.CrossCutting.Extensions;
using Uninter.Correios.Domain.Interfaces.Api;
using Uninter.Correios.Domain.Interfaces.Infra;
using Uninter.Correios.Domain.Interfaces.Service;
using Uninter.Correios.Domain.Models;
using Uninter.Correios.Domain.Request.Cep;
using Uninter.Correios.Service.Validators.Cep;

namespace Uninter.Correios.Service.Services;

public class CepService(ICorreiosApi correiosApi, ICorreiosTokenCache tokenCache) : BaseService, ICepService
{
    private readonly ICorreiosApi _correiosApi = correiosApi;
    private readonly ICorreiosTokenCache _tokenCache = tokenCache;

  
    public async Task<Endereco> ConsultarCepAsync(ConsultarCepRequest request)
    {
        await ValidateAsync(request, new ConsultarCepValidator());

        var cepLimpo = request.Cep.LimparCep();
        var cepLog = cepLimpo?.Replace("\r", string.Empty).Replace("\n", string.Empty);

        var token = _tokenCache.ObterToken().NormalizeBearerToken();

        try
        {            
            var response = await _correiosApi.ConsultarCepAsync(cepLimpo, token);           
            return ConverterParaEndereco(response);
        }
        catch (ApiException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
        {
            // CEP não encontrado na API dos Correios - retorna null para tratamento no controller
            return null;
        }
        catch (ApiException ex) when (ex.StatusCode == HttpStatusCode.Unauthorized || ex.StatusCode == HttpStatusCode.Forbidden)
        {
            Logger.Error($"Falha de autenticação ao consultar CEP {cepLog}. Status: {(int)ex.StatusCode} {ex.StatusCode}", ex);
            throw new InvalidOperationException(
                "Token dos Correios inválido, expirado ou sem autorização para o endpoint configurado. Atualize o token ativo na configuração da aplicação.", ex);
        }
        catch (ApiException ex)
        {
            Logger.Error($"Erro ao consultar CEP {cepLog} na API dos Correios. Status: {(int)ex.StatusCode} {ex.StatusCode}.", ex);
            throw new InvalidOperationException(
                $"Erro ao consultar a API dos Correios ({(int)ex.StatusCode} {ex.StatusCode}).", ex);
        }
        catch (HttpRequestException ex)
        {
            Logger.Error($"Falha de rede ao consultar CEP {cepLog}.", ex);
            throw new InvalidOperationException($"Falha de rede ao consultar a API dos Correios: {ex.Message}", ex);
        }
    }

    #region Métodos Privados

    /// <summary>
    /// Converte EnderecoResponse da API para modelo de domínio Endereco.
    /// </summary>
    private Endereco ConverterParaEndereco(Domain.Response.Api.EnderecoResponse response)
    {
        return new Endereco
        {
            Cep = response.Cep ?? string.Empty,
            Uf = response.Uf ?? string.Empty,
            Localidade = response.Localidade,
            Bairro = response.Bairro,
            Logradouro = response.Logradouro ?? response.LogradouroTexto,
            TipoLogradouro = response.TipoLogradouro ?? response.LogradouroDNEC,
            Complemento = response.Complemento ?? response.LogradouroTextoAdicional,
            NumeroLocalidade = response.NumeroLocalidade ?? response.NumeroLocalidadeAlternativo,
            TipoCep = response.TipoCep,
            Lado = response.Lado,
            NumeroInicial = response.NumeroInicial,
            NumeroFinal = response.NumeroFinal,
            NomeLogradouro = response.NomeLogradouro,
            Abreviatura = response.Abreviatura,
            CodigoIbge = response.CodigoIbge
        };
    }

    #endregion
}
