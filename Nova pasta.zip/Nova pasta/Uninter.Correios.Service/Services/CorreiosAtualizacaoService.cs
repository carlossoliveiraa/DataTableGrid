using System;
using System.Threading.Tasks;
using Hangfire.Console;
using Hangfire.Server;
using Refit;
using Uninter.Correios.CrossCutting.Extensions;
using Uninter.Correios.Domain.Interfaces.Api;
using Uninter.Correios.Domain.Interfaces.Infra;
using Uninter.Correios.Domain.Interfaces.Service;

namespace Uninter.Correios.Service.Services;

/// <summary>
/// Serviço para verificar e gerenciar atualizações dos dados da API dos Correios.
/// </summary>
public class CorreiosAtualizacaoService : ICorreiosAtualizacaoService
{
    private readonly ICorreiosApi _correiosApi;
    private readonly ICorreiosConfiguracaoRepository _configuracaoRepository;
    private readonly ICorreiosTokenCache _tokenCache;

    public CorreiosAtualizacaoService(
        ICorreiosApi correiosApi,
        ICorreiosConfiguracaoRepository configuracaoRepository,
        ICorreiosTokenCache tokenCache)
    {
        _correiosApi = correiosApi;
        _configuracaoRepository = configuracaoRepository;
        _tokenCache = tokenCache;
    }

    /// <summary>
    /// Verifica se há atualização disponível na API dos Correios comparando 
    /// com a última data armazenada no banco de dados.
    /// </summary>
    public async Task<bool> VerificarSeHaAtualizacaoAsync()
    {
        try
        {
            // Obter configuração ativa do banco
            var configuracao = await _configuracaoRepository.ObterTokenAtivoAsync();

            if (configuracao == null)
            {
                Uninter.Core.V5.Log.Logger.Warning("Nenhuma configuração ativa encontrada no banco de dados.");
                return false;
            }

            // Buscar data de atualização na API dos Correios usando token do banco
            var token = _tokenCache.ObterToken().NormalizeBearerToken();
            var response = await _correiosApi.VerificarAtualizacaoAsync(token);

            // Comparar datas
            if (response == null)
            {
                Uninter.Core.V5.Log.Logger.Warning("Resposta da API de atualização é nula.");
                return false;
            }

            var haAtualizacao = response.EhMaisRecenteQue(configuracao.DataAtualizacaoCorreios);

            if (haAtualizacao)
            {
                Uninter.Core.V5.Log.Logger.Information(
                    $"Atualização disponível! Data da API: {response.AtualizadoEm:yyyy-MM-dd HH:mm:ss} | " +
                    $"Data no banco: {configuracao.DataAtualizacaoCorreios?.ToString("yyyy-MM-dd HH:mm:ss") ?? "N/A"}"
                );
            }
            else
            {
                Uninter.Core.V5.Log.Logger.Information(
                    $"Nenhuma atualização disponível. Data da API: {response.AtualizadoEm:yyyy-MM-dd HH:mm:ss} | " +
                    $"Data no banco: {configuracao.DataAtualizacaoCorreios?.ToString("yyyy-MM-dd HH:mm:ss") ?? "N/A"}"
                );
            }

            return haAtualizacao;
        }
        catch (ApiException apiEx)
        {
            Uninter.Core.V5.Log.Logger.Error(
                $"Erro ao verificar atualização na API dos Correios. Status: {apiEx.StatusCode}", apiEx);
            return false;
        }
        catch (Exception ex)
        {
            Uninter.Core.V5.Log.Logger.Error("Erro ao verificar se há atualização disponível.", ex);
            return false;
        }
    }

    /// <summary>
    /// Verifica se há atualização disponível na API dos Correios.
    /// - Sempre chama a API para obter a data atual (inclusive na primeira execução).
    /// - Se DataAtualizacaoCorreios for NULL: retorna (true, true, dataCorreios).
    /// - Se tiver data: compara e retorna (haAtualizacao, false, dataCorreios).
    /// A data retornada deve ser passada para AtualizarDataAtualizacaoAsync(DateTime) ao final.
    /// </summary>
    public async Task<(bool haAtualizacao, bool primeiraExecucao, DateTime? dataAtualizacaoCorreios)> VerificarEGravarDataInicialSeNecessarioAsync()
    {
        var primeiraExecucao = false;

        try
        {
            var configuracao = await _configuracaoRepository.ObterTokenAtivoAsync();

            if (configuracao == null)
            {
                Uninter.Core.V5.Log.Logger.Warning("Nenhuma configuração ativa encontrada no banco de dados.");
                return (false, false, null);
            }

            primeiraExecucao = !configuracao.DataAtualizacaoCorreios.HasValue;

            // Buscar data de atualização na API dos Correios (sempre, inclusive na primeira execução)
            var token = _tokenCache.ObterToken().NormalizeBearerToken();
            var response = await _correiosApi.VerificarAtualizacaoAsync(token);

            if (response == null)
            {
                Uninter.Core.V5.Log.Logger.Warning("Resposta da API de atualização é nula.");
                // Primeira execução sem data da API: permite importar, mas não terá data para gravar
                if (primeiraExecucao)
                    return (true, true, null);
                return (false, false, null);
            }

            // Regra:
            //   - Primeira execução (sem data gravada) => importa.
            //   - Caso contrário => importa somente se a data da API for mais recente
            //     que a última data gravada em DataAtualizacaoCorreios.
            var dataApi = response.AtualizadoEm;
            var dataBanco = configuracao.DataAtualizacaoCorreios;
            var haAtualizacao = primeiraExecucao || response.EhMaisRecenteQue(dataBanco);

            Uninter.Core.V5.Log.Logger.Information(
                $"Verificação de atualização Correios | API: {dataApi:yyyy-MM-dd HH:mm:ss} | " +
                $"Banco: {(dataBanco.HasValue ? dataBanco.Value.ToString("yyyy-MM-dd HH:mm:ss") : "NULL")} | " +
                $"PrimeiraExecucao: {primeiraExecucao} | HaAtualizacao: {haAtualizacao}"
            );

            return (haAtualizacao, primeiraExecucao, dataApi);
        }
        catch (ApiException apiEx)
        {
            Uninter.Core.V5.Log.Logger.Error(
                $"Erro ao verificar atualização na API dos Correios. Status: {apiEx.StatusCode}", apiEx);
            // Se é primeira execução, permite importar mesmo sem conseguir falar com a API
            if (primeiraExecucao)
            {
                Uninter.Core.V5.Log.Logger.Warning(
                    "Primeira execução detectada. Permitindo importação mesmo com falha na API de verificação."
                );
                return (true, true, null);
            }
            return (false, false, null);
        }
        catch (Exception ex)
        {
            Uninter.Core.V5.Log.Logger.Error("Erro ao verificar atualização dos Correios.", ex);
            // Se é primeira execução, permite importar mesmo sem conseguir falar com a API
            if (primeiraExecucao)
            {
                Uninter.Core.V5.Log.Logger.Warning(
                    "Primeira execução detectada. Permitindo importação mesmo com falha na API de verificação."
                );
                return (true, true, null);
            }
            return (false, false, null);
        }
    }

    /// <summary>
    /// Grava a data de atualização dos Correios diretamente no banco, sem chamar a API novamente.
    /// Use esta sobrecarga quando a data já foi obtida em VerificarEGravarDataInicialSeNecessarioAsync.
    /// </summary>
    public async Task AtualizarDataAtualizacaoAsync(DateTime dataAtualizacaoCorreios)
    {
        try
        {
            var configuracao = await _configuracaoRepository.ObterTokenAtivoAsync();

            if (configuracao == null)
            {
                Uninter.Core.V5.Log.Logger.Warning("Nenhuma configuração ativa encontrada no banco de dados. DataAtualizacaoCorreios não foi atualizada.");
                return;
            }

            await _configuracaoRepository.AtualizarDataAtualizacaoCorreiosAsync(configuracao.Id, dataAtualizacaoCorreios);

            Uninter.Core.V5.Log.Logger.Information(
                $"DataAtualizacaoCorreios atualizada com sucesso: {dataAtualizacaoCorreios:yyyy-MM-dd HH:mm:ss}"
            );
        }
        catch (Exception ex)
        {
            Uninter.Core.V5.Log.Logger.Error("Erro ao gravar DataAtualizacaoCorreios no banco de dados.", ex);
            throw;
        }
    }

    /// <summary>
    /// Consulta o endpoint /cep/v1/atualizacao dos Correios e grava a data retornada
    /// em DataAtualizacaoCorreios ao final de uma importação bem-sucedida.
    /// Dessa forma, na próxima execução a comparação é: dataCorreios > dataGravada.
    /// </summary>
    public async Task AtualizarDataAtualizacaoAsync()
    {
        try
        {
            var configuracao = await _configuracaoRepository.ObterTokenAtivoAsync();

            if (configuracao == null)
            {
                Uninter.Core.V5.Log.Logger.Warning("Nenhuma configuração ativa encontrada no banco de dados.");
                return;
            }

            var token = _tokenCache.ObterToken().NormalizeBearerToken();
            var response = await _correiosApi.VerificarAtualizacaoAsync(token);

            if (response == null)
            {
                Uninter.Core.V5.Log.Logger.Warning("Resposta da API de atualização é nula. DataAtualizacaoCorreios não foi atualizada.");
                return;
            }

            await _configuracaoRepository.AtualizarDataAtualizacaoCorreiosAsync(configuracao.Id, response.AtualizadoEm);

            Uninter.Core.V5.Log.Logger.Information(
                $"DataAtualizacaoCorreios atualizada com sucesso: {response.AtualizadoEm:yyyy-MM-dd HH:mm:ss}"
            );
        }
        catch (ApiException apiEx)
        {
            Uninter.Core.V5.Log.Logger.Error(
                $"Erro ao consultar API dos Correios ao atualizar DataAtualizacaoCorreios. Status: {apiEx.StatusCode}", apiEx);
            throw;
        }
        catch (Exception ex)
        {
            Uninter.Core.V5.Log.Logger.Error("Erro ao atualizar DataAtualizacaoCorreios no banco de dados.", ex);
            throw;
        }
    }
}
