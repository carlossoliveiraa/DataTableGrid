using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Uninter.Core.V5.Log;
using Uninter.Correios.Domain.Interfaces.Infra;
using Uninter.Correios.Domain.Interfaces.Service;
using Uninter.Correios.Domain.Request.ConfiguracaoAplicacao;
using Uninter.Correios.Domain.Response.ConfiguracaoAplicacao;

namespace Uninter.Correios.Service.Services;

public class CorreiosConfiguracaoService : ICorreiosConfiguracaoService
{
    private readonly ICorreiosConfiguracaoRepository _repository;
    private readonly ICorreiosTokenCache _tokenCache;

    public CorreiosConfiguracaoService(ICorreiosConfiguracaoRepository repository, ICorreiosTokenCache tokenCache)
    {
        _repository = repository;
        _tokenCache = tokenCache;
    }

    public async Task<System.DateTime?> RecarregarTokenCacheAsync()
    {
        await _tokenCache.RecarregarAsync(_repository);
        return _tokenCache.ObterDataExpiracao();
    }

    public async Task<IEnumerable<CorreiosConfiguracaoResponse>> ListarTodosAsync()
    {
        var lista = await _repository.ListarTodosAsync();
        return lista.Select(Map);
    }

    public async Task<CorreiosConfiguracaoResponse> ObterPorIdAsync(int id)
    {
        var entidade = await _repository.ObterPorIdAsync(id);
        return entidade == null ? null : Map(entidade);
    }

    public async Task<int> InserirAsync(CorreiosConfiguracaoInserirRequest request)
    {
        var insertRequest = new CorreiosConfiguracaoInserirRequest(request.Token, request.Observacao, request.CriadoPor);

        return await _repository.InserirAsync(insertRequest);
    }

    public async Task AtualizarAsync(int id, string token, string? observacao = null)
    {
        var existente = await _repository.ObterPorIdAsync(id);
        if (existente == null)
        {
            Logger.Information($"CorreiosApi - AtualizarAsync - Configuração com Id {id} não encontrada.");
            throw new KeyNotFoundException($"Configuração com Id {id} não encontrada.");
        }           

        var atualizarRequest = new CorreiosConfiguracaoAtualizarRequest(token, observacao);

        await _repository.AtualizarAsync(id, atualizarRequest);
    }

    public async Task ExcluirLogicoAsync(int id)
    {
        var existente = await _repository.ObterPorIdAsync(id);
        if (existente == null)
            throw new KeyNotFoundException($"Configuração com Id {id} não encontrada.");

        await _repository.ExcluirLogicoAsync(id);
    }

    private static CorreiosConfiguracaoResponse Map(Domain.Models.CorreiosConfiguracao e) => new()
    {
        Id = e.Id,
        Token = e.Token,
        EnderecoIp = e.EnderecoIp,
        CriadoEm = e.CriadoEm,
        AtualizadoEm = e.AtualizadoEm,
        ExpiraEm = e.ExpiraEm,
        Ativo = e.Ativo,
        Observacao = e.Observacao,
        CriadoPor = e.CriadoPor,
        DataAtualizacaoCorreios = e.DataAtualizacaoCorreios,
        EstaExpirado = e.EstaExpirado(),
        DiasParaExpirar = e.DiasParaExpirar()
    };
}
