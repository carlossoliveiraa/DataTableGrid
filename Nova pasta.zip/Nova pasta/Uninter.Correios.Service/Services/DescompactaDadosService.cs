using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Hangfire.Console;
using Hangfire.Server;

using Microsoft.Extensions.Options;

using Uninter.Correios.CrossCutting.Configurations;
using Uninter.Correios.CrossCutting.Contract;
using Uninter.Correios.Domain.Interfaces.Service;

namespace Uninter.Correios.Service.Services;

/// <summary>
/// Serviço responsável APENAS pela descompactação de arquivos ZIP.
/// Não move e não remove arquivos após extração.
/// </summary>
public class DescompactaDadosService : IDescompactaDadosService
{
    private readonly IOptions<AppSettings> _appSettings;
    private readonly IAppLogger _logger;

    public DescompactaDadosService(IOptions<AppSettings> appSettings, IAppLogger logger)
    {
        _appSettings = appSettings;
        _logger = logger;
    }

    /// <summary>
    /// Descompacta o arquivo principal eDNE_Basico.zip e seus arquivos internos.
    /// Arquivos com "Delta" no nome vão para eDNE_DELTA, os demais para eDNE_Basico_FULL.
    /// </summary>
    public async Task UnzipAsync(PerformContext context = null)
    {
        var arq = _appSettings.Value.CorreiosArquivos;
        var pastaZip = _appSettings.Value.CaminhoArquivosZipados;
        var raiz = _appSettings.Value.CaminhoProcessarArquivos;
        var pastaEntrada = Path.Combine(raiz, arq.PastaEntrada);
        var arquivoPrincipal = Path.Combine(pastaZip, arq.NomeArquivoZip);

        _logger.Information("ZipCode - === DESCOMPACTAÇÃO INICIADA ===");
        _logger.Information($"ZipCode - Arquivo principal: {arquivoPrincipal}");
        
        context?.WriteLine("📦 === DESCOMPACTAÇÃO INICIADA ===");
        context?.WriteLine($"📁 Arquivo: {Path.GetFileName(arquivoPrincipal)}");

        // Validar se o arquivo principal existe
        if (!File.Exists(arquivoPrincipal))
        {
            _logger.Warning($"ZipCode - Arquivo principal não encontrado: {arquivoPrincipal}");
            context?.WriteLine($"⚠️ Arquivo não encontrado: {Path.GetFileName(arquivoPrincipal)}");
            return;
        }

        // BACKUP DOS ARQUIVOS EXISTENTES ANTES DE DESCOMPACTAR
        var pastaBkp = Path.Combine(pastaEntrada, arq.PastaBackup);
        Directory.CreateDirectory(pastaBkp);
        
        if (Directory.Exists(pastaEntrada))
        {
            var dataAtual = DateTime.Now.ToString("yyyyMMdd");
            var pastasFull = Directory.GetDirectories(pastaEntrada, $"{arq.PastaDescompactacaoFull}*", SearchOption.TopDirectoryOnly);
            var pastasDelta = Directory.GetDirectories(pastaEntrada, $"{arq.PastaDescompactacaoDelta}*", SearchOption.TopDirectoryOnly);
            
            // Backup de FULL
            if (pastasFull.Length > 0)
            {
                try
                {
                    var pastaFull = pastasFull[0];
                    var nomeBackup = $"{arq.PastaDescompactacaoFull}_{dataAtual}";
                    var caminhoBackup = Path.Combine(pastaBkp, nomeBackup);
                    
                    context?.WriteLine($"💾 Backup: {arq.PastaDescompactacaoFull} → {arq.PastaBackup}/{nomeBackup}");
                    _logger.Information($"ZipCode - Backup: {Path.GetFileName(pastaFull)} → {arq.PastaBackup}/{nomeBackup}");
                    
                    // Limpar backup anterior de FULL
                    foreach (var dir in Directory.GetDirectories(pastaBkp, $"{arq.PastaDescompactacaoFull}*"))
                    {
                        Directory.Delete(dir, recursive: true);
                    }
                    
                    Directory.Move(pastaFull, caminhoBackup);
                    context?.WriteLine($"✅ Backup FULL criado");
                }
                catch (Exception ex)
                {
                    _logger.Warning($"ZipCode - Erro ao fazer backup FULL: {ex.Message}");
                    context?.WriteLine($"⚠️  Erro backup FULL: {ex.Message}");
                }
            }
            
            // Backup de DELTA
            if (pastasDelta.Length > 0)
            {
                try
                {
                    var pastaDelta = pastasDelta[0];
                    var nomeBackup = $"{arq.PastaDescompactacaoDelta}_{dataAtual}";
                    var caminhoBackup = Path.Combine(pastaBkp, nomeBackup);
                    
                    context?.WriteLine($"💾 Backup: {arq.PastaDescompactacaoDelta} → {arq.PastaBackup}/{nomeBackup}");
                    _logger.Information($"ZipCode - Backup: {Path.GetFileName(pastaDelta)} → {arq.PastaBackup}/{nomeBackup}");
                    
                    // Limpar backup anterior de DELTA
                    foreach (var dir in Directory.GetDirectories(pastaBkp, $"{arq.PastaDescompactacaoDelta}*"))
                    {
                        Directory.Delete(dir, recursive: true);
                    }
                    
                    Directory.Move(pastaDelta, caminhoBackup);
                    context?.WriteLine($"✅ Backup DELTA criado");
                }
                catch (Exception ex)
                {
                    _logger.Warning($"ZipCode - Erro ao fazer backup DELTA: {ex.Message}");
                    context?.WriteLine($"⚠️  Erro backup DELTA: {ex.Message}");
                }
            }
            
            // Apagar outras pastas/arquivos da raiz de Entrada (exceto bkp)
            context?.WriteLine("🧹 Limpando pasta Entrada...");
            foreach (var dir in Directory.GetDirectories(pastaEntrada))
            {
                if (!dir.EndsWith(arq.PastaBackup, StringComparison.OrdinalIgnoreCase))
                {
                    try { Directory.Delete(dir, recursive: true); }
                    catch (Exception ex) { _logger.Warning($"ZipCode - Falha ao remover diretório {dir}: {ex.Message}"); }
                }
            }
            foreach (var file in Directory.GetFiles(pastaEntrada))
            {
                try { File.Delete(file); }
                catch (Exception ex) { _logger.Warning($"ZipCode - Falha ao remover arquivo {file}: {ex.Message}"); }
            }
        }
        else
        {
            Directory.CreateDirectory(pastaEntrada);
        }

        // Criar pasta temporária para extração inicial
        var pastaTempPrincipal = Path.Combine(pastaEntrada, "_temp_principal");
        Directory.CreateDirectory(pastaTempPrincipal);

        var progressBar = context?.WriteProgressBar();
        
        try
        {
            // ETAPA 1: Descompactar arquivo principal (0-30%)
            _logger.Information($"ZipCode - [0%] Extraindo arquivo principal: {Path.GetFileName(arquivoPrincipal)}...");
            context?.WriteLine($"📂 [0%] Extraindo arquivo principal...");
            progressBar?.SetValue(0);
            
            // Usar encoding CP850 (DOS Latin-1) que é comum em ZIPs brasileiros
            ExtrairZipComEncodingCorreto(arquivoPrincipal, pastaTempPrincipal);
            
            progressBar?.SetValue(30);
            _logger.Information($"ZipCode - [30%] Arquivo principal extraído com sucesso");
            context?.WriteLine($"✅ [30%] Arquivo principal extraído");

            // ETAPA 2: Localizar arquivos ZIP internos (30-40%)
            var zipsInternos = Directory.GetFiles(pastaTempPrincipal, "*.zip", SearchOption.AllDirectories);
            
            if (zipsInternos.Length == 0)
            {
                _logger.Warning("ZipCode - Nenhum arquivo ZIP interno encontrado");
                context?.WriteLine("⚠️ Nenhum arquivo ZIP interno encontrado");
                progressBar?.SetValue(100);
                return;
            }

            progressBar?.SetValue(40);
            context?.WriteLine($"📦 [40%] {zipsInternos.Length} arquivo(s) interno(s) encontrado(s)");
            _logger.Information($"ZipCode - {zipsInternos.Length} arquivo(s) ZIP interno(s) encontrado(s)");

            // ETAPA 3: Descompactar arquivos internos (40-95%)
            var progressoPorArquivo = 55.0 / zipsInternos.Length;
            var progressoAtual = 40.0;

            for (int i = 0; i < zipsInternos.Length; i++)
            {
                var zipInterno = zipsInternos[i];
                var nomeZipInterno = Path.GetFileName(zipInterno);
                
                // Identificar o tipo pelo nome do arquivo
                var isDelta = nomeZipInterno.Contains("Delta", StringComparison.OrdinalIgnoreCase);
                var nomePastaDestino = isDelta ? arq.PastaDescompactacaoDelta : arq.PastaDescompactacaoFull;
                var pastaDestinoInterno = Path.Combine(pastaEntrada, nomePastaDestino);
                
                Directory.CreateDirectory(pastaDestinoInterno);
                
                progressoAtual += progressoPorArquivo;
                var percentual = (int)Math.Round(progressoAtual);
                
                context?.WriteLine($"📂 [{percentual}%] Extraindo {nomeZipInterno} → {nomePastaDestino}/");
                _logger.Information($"ZipCode - [{percentual}%] Extraindo ZIP interno: {nomeZipInterno} → {nomePastaDestino}");
                progressBar?.SetValue(percentual);
                
                // Usar encoding correto para ZIPs dos Correios
                ExtrairZipComEncodingCorreto(zipInterno, pastaDestinoInterno);
                
                _logger.Information($"ZipCode - ZIP interno extraído: {nomeZipInterno}");
                context?.WriteLine($"✅ {nomeZipInterno} extraído com sucesso");
            }

            progressBar?.SetValue(95);

            // ETAPA 4: Limpeza da pasta temporária (95-100%)
            context?.WriteLine($"🧹 [95%] Limpando arquivos temporários...");
            _logger.Information("ZipCode - Limpando pasta temporária...");
            
            try
            {
                Directory.Delete(pastaTempPrincipal, recursive: true);
                _logger.Information("ZipCode - Pasta temporária removida");
            }
            catch (Exception ex)
            {
                _logger.Warning($"ZipCode - Erro ao limpar pasta temporária: {ex.Message}");
            }

            progressBar?.SetValue(100);
            
            _logger.Information("ZipCode - === DESCOMPACTAÇÃO FINALIZADA COM SUCESSO ===");
            context?.WriteLine("═══════════════════════════════════════════════════════════════");
            context?.WriteLine("✅ DESCOMPACTAÇÃO CONCLUÍDA - PROCESSO FINALIZADO");
            context?.WriteLine("═══════════════════════════════════════════════════════════════");
            context?.WriteLine($"⏱️  Fim: {DateTime.Now:dd/MM/yyyy HH:mm:ss}");
        }
        catch (Exception ex)
        {
            _logger.Error($"ZipCode - Erro durante descompactação: {ex.Message}", ex);
            context?.WriteLine($"❌ Erro: {ex.Message}");
            
            // Tentar limpar pasta temporária em caso de erro
            try
            {
                if (Directory.Exists(pastaTempPrincipal))
                    Directory.Delete(pastaTempPrincipal, recursive: true);
            }
            catch (Exception cleanupEx)
            {
                _logger.Warning($"ZipCode - Falha ao limpar pasta temporária: {cleanupEx.Message}");
            }

            throw;
        }
    }

    // Nota: Arquivos são extraídos com encoding Windows-1252 (pt-BR) e lidos diretamente pelos leitores
    // NÃO há conversão UTF-8 - funciona igual ao "Extrair Tudo" do Windows Explorer

    /// <summary>
    /// Extrai ZIP usando Windows-1252 (padrão do Windows pt-BR).
    /// Funciona exatamente como "Extrair Tudo" do Windows Explorer.
    /// </summary>
    private void ExtrairZipComEncodingCorreto(string arquivoZip, string pastaDestino)
    {
        // Limpar pasta destino se já existir
        if (Directory.Exists(pastaDestino))
        {
            Directory.Delete(pastaDestino, recursive: true);
        }
        Directory.CreateDirectory(pastaDestino);

        // Extrair com Windows-1252 (padrão do Windows pt-BR)
        // Funciona igual ao botão direito > Extrair Tudo
        var encoding = Encoding.GetEncoding(1252);
        ZipFile.ExtractToDirectory(arquivoZip, pastaDestino, encoding, overwriteFiles: true);
        
        _logger.Information($"ZipCode - ZIP extraído: {Path.GetFileName(arquivoZip)}");
    }
}
