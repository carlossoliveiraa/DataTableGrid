using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.Extensions.Options;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

using Refit;

using Uninter.Correios.CrossCutting.Configurations;
using Uninter.Correios.CrossCutting.Contract;
using Uninter.Correios.Domain.Enum;
using Uninter.Correios.Domain.Interfaces.Api;
using Uninter.Correios.Domain.Interfaces.Service;
using Uninter.Correios.Domain.Models;
using Uninter.Correios.Domain.Request.Api.Notificacoes.Email;

namespace Uninter.Correios.Service.Services;

/// <summary>
/// Serviço responsável por enviar notificações por email sobre eventos do sistema.
/// Existe um único método público de envio (<see cref="EnviarEmailAsync"/>) que,
/// a partir do <see cref="TipoNotificacaoEmail"/>, monta o assunto e o conteúdo
/// adequados ao evento e dispara o template único configurado.
/// </summary>
public class EmailNotificationService : BaseService, IEmailNotificationService
{
    private readonly INotificacoesApi _notificacoesApi;
    private readonly IOptions<AppSettings> _appSettings;
    private readonly IAppLogger _logger;

    public EmailNotificationService(
        INotificacoesApi notificacoesApi,
        IOptions<AppSettings> appSettings,
        IAppLogger logger)
    {
        _notificacoesApi = notificacoesApi;
        _appSettings = appSettings;
        _logger = logger;
    }

    /// <summary>
    /// Envia uma notificação por email do tipo informado.
    /// Erros são logados e nunca propagados (envio é não-bloqueante).
    /// </summary>
    public async Task EnviarEmailAsync(TipoNotificacaoEmail tipo, EmailDadosNotificacao dados)
    {
        try
        {
            var settings = ObterConfig();
            if (settings == null || !settings.Habilitado)
            {
                _logger.Information($"Email de {tipo} está desabilitado nas configurações.");
                return;
            }

            dados ??= new EmailDadosNotificacao();

            var (templateNome, assunto, conteudo, parametros) = MontarPayload(tipo, dados, settings);

            if (string.IsNullOrWhiteSpace(templateNome))
            {
                _logger.Warning($"Template não configurado para email de {tipo}.");
                return;
            }

            var destinatarios = ObterListaDestinatarios(settings.Destinatarios);
            if (destinatarios.Count == 0)
            {
                _logger.Warning($"Nenhum destinatário configurado para email de {tipo}.");
                return;
            }

            foreach (var destinatario in destinatarios)
            {
                await EnviarParaDestinatarioAsync(destinatario, templateNome, assunto, conteudo, parametros);
            }

            _logger.Information($"Email de {tipo} enviado com sucesso. {MontarContextoLog(tipo, dados)}");
        }
        catch (Exception ex)
        {
            _logger.Error($"Erro ao enviar email de {tipo}: {ex.Message}", ex);
        }
    }

    public async Task VerificarEEnviarEmailTokenExpiracaoAsync(DateTime dataExpiracao)
    {
        var config = ObterConfig();
        if (config == null || !config.Habilitado)
            return;

        var diasRestantes = (dataExpiracao.Date - DateTime.Now.Date).Days;

        if (diasRestantes <= config.DiasAntecedenciaTokenExpiracao && diasRestantes >= 0)
        {
            await EnviarEmailAsync(TipoNotificacaoEmail.TokenExpiracao, new EmailDadosNotificacao
            {
                DataExpiracao = dataExpiracao,
                DiasRestantes = diasRestantes
            });
        }
    }

    #region Métodos Privados

    private EmailNotificationSettings ObterConfig() => _appSettings.Value.EmailNotificationSettings;

    /// <summary>
    /// Resolve template, assunto, conteúdo (texto) e variáveis (@assunto e @conteudo, conforme
    /// cadastro dos templates na ferramenta de notificações — ver
    /// https://notificacoesapidev.uninter.com/) para o tipo informado. O assunto é prefixado com
    /// o ambiente (ex.: "[DEV] ...") quando este não for produção.
    /// </summary>
    private (string TemplateNome, string Assunto, string Conteudo, JObject Parametros) MontarPayload(
        TipoNotificacaoEmail tipo,
        EmailDadosNotificacao dados,
        EmailNotificationSettings settings)
    {
        switch (tipo)
        {
            case TipoNotificacaoEmail.NovaImportacao:
                {
                    var assunto = AplicarPrefixoAmbiente("Nova importação de dados dos Correios realizada");
                    var dataImportacao = dados.DataImportacao ?? DateTime.Now;
                    var conteudo =
                        $"Nova importação de dados dos Correios realizada com sucesso em {dataImportacao:dd/MM/yyyy HH:mm:ss}.\n" +
                        $"Arquivo: {dados.NomeArquivo ?? "N/A"}.\n" +
                        $"Quantidade de registros: {dados.QuantidadeRegistros:N0}.\n" +
                        $"Tempo de processamento: {FormatarTempoProcessamento(dados.TempoProcessamento)}.\n" +
                        "A importação foi concluída sem erros. Todos os dados foram processados e estão disponíveis no sistema.\n" +
                        "Em caso de dúvidas ou problemas, entre em contato com a equipe de TI.";
                    return (settings.TemplateNovaImportacao, assunto, conteudo, MontarVariaveis(conteudo));
                }

            case TipoNotificacaoEmail.FalhaExecucao:
                {
                    var assunto = AplicarPrefixoAmbiente("Falha na importação de dados dos Correios");
                    var dataFalha = dados.DataFalha ?? DateTime.Now;
                    var conteudo =
                        $"ATENÇÃO! Falha na importação de dados dos Correios em {dataFalha:dd/MM/yyyy HH:mm:ss}.\n" +
                        $"Arquivo: {dados.NomeArquivo ?? "N/A"}.\n" +
                        $"Erro: {dados.MensagemErro ?? "Erro não especificado"}.\n" +
                        $"Detalhes técnicos: {dados.StackTrace ?? "Stack trace não disponível"}.\n" +
                        "É necessário verificar e corrigir o problema o mais rápido possível. " +
                        "Entre em contato com a equipe de desenvolvimento para assistência técnica.";
                    return (settings.TemplateFalhaExecucao, assunto, conteudo, MontarVariaveis(conteudo));
                }

            case TipoNotificacaoEmail.TokenExpiracao:
                {
                    var assunto = AplicarPrefixoAmbiente("Token da API dos Correios está próximo de expirar");
                    var dataExpiracao = dados.DataExpiracao ?? DateTime.Now;
                    var conteudo =
                        $"O token de autenticação da API dos Correios expirará em {dados.DiasRestantes} dias ({dataExpiracao:dd/MM/yyyy}).\n" +
                        "Para garantir o funcionamento contínuo do sistema de importação, é necessário renovar o token antes dessa data.\n" +
                        "Como renovar o token: 1) Acesse o site dos Correios; 2) Faça login com suas credenciais; " +
                        "3) Gere um novo token de autenticação; 4) Atualize o token no sistema de integração.\n" +
                        "Em caso de dúvidas, entre em contato com a equipe de TI.";
                    return (settings.TemplateTokenExpiracao, assunto, conteudo, MontarVariaveis(conteudo));
                }

            default:
                throw new ArgumentOutOfRangeException(nameof(tipo), tipo, "Tipo de notificação não suportado.");
        }
    }

    private static JObject MontarVariaveis(string conteudo) => new JObject
    {
        // O template cadastrado na ferramenta de notificações registra apenas a variável
        // `conteudo`. O assunto é enviado em campo dedicado da requisição (`Assunto`) via
        // endpoint /personalizado/assunto/add, então NÃO deve ir no JsonReplaceVariaveis —
        // caso contrário a API responde com "assunto não cadastrado como variável.".
        { "conteudo", conteudo }
    };

    private string AplicarPrefixoAmbiente(string assunto)
    {
        var ambiente = _appSettings.Value?.Ambiente?.Trim();
        if (string.IsNullOrWhiteSpace(ambiente))
            return assunto;

        if (ambiente.Equals("PROD", StringComparison.OrdinalIgnoreCase) ||
            ambiente.Equals("PRODUCTION", StringComparison.OrdinalIgnoreCase))
        {
            return assunto;
        }

        return $"[{ambiente.ToUpperInvariant()}] {assunto}";
    }

    private static string MontarContextoLog(TipoNotificacaoEmail tipo, EmailDadosNotificacao dados)
    {
        return tipo switch
        {
            TipoNotificacaoEmail.NovaImportacao => $"Arquivo: {dados.NomeArquivo}",
            TipoNotificacaoEmail.FalhaExecucao => $"Arquivo: {dados.NomeArquivo}",
            TipoNotificacaoEmail.TokenExpiracao => $"Dias restantes: {dados.DiasRestantes}",
            _ => string.Empty
        };
    }

    private async Task EnviarParaDestinatarioAsync(string destinatario, string templateNome, string assunto, string conteudo, JObject parametros)
    {
        if (string.IsNullOrWhiteSpace(destinatario))
        {
            _logger.Warning("Destinatário vazio ao enviar email. Envio ignorado.");
            return;
        }

        // 1ª tentativa: buscar o HTML do template cadastrado e renderizá-lo localmente
        // (substituindo os placeholders), depois enviar pelo endpoint /texto/add. Essa
        // abordagem evita os erros de validação do endpoint /personalizado/* (ex.: "assunto
        // não cadastrado como variável" / "Template inválido para este envio") porque não
        // depende do contrato de variáveis nem da categoria do template.
        if (!string.IsNullOrWhiteSpace(templateNome))
        {
            var enviado = await TentarEnviarComTemplateAsync(destinatario, templateNome, assunto, conteudo, parametros);
            if (enviado)
                return;

            _logger.Warning(
                $"Envio via template '{templateNome}' falhou para {destinatario}. Aplicando fallback de email simples (texto) para garantir a entrega.");
        }

        // 2ª tentativa (fallback): qualquer falha no envio com template (template inválido,
        // indisponibilidade da API, erro HTTP, exceção transitória) cai aqui. O objetivo é
        // garantir que a notificação chegue ao destinatário usando o endpoint /texto/add
        // com o conteúdo padrão de fallback.
        var enviadoTexto = await EnviarEmailTextoAsync(destinatario, assunto, EmailFallbackTemplate.Render(assunto, conteudo));
        if (!enviadoTexto)
        {
            _logger.Error(
                $"Ambas as tentativas de envio (template e texto) falharam para {destinatario}. Email NÃO foi entregue.",
                null);
        }
    }

    /// <summary>
    /// Tenta enviar via template personalizado seguindo o fluxo: GET do HTML do template,
    /// renderização local dos placeholders (<c>@assunto</c>, <c>@conteudo</c> e quaisquer
    /// variáveis adicionais em <paramref name="parametros"/>), e POST pelo endpoint
    /// <c>/v1/email/fila/integracao/texto/add</c>. Retorna <c>true</c> apenas em caso de
    /// sucesso confirmado pela API. Qualquer falha (template não encontrado, erro HTTP,
    /// exceção transitória) retorna <c>false</c> para acionar o fallback de texto.
    /// </summary>
    private async Task<bool> TentarEnviarComTemplateAsync(string destinatario, string templateNome, string assunto, string conteudo, JObject parametros)
    {
        try
        {
            var templateResponse = await _notificacoesApi.BuscarConteudoHtml(templateNome);

            if (templateResponse == null || !templateResponse.Success || string.IsNullOrWhiteSpace(templateResponse.Data))
            {
                var corpo = templateResponse == null ? "<sem resposta>" : JsonConvert.SerializeObject(templateResponse);
                _logger.Warning($"Não foi possível obter o HTML do template '{templateNome}' para {destinatario}. Resposta: {corpo}");
                return false;
            }

            var htmlRenderizado = RenderizarTemplate(templateResponse.Data, assunto, conteudo, parametros);
            return await EnviarEmailTextoAsync(destinatario, assunto, htmlRenderizado);
        }
        catch (ApiException apiEx)
        {
            _logger.Error(
                $"Erro HTTP ao buscar template '{templateNome}' para {destinatario}: {(int)apiEx.StatusCode} {apiEx.StatusCode}. " +
                $"Conteúdo: {apiEx.Content}.",
                apiEx);

            // Qualquer erro HTTP aciona o fallback — o requisito é a entrega da notificação.
            return false;
        }
        catch (Exception ex)
        {
            _logger.Error($"Erro ao processar template '{templateNome}' para {destinatario}: {ex.Message}", ex);
            return false; // aciona fallback também em erros não-HTTP para garantir a entrega
        }
    }

    /// <summary>
    /// Substitui no HTML do template os placeholders no formato <c>@nome</c> pelos valores
    /// fornecidos. Faz a substituição manualmente (case-insensitive) para não depender da
    /// validação de variáveis do endpoint <c>/personalizado/*</c> nem da grafia exata
    /// (<c>@Assunto</c>, <c>@assunto</c>, <c>@ASSUNTO</c> são todos aceitos).
    /// </summary>
    private static string RenderizarTemplate(string html, string assunto, string conteudo, JObject parametros)
    {
        var resultado = html ?? string.Empty;

        // Conteúdo é texto plano: quebras de linha precisam virar <br /> para renderizar no HTML.
        var conteudoHtml = (conteudo ?? string.Empty).Replace("\r\n", "\n").Replace("\n", "<br />");

        resultado = SubstituirPlaceholder(resultado, "assunto", assunto ?? string.Empty);
        resultado = SubstituirPlaceholder(resultado, "conteudo", conteudoHtml);

        if (parametros != null)
        {
            foreach (var prop in parametros.Properties())
            {
                resultado = SubstituirPlaceholder(resultado, prop.Name, prop.Value?.ToString() ?? string.Empty);
            }
        }

        return resultado;
    }

    /// <summary>
    /// Substitui ocorrências de <c>@{nome}</c> no HTML de forma case-insensitive,
    /// preservando o conteúdo dos demais trechos. Usa <see cref="System.Text.RegularExpressions.Regex"/>
    /// com <c>MatchEvaluator</c> para que caracteres especiais (<c>$</c>, <c>\</c>) no valor
    /// não sejam interpretados como referências de captura.
    /// </summary>
    private static string SubstituirPlaceholder(string html, string nome, string valor)
    {
        if (string.IsNullOrEmpty(html) || string.IsNullOrEmpty(nome))
            return html;

        var padrao = "@" + System.Text.RegularExpressions.Regex.Escape(nome);
        return System.Text.RegularExpressions.Regex.Replace(
            html,
            padrao,
            _ => valor ?? string.Empty,
            System.Text.RegularExpressions.RegexOptions.IgnoreCase);
    }

    /// <summary>
    /// Envia email simples (sem template) pelo endpoint /texto/add. Usado como fallback quando
    /// o template personalizado não está disponível. Retorna true quando a API confirma o envio.
    /// </summary>
    private async Task<bool> EnviarEmailTextoAsync(string destinatario, string assunto, string conteudo)
    {
        EmailFilaTextoRequest request = null;

        try
        {
            request = new EmailFilaTextoRequest
            {
                Destinatario = destinatario,
                Assunto = assunto ?? string.Empty,
                ConteudoTexto = conteudo ?? string.Empty,
                NomeSistemaOrigem = _appSettings.Value?.AplicacaoNome,
                Anexos = new List<EmailFilaAnexoRequest>()
            };

            var response = await _notificacoesApi.EnviarEmailTexto(request);

            if (response != null && response.Success)
            {
                _logger.Information($"Email (texto) enviado com sucesso para {destinatario}. ID: {response.Data}");
                return true;
            }

            var statusResposta = response == null ? "<sem resposta>" : (response.Success ? "sucesso" : "falha");
            _logger.Warning($"Falha ao enviar email (texto) para {destinatario}. Status: {statusResposta}");
            return false;
        }
        catch (ApiException apiEx)
        {
            _logger.Error(
                $"Erro HTTP ao enviar email (texto) para {destinatario}: {(int)apiEx.StatusCode} {apiEx.StatusCode}.",
                apiEx);
            return false;
        }
        catch (Exception ex)
        {
            _logger.Error($"Erro ao enviar email (texto) para {destinatario}: {ex.Message}", ex);
            return false;
        }
    }

    private static List<string> ObterListaDestinatarios(string destinatariosConfig)
    {
        if (string.IsNullOrWhiteSpace(destinatariosConfig))
            return new List<string>();

        return destinatariosConfig
            .Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(d => d.Trim())
            .Where(d => !string.IsNullOrWhiteSpace(d))
            .ToList();
    }

    private static string FormatarTempoProcessamento(TimeSpan tempo)
    {
        if (tempo.TotalHours >= 1)
            return $"{tempo.Hours}h {tempo.Minutes}m {tempo.Seconds}s";
        if (tempo.TotalMinutes >= 1)
            return $"{tempo.Minutes}m {tempo.Seconds}s";
        return $"{tempo.Seconds}s";
    }

    #endregion
}
