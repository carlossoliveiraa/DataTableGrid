#nullable enable

using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

using Refit;

using Uninter.Core.V5.Log;
using Uninter.Correios.CrossCutting.Extensions;
using Uninter.Correios.CrossCutting.Utils;
using Uninter.Correios.Domain.Interfaces.Api;
using Uninter.Correios.Domain.Interfaces.Infra;
using Uninter.Correios.Domain.Interfaces.Service;
using Uninter.Correios.Domain.Request.Api;
using Uninter.Correios.Domain.Response.Api;
using Uninter.Correios.Service.Validators;

namespace Uninter.Correios.Service.Services;


public class EnderecoService(ICorreiosApi correiosApi, ICorreiosTokenCache tokenCache) : BaseService, IEnderecoService
{
    private readonly ICorreiosApi _correiosApi = correiosApi;
    private readonly ICorreiosTokenCache _tokenCache = tokenCache;
    private readonly ListaEnderecosQueryParamsValidator _validator = new();
     
    public async Task<(PagedModelEnderecoResponse? Resultado, string? Erro)> ListarEnderecosAsync(ListaEnderecosQueryParams queryParams)
    {
       
        var validationResult = await _validator.ValidateAsync(queryParams);
        if (!validationResult.IsValid)
        {
            var errors = string.Join("; ", validationResult.Errors.Select(e => e.ErrorMessage));
            return (null, errors);
        }

        // Cria cópia normalizada para não mutar o request original recebido pelo controller
        var paramsNormalizados = new ListaEnderecosQueryParams
        {
            Logradouro = NormalizarSeNaoVazio(queryParams.Logradouro),
            TipoLogradouro = NormalizarSeNaoVazio(queryParams.TipoLogradouro),
            Bairro = NormalizarSeNaoVazio(queryParams.Bairro),
            Localidade = NormalizarSeNaoVazio(queryParams.Localidade),
            Uf = queryParams.Uf,
            Cep = queryParams.Cep,
            Page = queryParams.Page,
            Size = queryParams.Size
        };

        var token = _tokenCache.ObterToken().NormalizeBearerToken();

        try
        {
            var resultado = await _correiosApi.ListarEnderecosAsync(paramsNormalizados, token);
            return (resultado, null);
        }
        catch (ApiException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
        {
            return (null, "Nenhum endereço encontrado para os parâmetros informados.");
        }
        catch (ApiException ex) when (ex.StatusCode == HttpStatusCode.Unauthorized || ex.StatusCode == HttpStatusCode.Forbidden)
        {
            Logger.Error($"Falha de autenticação ao listar endereços. Status: {(int)ex.StatusCode} {ex.StatusCode}", ex);
            return (null, "Token dos Correios inválido, expirado ou sem autorização para o endpoint configurado. Atualize o token ativo na configuração da aplicação.");
        }
        catch (ApiException ex)
        {
            Logger.Error($"Erro ao listar endereços na API dos Correios. Status: {(int)ex.StatusCode} {ex.StatusCode}. Conteúdo: {ex.Content}", ex);
            return (null, $"Erro ao consultar a API dos Correios ({(int)ex.StatusCode} {ex.StatusCode}).");
        }
        catch (HttpRequestException ex)
        {
            Logger.Error("Falha de rede ao listar endereços.", ex);
            return (null, $"Falha de rede ao consultar a API dos Correios: {ex.Message}");
        }
        catch (Exception ex)
        {
            Logger.Error("Erro inesperado ao listar endereços.", ex);
            return (null, $"Erro inesperado ao consultar a API dos Correios: {ex.GetType().Name} - {ex.Message}");
        }
    }

    private static string? NormalizarSeNaoVazio(string? valor)
        => string.IsNullOrWhiteSpace(valor) ? valor : EnderecoNormalizer.Normalizar(valor);
}
