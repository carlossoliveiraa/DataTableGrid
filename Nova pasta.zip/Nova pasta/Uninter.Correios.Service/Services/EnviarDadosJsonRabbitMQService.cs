using System;
using System.Data.Common;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Hangfire.Console;
using Hangfire.Server;
using Microsoft.Extensions.Options;
using Uninter.Correios.CrossCutting;
using Uninter.Correios.CrossCutting.Configurations;
using Uninter.Correios.CrossCutting.Contract;
using Uninter.Correios.CrossCutting.Helpers;
using Uninter.Correios.CrossCutting.Messaging;
using Uninter.Correios.Domain.Interfaces.Service;

#nullable enable

namespace Uninter.Correios.Service.Services;

/// <summary>
/// Serviço responsável por ler arquivos JSON e enviar para RabbitMQ.
/// Baseado no padrão do Uninter.ZipCode.Api
/// </summary>
public class EnviarDadosJsonRabbitMQService : IEnviarDadosJsonRabbitMQService
{
    private readonly IAppLogger _logger;
    private readonly string _pastaJson;
    private readonly string _pastaProcessado;
    private readonly RabbitMQSettings _rabbitMQSettings;

    public EnviarDadosJsonRabbitMQService(
        IAppLogger logger,
        IOptions<AppSettings> configuration,
        IOptions<RabbitMQSettings> rabbitMQSettings)
    {
        _logger = logger;
        _rabbitMQSettings = rabbitMQSettings.Value;
        
        // Caminhos configuráveis via CorreiosArquivos:PastaJson / PastaJsonProcessado
        var caminhoBase = configuration.Value.CaminhoProcessarArquivos;
        var arq = configuration.Value.CorreiosArquivos;
        _pastaJson = Path.Combine(caminhoBase, arq.PastaJson);
        _pastaProcessado = Path.Combine(caminhoBase, arq.PastaJsonProcessado);
        
        // Garantir que pastas existem
        Directory.CreateDirectory(_pastaJson);
        Directory.CreateDirectory(_pastaProcessado);
    }

    public async Task ProcessarArquivosJsonAsync(PerformContext? context = null)
    {
        try
        {
            EscreverNoConsoleSemFalhar(context, "📂 Verificando pasta de arquivos JSON...");
            _logger.Information($"EnviarDadosJsonRabbitMQ - Iniciando processamento: {_pastaJson}");

            if (!Directory.Exists(_pastaJson))
            {
                EscreverNoConsoleSemFalhar(context, "⚠️  Pasta Json não encontrada.");
                _logger.Warning($"EnviarDadosJsonRabbitMQ - Pasta não encontrada: {_pastaJson}");
                return;
            }

            // Buscar arquivos JSON
            var arquivosJson = Directory.GetFiles(_pastaJson, "*.json")
                .OrderBy(f => f)
                .ToList();

            if (!arquivosJson.Any())
            {
                EscreverNoConsoleSemFalhar(context, "✅ Nenhum arquivo JSON para processar.");
                _logger.Information("EnviarDadosJsonRabbitMQ - Nenhum arquivo encontrado");
                return;
            }

            EscreverNoConsoleSemFalhar(context, $"📄 {arquivosJson.Count} arquivo(s) encontrado(s)");
            EscreverNoConsoleSemFalhar(context, $"🔌 Conectando ao RabbitMQ: {_rabbitMQSettings.Exchange}");

            int totalPublicados = 0;

            // Criar publicador RabbitMQ (similar ao ProducerHandler do ZipCode)
            using var publisher = new RabbitMQPublisher(_rabbitMQSettings, _logger);

            // Processar cada arquivo
            foreach (var caminhoArquivo in arquivosJson)
            {
                var nomeArquivo = Path.GetFileName(caminhoArquivo);
                
                try
                {
                    EscreverNoConsoleSemFalhar(context, $"📖 Processando: {nomeArquivo}");

                    // Ler e deserializar JSON
                    var jsonContent = await ReadFileWithRetryAsync(caminhoArquivo);
                    
                    if (string.IsNullOrWhiteSpace(jsonContent))
                    {
                        EscreverNoConsoleSemFalhar(context, "   ⚠️  Arquivo vazio, ignorando... ");
                        continue;
                    }
                                        
                    List<PostalInfo>? postalInfoList = null;
                    
                    try
                    {
                        postalInfoList = JsonSerializer.Deserialize<List<PostalInfo>>(
                            jsonContent,
                            new JsonSerializerOptions 
                            { 
                                PropertyNameCaseInsensitive = true
                            });
                    }
                    catch (JsonException jsonEx)
                    {
                        EscreverNoConsoleSemFalhar(context, $"   ❌ Erro ao deserializar JSON: {jsonEx.Message}");
                        _logger.Error($"EnviarDadosJsonRabbitMQ - Erro deserialização {nomeArquivo}", jsonEx);
                        continue;
                    }

                    if (postalInfoList == null || !postalInfoList.Any())
                    {
                        EscreverNoConsoleSemFalhar(context, "   ⚠️  Nenhum registro PostalInfo no arquivo");
                        continue;
                    }

                    // Publicar cada PostalInfo no RabbitMQ
                    EscreverNoConsoleSemFalhar(context, $"   📤 Publicando {postalInfoList.Count:N0} registros no RabbitMQ...");
                    _logger.Information($"EnviarDadosJsonRabbitMQ - Iniciando publicação de {postalInfoList.Count} registros");
                    
                    // Validar routing key uma única vez antes do loop
                    if (string.IsNullOrWhiteSpace(_rabbitMQSettings.RoutingKey))
                        throw new InvalidOperationException("RoutingKey não configurada no appsettings RabbitMQ:RoutingKey");
                    
                    int publicadosArquivo = 0;
                    const int tamanhoBatch = 20000;
                    int totalRegistros = postalInfoList.Count;
                    int totalBatches = (int)Math.Ceiling(totalRegistros / (double)tamanhoBatch);
                    
                    // Processar em lotes de 20.000 mensagens.
                    for (int batchIndex = 0; batchIndex < totalBatches; batchIndex++)
                    {
                        int inicio = batchIndex * tamanhoBatch;
                        int quantidade = Math.Min(tamanhoBatch, totalRegistros - inicio);
                        var batch = postalInfoList.Skip(inicio).Take(quantidade).ToList();
                        
                        EscreverNoConsoleSemFalhar(context, $" 📦 Lote {batchIndex + 1}/{totalBatches} ({quantidade:N0} registros)...");
                        
                        foreach (var postalInfo in batch)
                        {
                            try
                            {
                                publisher.Publish(postalInfo, _rabbitMQSettings.RoutingKey);
                                totalPublicados++;
                                publicadosArquivo++;
                            }
                            catch (Exception ex)
                            {
                                EscreverNoConsoleSemFalhar(context, $"      ⚠️  Erro ao publicar registro (ZipCode={postalInfo.ZipCode}): {ex.Message}");
                                _logger.Error($"EnviarDadosJsonRabbitMQ - Erro ao publicar (ZipCode={postalInfo.ZipCode}): {ex.Message}", ex);
                            }
                        }
                        
                        // Feedback de progresso
                        double percentual = ((batchIndex + 1) / (double)totalBatches) * 100;
                        EscreverNoConsoleSemFalhar(context, $"      ✓ Progresso: {publicadosArquivo:N0}/{totalRegistros:N0} ({percentual:F1}%)");
                        
                        // Pequeno delay entre lotes para não sobrecarregar o RabbitMQ
                        if (batchIndex < totalBatches - 1)
                        {
                            await Task.Delay(100);
                        }
                    }

                    EscreverNoConsoleSemFalhar(context, $"   ✅ {publicadosArquivo:N0} registros publicados");
                    _logger.Information($"EnviarDadosJsonRabbitMQ - {publicadosArquivo} registros publicados: {nomeArquivo}");
                    
                    // Limpar pasta jsonProcessado antes de mover o arquivo atual
                    LimparPastaProcessado(context);
                    
                    // Mover arquivo para pasta processado
                    MoverArquivoParaProcessado(caminhoArquivo, nomeArquivo, context);
                    
                    // Liberar memória
                    postalInfoList.Clear();
                    postalInfoList = null;
                }
                catch (Exception ex)
                {
                    EscreverNoConsoleSemFalhar(context, $"   ❌ Erro: {ex.Message}");
                    _logger.Error($"EnviarDadosJsonRabbitMQ - Erro ao processar {nomeArquivo}", ex);
                }
            }

            EscreverNoConsoleSemFalhar(context, $"✅ Processamento concluído: {totalPublicados:N0} mensagens publicadas!");
            _logger.Information($"EnviarDadosJsonRabbitMQ - Total publicado: {totalPublicados} mensagens");
        }
        catch (Exception ex)
        {
            EscreverNoConsoleSemFalhar(context, $"❌ Erro crítico: {ex.Message}");
            _logger.Error("EnviarDadosJsonRabbitMQ - Erro crítico", ex);
            throw;
        }
    }

    /// <summary>
    /// Limpa todos os arquivos da pasta jsonProcessado
    /// </summary>
    private void LimparPastaProcessado(PerformContext? context)
    {
        try
        {
            if (!Directory.Exists(_pastaProcessado))
            {
                return;
            }

            var arquivos = Directory.GetFiles(_pastaProcessado, "*.json");
            if (arquivos.Length > 0)
            {
                EscreverNoConsoleSemFalhar(context, $"🧹 Limpando {arquivos.Length} arquivo(s) da pasta jsonProcessado...");
                
                foreach (var arquivo in arquivos)
                {
                    try
                    {
                        File.Delete(arquivo);
                        _logger.Information($"EnviarDadosJsonRabbitMQ - Arquivo removido: {Path.GetFileName(arquivo)}");
                    }
                    catch (Exception ex)
                    {
                        _logger.Warning($"EnviarDadosJsonRabbitMQ - Erro ao remover arquivo: {ex.Message}");
                    }
                }
                
                EscreverNoConsoleSemFalhar(context, "   ✅ Pasta jsonProcessado limpa");
            }
        }
        catch (Exception ex)
        {
            EscreverNoConsoleSemFalhar(context, $"   ⚠️  Erro ao limpar pasta: {ex.Message}");
            _logger.Warning($"EnviarDadosJsonRabbitMQ - Erro ao limpar pasta jsonProcessado: {ex.Message}");
        }
    }

    /// <summary>
    /// Move arquivo JSON processado para jsonProcessado/ sem renomear
    /// </summary>
    private void MoverArquivoParaProcessado(string caminhoOrigem, string nomeArquivo, PerformContext? context)
    {
        try
        {
            var caminhoDestino = Path.Combine(_pastaProcessado, nomeArquivo);
            File.Move(caminhoOrigem, caminhoDestino);
            
            EscreverNoConsoleSemFalhar(context, $"   📦 Movido para: jsonProcessado\\{nomeArquivo}");
            _logger.Information($"EnviarDadosJsonRabbitMQ - Arquivo movido: jsonProcessado/{nomeArquivo}");
        }
        catch (Exception ex)
        {
            EscreverNoConsoleSemFalhar(context, $"   ⚠️  Erro ao mover arquivo: {ex.Message}");
            _logger.Warning($"EnviarDadosJsonRabbitMQ - Não foi possível mover arquivo {nomeArquivo}: {ex.Message}");
            // Não propaga o erro, pois o arquivo já foi processado
        }
    }

    private void EscreverNoConsoleSemFalhar(PerformContext? context, string mensagem)
    {
        if (context is null)
        {
            return;
        }

        try
        {
            context.WriteLine(mensagem);
        }
        catch (Exception ex) when (ex is InvalidOperationException or ObjectDisposedException or DbException)
        {
            _logger.Warning($"EnviarDadosJsonRabbitMQ - Falha ao escrever no console do Hangfire (ignorado): {ex.Message}");
        }
    }

    /// <summary>
    /// Lê arquivo com retry (caso esteja em uso)
    /// </summary>
    private static async Task<string> ReadFileWithRetryAsync(string path, int maxRetries = 3)
    {
        for (int i = 0; i < maxRetries; i++)
        {
            try
            {
                return await File.ReadAllTextAsync(path);
            }
            catch (IOException) when (i < maxRetries - 1)
            {
                await Task.Delay(1000);
            }
        }
        
        return await File.ReadAllTextAsync(path);
    }
}
