using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

using Hangfire.Console;
using Hangfire.Server;

using Microsoft.Extensions.Options;

using Uninter.Correios.CrossCutting.Configurations;
using Uninter.Correios.CrossCutting.Contract;
using Uninter.Correios.CrossCutting.Helpers;
using Uninter.Correios.Domain.Interfaces.Infra;
using Uninter.Correios.Domain.Interfaces.Service;
using Uninter.Correios.Domain.Models;
using Uninter.Correios.Infra.Readers;

namespace Uninter.Correios.Service.Services;

/// <summary>
/// Serviço responsável pela execução da importação dos dados do eDNE V3.
/// </summary>
public class ExecutaImportadorService : IExecutaImportadorService
{
    private readonly IZipCodeImportRepository _repository;
    private readonly IOptions<AppSettings> _appSettings;
    private readonly IAppLogger _logger;
    private const int BatchSize = 10_000;
    private static readonly string[] SubpastasEntrada = { "delimitado", "fixo" };

    public ExecutaImportadorService(
        IZipCodeImportRepository repository, 
        IOptions<AppSettings> appSettings, 
        IAppLogger logger)
    {
        _repository = repository;
        _appSettings = appSettings;
        _logger = logger;
    }

    public async Task<ImportacaoResultado> ExecutarAsync(PerformContext context = null)
    {
        // Método legado - mantém compatibilidade
        return await ExecutarPorTipoAsync("full", context);
    }

    public async Task<ImportacaoResultado> ExecutarPorTipoAsync(string tipoImportacao, PerformContext context = null)
    {
        var raiz = _appSettings.Value.CaminhoProcessarArquivos;
        var swTotal = Stopwatch.StartNew();
        
        var tipoUpperCase = tipoImportacao.ToUpperInvariant();
        var descricao = tipoUpperCase == "DELTA" ? "DELTA" : "FULL";

        context?.WriteLine($"═══════════════════════════════════════════════════════════════");
        context?.WriteLine($"🚀 IMPORTAÇÃO {descricao} INICIADA");
        context?.WriteLine($"═══════════════════════════════════════════════════════════════");
        context?.WriteLine($"⏱️  Início: {DateTime.Now:dd/MM/yyyy HH:mm:ss}");
        context?.WriteLine("");

        var progressBar = context?.WriteProgressBar();
        int totalInserted = 0, totalUpdated = 0, totalUnchanged = 0;
        var todasMudancas = new List<ChangeRecord>();

        var pastaEntradaBase = Path.Combine(raiz, _appSettings.Value.CorreiosArquivos.PastaEntrada);
        var pastaProcessado = Path.Combine(raiz, _appSettings.Value.CorreiosArquivos.PastaProcessado);
        var pastaErro = Path.Combine(raiz, _appSettings.Value.CorreiosArquivos.PastaErro);
        var pastaJson = Path.Combine(raiz, _appSettings.Value.CorreiosArquivos.PastaJson);

        try
        {
            if (string.IsNullOrWhiteSpace(raiz) || !Directory.Exists(raiz))
            {
                _logger.Warning($"ZipCode - Caminho raiz não encontrado ou não configurado: {raiz}");
                context?.WriteLine($"❌ Caminho raiz não encontrado: {raiz}");
                return ImportacaoResultado.Vazio;
            }

            if (!Directory.Exists(pastaEntradaBase))
            {
                _logger.Warning($"ZipCode - Pasta Entrada não encontrada: {pastaEntradaBase}");
                context?.WriteLine($"❌ Pasta Entrada não encontrada: {pastaEntradaBase}");
                return ImportacaoResultado.Vazio;
            }
            
            // Pasta destino conforme tipo (configurável via CorreiosArquivos:PastaImportacao*)
            var nomePasta = tipoUpperCase == "DELTA"
                ? _appSettings.Value.CorreiosArquivos.PastaImportacaoDelta
                : _appSettings.Value.CorreiosArquivos.PastaImportacaoFull;
            var pastaImportacao = Path.Combine(pastaEntradaBase, nomePasta);
            var pastaDelimitado = Path.Combine(pastaImportacao, "delimitado");
            
            if (!Directory.Exists(pastaImportacao))
            {
                var msg = $"Pasta {descricao} não encontrada: {pastaImportacao}";
                _logger.Warning($"ZipCode - {msg}");
                context?.WriteLine($"❌ {msg}");
                return ImportacaoResultado.Vazio;
            }
            
            if (!Directory.Exists(pastaDelimitado))
            {
                var msg = $"Pasta 'delimitado' não encontrada em: {pastaImportacao}";
                _logger.Warning($"ZipCode - {msg}");
                context?.WriteLine($"❌ {msg}");
                return ImportacaoResultado.Vazio;
            }
            
            _logger.Information($"ZipCode - Pasta {descricao} encontrada: {pastaImportacao}");
            context?.WriteLine($"📁 Pasta {descricao}: {nomePasta}");
            context?.WriteLine($"📁 Arquivos em: {pastaDelimitado}");

            Directory.CreateDirectory(pastaProcessado);
            Directory.CreateDirectory(pastaErro);
            Directory.CreateDirectory(pastaJson);

            _logger.Information($"ZipCode - Pasta Delimitado: {pastaDelimitado}");
            _logger.Information("ZipCode - Limpando tabelas de staging...");
            context?.WriteLine("═══════════════════════════════════════════════════════════════");
            context?.WriteLine("🗑️  ETAPA 0: Limpando Staging (LOG_*)");
            context?.WriteLine("═══════════════════════════════════════════════════════════════");
            progressBar?.SetValue(0);
            await _repository.LimparStagingAsync();
            _logger.Information("ZipCode - Staging limpo.");
            context?.WriteLine("   ✅ Tabelas de staging limpas com sucesso!");
            context?.WriteLine("");
            progressBar?.SetValue(5);

            await ImportarLocalidadesAsync(pastaImportacao, context);
            progressBar?.SetValue(15);
            
            await ImportarBairrosAsync(pastaImportacao, context);
            progressBar?.SetValue(25);

            var (insLog, updLog, unchLog, mudLog) = await ImportarLogradourosAsync(pastaImportacao, context);
            _logger.Information($"ZipCode - >>> LOGRADOUROS MERGE: +{insLog:N0} inseridos | ~{updLog:N0} atualizados | ={unchLog:N0} inalterados");
            totalInserted += insLog; totalUpdated += updLog; totalUnchanged += unchLog;
            todasMudancas.AddRange(mudLog);
            progressBar?.SetValue(50);

            var (insCpc, updCpc, unchCpc, mudCpc) = await ImportarCaixasPostaisAsync(pastaImportacao, context);
            _logger.Information($"ZipCode - >>> CAIXAS POSTAIS MERGE: +{insCpc:N0} inseridos | ~{updCpc:N0} atualizados | ={unchCpc:N0} inalterados");
            totalInserted += insCpc; totalUpdated += updCpc; totalUnchanged += unchCpc;
            todasMudancas.AddRange(mudCpc);
            progressBar?.SetValue(65);

            var (insGu, updGu, unchGu, mudGu) = await ImportarGrandesUsuariosAsync(pastaImportacao, context);
            _logger.Information($"ZipCode - >>> GRANDES USUÁRIOS MERGE: +{insGu:N0} inseridos | ~{updGu:N0} atualizados | ={unchGu:N0} inalterados");
            totalInserted += insGu; totalUpdated += updGu; totalUnchanged += unchGu;
            todasMudancas.AddRange(mudGu);
            progressBar?.SetValue(80);

            var (insUo, updUo, unchUo, mudUo) = await ImportarUnidadesOperacionaisAsync(pastaImportacao, context);
            _logger.Information($"ZipCode - >>> UNIDADES OPERACIONAIS MERGE: +{insUo:N0} inseridos | ~{updUo:N0} atualizados | ={unchUo:N0} inalterados");
            totalInserted += insUo; totalUpdated += updUo; totalUnchanged += unchUo;
            todasMudancas.AddRange(mudUo);
            progressBar?.SetValue(95);

            swTotal.Stop();
            var resumo = $"{descricao} Concluído em {swTotal.Elapsed.TotalMinutes:F1}min | +{totalInserted:N0} inseridos | ~{totalUpdated:N0} atualizados | ={totalUnchanged:N0} inalterados";
            _logger.Information($"ZipCode - === {resumo} ===");
            
            context?.WriteLine("");
            context?.WriteLine("═══════════════════════════════════════════════════════════════");
            context?.WriteLine($"✅ === IMPORTAÇÃO {descricao} CONCLUÍDA ===");
            context?.WriteLine("═══════════════════════════════════════════════════════════════");
            context?.WriteLine($"⏱️  Tempo total: {swTotal.Elapsed.TotalMinutes:F1} minutos ({swTotal.Elapsed.TotalSeconds:F0}s)");
            context?.WriteLine($"📊 Estatísticas:");
            context?.WriteLine($"   • {totalInserted:N0} registros INSERIDOS");
            context?.WriteLine($"   • {totalUpdated:N0} registros ATUALIZADOS");
            context?.WriteLine($"   • {totalUnchanged:N0} registros INALTERADOS");
            context?.WriteLine("");
            
            // Salvar mudanças em JSON se houver alterações
            _logger.Information($"ZipCode - Total de mudanças detectadas: {todasMudancas.Count}");
            
            if (todasMudancas.Any())
            {
                context?.WriteLine($"💾 Salvando {todasMudancas.Count:N0} mudanças em JSON...");
                SalvarMudancasJson(pastaJson, todasMudancas);
                _logger.Information($"ZipCode - {todasMudancas.Count} mudanças salvas em JSON para envio à fila");
                context?.WriteLine($"   ✅ JSON salvo com sucesso!");
                
                // Mostrar algumas mudanças como exemplo
                if (todasMudancas.Count > 0)
                {
                    context?.WriteLine("");
                    context?.WriteLine($"📝 Exemplos de mudanças ({Math.Min(5, todasMudancas.Count)} primeiras):");
                    foreach (var mudanca in todasMudancas.Take(5))
                    {
                        var cep = mudanca.ChavePrimaria.ContainsKey("Id") ? mudanca.ChavePrimaria["Id"]?.ToString() : "?";
                        context?.WriteLine($"   • {mudanca.OperationType} - CEP {cep}");
                    }
                    if (todasMudancas.Count > 5)
                    {
                        context?.WriteLine($"   ... e mais {todasMudancas.Count - 5:N0} mudanças");
                    }
                }
            }
            else
            {
                context?.WriteLine("ℹ️  Nenhuma mudança detectada (tudo igual)");
                context?.WriteLine("   ℹ️  Arquivo JSON não será gerado (sem alterações para enviar ao RabbitMQ)");
                _logger.Information("ZipCode - Nenhuma mudança detectada. JSON não será gerado.");
            }
            
            context?.WriteLine($"✅ === {resumo} ===");

            // Mover pasta inteira para Processado/{yyyy-MM-dd-HH-mm-ss}/
            MoverParaProcessadoComTimestamp(pastaImportacao, pastaProcessado, descricao, context);
            
            progressBar?.SetValue(100);

            return new ImportacaoResultado(totalInserted, totalUpdated, totalUnchanged);
        }
        catch (Exception ex)
        {
            swTotal.Stop();
            _logger.Error($"ZipCode - Erro crítico na importação {descricao} após {swTotal.Elapsed.TotalMinutes:F1}min: {ex.Message}", ex);
            context?.WriteLine($"❌ Erro crítico: {ex.Message}");
            GravarLogErro(pastaErro, ex, swTotal.Elapsed);
            throw;
        }
    }

    private Task ImportarLocalidadesAsync(string pastaEntrada, PerformContext? context) =>
        ImportarStagingAsync(
            pastaEntrada, "LOG_LOCALIDADE.TXT",
            etapa: 1, titulo: "Localidades (Cidades)", label: "LOCALIDADES",
            readerFactory: a => new LeitorLocalidadeV3(a).LerArquivoAsync(),
            bulkInsert: batch => _repository.BulkInsertLocalidadesAsync(batch),
            context);

    private Task ImportarBairrosAsync(string pastaEntrada, PerformContext? context) =>
        ImportarStagingAsync(
            pastaEntrada, "LOG_BAIRRO.TXT",
            etapa: 2, titulo: "Bairros", label: "BAIRROS",
            readerFactory: a => new LeitorBairroV3(a).LerArquivoAsync(),
            bulkInsert: batch => _repository.BulkInsertBairrosAsync(batch),
            context);

    private async Task<(int inserted, int updated, int unchanged, List<ChangeRecord> mudancas)> ImportarLogradourosAsync(string pastaEntrada, PerformContext? context)
    {
        var arquivos = EncontrarArquivosEntrada(pastaEntrada, "LOG_LOGRADOURO_*.TXT");
        if (arquivos.Length == 0) 
        { 
            _logger.Information("ZipCode - LOGRADOUROS - Nenhum arquivo encontrado, pulando.");
            context?.WriteLine("⚠️  LOGRADOUROS - Nenhum arquivo encontrado");
            return (0, 0, 0, new List<ChangeRecord>()); 
        }

        EscreverHeaderEtapa(context, 3, $"Logradouros ({arquivos.Length} UFs - Sequencial)");

        int totalGeral = 0;
        var swTotal = Stopwatch.StartNew();
        
        foreach (var arquivo in arquivos.OrderBy(f => f))
        {
            var uf = ExtrairUF(arquivo);
            var sw = Stopwatch.StartNew();
            
            _logger.Information($"ZipCode - LOGRADOUROS [{uf}] - Carregando {Path.GetFileName(arquivo)}...");
            context?.WriteLine($"   📂 {uf}: processando...");
            
            var totalUf = await ProcessarBatchesAsync(
                new LeitorLogradouroV3(arquivo).LerArquivoAsync(),
                batch => _repository.BulkInsertLogradourosAsync(batch, uf),
                $"LOGRADOUROS [{uf}]",
                null); // Não mostrar progresso individual por UF no Hangfire
            
            totalGeral += totalUf;
            sw.Stop();
            
            context?.WriteLine($"\r   ✅ {uf}: {totalUf:N0} registros em {sw.Elapsed.TotalSeconds:F1}s");
            _logger.Information($"ZipCode - LOGRADOUROS [{uf}] - Concluído: {totalUf:N0} registros em {sw.Elapsed.TotalSeconds:F1}s");
        }

        swTotal.Stop();
        context?.WriteLine("");
        context?.WriteLine($"   📊 Total geral: {totalGeral:N0} logradouros em {swTotal.Elapsed.TotalMinutes:F1} minutos");
        context?.WriteLine("");
        context?.WriteLine("   🔀 Consolidando logradouros em PostalCode...");
        
        _logger.Information($"ZipCode - LOGRADOUROS - Total: {totalGeral:N0} registros no staging. Executando MERGE...");
        
        var resultado = await _repository.MergeLogradourosAsync();
        
        context?.WriteLine($"   🎯 Resultado: {resultado.inserted:N0} inseridos | {resultado.updated:N0} atualizados | {resultado.unchanged:N0} inalterados");
        context?.WriteLine($"   ✅ Logradouros consolidados com sucesso!");
        context?.WriteLine("");
        
        _logger.Information($"ZipCode - >>> LOGRADOUROS MERGE: +{resultado.inserted:N0} inseridos | ~{resultado.updated:N0} atualizados | ={resultado.unchanged:N0} inalterados");
        
        return resultado;
    }

    private Task<(int inserted, int updated, int unchanged, List<ChangeRecord> mudancas)> ImportarCaixasPostaisAsync(string pastaEntrada, PerformContext? context) =>
        ImportarComMergeAsync(
            pastaEntrada, "LOG_CPC.TXT",
            etapa: 4, titulo: "Caixas Postais Comunitárias (CPC)", label: "CAIXAS POSTAIS",
            readerFactory: a => new LeitorCaixaPostalV3(a).LerArquivoAsync(),
            bulkInsert: batch => _repository.BulkInsertCaixasPostaisAsync(batch),
            mergeAsync: () => _repository.MergeCaixasPostaisAsync(),
            context);

    private Task<(int inserted, int updated, int unchanged, List<ChangeRecord> mudancas)> ImportarGrandesUsuariosAsync(string pastaEntrada, PerformContext? context) =>
        ImportarComMergeAsync(
            pastaEntrada, "LOG_GRANDE_USUARIO.TXT",
            etapa: 5, titulo: "Grandes Usuários", label: "GRANDES USUÁRIOS",
            readerFactory: a => new LeitorGrandeUsuarioV3(a).LerArquivoAsync(),
            bulkInsert: batch => _repository.BulkInsertGrandesUsuariosAsync(batch),
            mergeAsync: () => _repository.MergeGrandesUsuariosAsync(),
            context);

    private Task<(int inserted, int updated, int unchanged, List<ChangeRecord> mudancas)> ImportarUnidadesOperacionaisAsync(string pastaEntrada, PerformContext? context) =>
        ImportarComMergeAsync(
            pastaEntrada, "LOG_UNID_OPER.TXT",
            etapa: 6, titulo: "Unidades Operacionais", label: "UNIDADES OPERACIONAIS",
            readerFactory: a => new LeitorUnidadeOperacionalV3(a).LerArquivoAsync(),
            bulkInsert: batch => _repository.BulkInsertUnidadesOperacionaisAsync(batch),
            mergeAsync: () => _repository.MergeUnidadesOperacionaisAsync(),
            context);

    private async Task ImportarStagingAsync<T>(
        string pastaEntrada,
        string nomeArquivo,
        int etapa,
        string titulo,
        string label,
        Func<string, IAsyncEnumerable<T>> readerFactory,
        Func<List<T>, Task> bulkInsert,
        PerformContext? context)
    {
        var arquivo = EncontrarArquivoEntrada(pastaEntrada, nomeArquivo);
        if (arquivo is null)
        {
            _logger.Information($"ZipCode - {label} - Arquivo não encontrado, pulando.");
            context?.WriteLine($"⚠️  {label} - Arquivo não encontrado");
            return;
        }

        EscreverHeaderEtapa(context, etapa, titulo);
        _logger.Information($"ZipCode - {label} - Carregando {Path.GetFileName(arquivo)}...");
        var sw = Stopwatch.StartNew();

        var total = await ProcessarBatchesAsync(readerFactory(arquivo), bulkInsert, label, context);

        sw.Stop();
        context?.WriteLine($"   📁 Leitura completa: {total:N0} registros em {sw.Elapsed.TotalSeconds:F1}s");
        context?.WriteLine($"   ✅ {label} importados no staging!");
        context?.WriteLine("");

        _logger.Information($"ZipCode - {label} - Concluído: {total:N0} registros no staging em {sw.Elapsed.TotalSeconds:F1}s");
    }

    private async Task<(int inserted, int updated, int unchanged, List<ChangeRecord> mudancas)> ImportarComMergeAsync<T>(
        string pastaEntrada,
        string nomeArquivo,
        int etapa,
        string titulo,
        string label,
        Func<string, IAsyncEnumerable<T>> readerFactory,
        Func<List<T>, Task> bulkInsert,
        Func<Task<(int inserted, int updated, int unchanged, List<ChangeRecord> mudancas)>> mergeAsync,
        PerformContext? context)
    {
        var arquivo = EncontrarArquivoEntrada(pastaEntrada, nomeArquivo);
        if (arquivo is null)
        {
            _logger.Information($"ZipCode - {label} - Arquivo não encontrado, pulando.");
            context?.WriteLine($"⚠️  {label} - Arquivo não encontrado");
            return (0, 0, 0, new List<ChangeRecord>());
        }

        EscreverHeaderEtapa(context, etapa, titulo);
        _logger.Information($"ZipCode - {label} - Carregando {Path.GetFileName(arquivo)}...");
        var sw = Stopwatch.StartNew();

        var total = await ProcessarBatchesAsync(readerFactory(arquivo), bulkInsert, label, context);

        sw.Stop();
        context?.WriteLine($"   📁 Leitura completa: {total:N0} registros em {sw.Elapsed.TotalSeconds:F1}s");
        context?.WriteLine("");
        context?.WriteLine("   🔀 Consolidando em PostalCode...");

        _logger.Information($"ZipCode - {label} - Concluído: {total:N0} registros no staging. Executando MERGE...");

        var resultado = await mergeAsync();

        context?.WriteLine($"   🎯 Resultado: {resultado.inserted:N0} inseridos | {resultado.updated:N0} atualizados | {resultado.unchanged:N0} inalterados");
        context?.WriteLine($"   ✅ {label} consolidados com sucesso!");
        context?.WriteLine("");

        _logger.Information($"ZipCode - >>> {label} MERGE: +{resultado.inserted:N0} inseridos | ~{resultado.updated:N0} atualizados | ={resultado.unchanged:N0} inalterados");

        return resultado;
    }

    private static void EscreverHeaderEtapa(PerformContext? context, int etapa, string titulo)
    {
        if (context is null) return;
        context.WriteLine("═══════════════════════════════════════════════════════════════");
        context.WriteLine($"📍 ETAPA {etapa}: {titulo}");
        context.WriteLine("═══════════════════════════════════════════════════════════════");
    }

    // === FIM DOS ANTIGOS MÉTODOS UNIFICADOS (Caixas Postais / Grandes Usuários / Unidades Operacionais) ===

    private async Task<int> ProcessarBatchesAsync<T>(
        IAsyncEnumerable<T> fonte,
        Func<List<T>, Task> bulkInsert,
        string prefixoLog,
        PerformContext? progressContext = null)
    {
        var batch = new List<T>(BatchSize);
        int total = 0;
        int ultimoLog = 0;
        const int intervaloLog = 50_000; // Log a cada 50k registros
        const int intervaloProgressContext = 10_000; // Console a cada 10k registros

        await foreach (var item in fonte)
        {
            batch.Add(item);
            if (batch.Count >= BatchSize)
            {
                await bulkInsert(batch);
                total += batch.Count;
                batch.Clear();

                // Log apenas em intervalos específicos (Logger)
                if (total - ultimoLog >= intervaloLog)
                {
                    _logger.Information($"ZipCode - {prefixoLog} - {total:N0} registros carregados...");
                    ultimoLog = total;
                }
                
                // Log mais frequente no Hangfire Console
                if (progressContext != null && total % intervaloProgressContext == 0)
                {
                    progressContext.WriteLine($"   📦 {total:N0} registros processados...");
                }
            }
        }

        if (batch.Count > 0)
        {
            await bulkInsert(batch);
            total += batch.Count;
        }

        return total;
    }

    private static string ExtrairUF(string caminhoArquivo)
    {
        // LOG_LOGRADOURO_SP.TXT -> SP
        var nomeArquivo = Path.GetFileNameWithoutExtension(caminhoArquivo);
        var partes = nomeArquivo.Split('_');
        return partes.Length >= 3 ? partes[2] : "??";
    }

    private static string EncontrarArquivoEntrada(string pastaEntrada, string nomeArquivo)
    {
        foreach (var sub in SubpastasEntrada)
        {
            var caminho = Path.Combine(pastaEntrada, sub, nomeArquivo);
            if (File.Exists(caminho)) return caminho;
        }
        return null;
    }

    private static string[] EncontrarArquivosEntrada(string pastaEntrada, string padrao)
    {
        var resultado = new List<string>();
        foreach (var sub in SubpastasEntrada)
        {
            var pasta = Path.Combine(pastaEntrada, sub);
            if (Directory.Exists(pasta))
                resultado.AddRange(Directory.GetFiles(pasta, padrao));
        }
        return resultado.ToArray();
    }

    private void MoverParaProcessado(string pastaEntrada, string pastaProcessado)
    {
        var timestamp = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");
        var pastaDestino = Path.Combine(pastaProcessado, timestamp);
        Directory.CreateDirectory(pastaDestino);

        foreach (var sub in SubpastasEntrada)
        {
            var origem = Path.Combine(pastaEntrada, sub);
            if (!Directory.Exists(origem)) continue;

            var arquivos = Directory.GetFiles(origem);
            if (arquivos.Length == 0) continue;

            var destino = Path.Combine(pastaDestino, sub);
            Directory.CreateDirectory(destino);

            foreach (var arquivo in arquivos)
            {
                var nomeArquivo = Path.GetFileName(arquivo);
                var caminhoDestino = Path.Combine(destino, nomeArquivo);
                File.Move(arquivo, caminhoDestino, overwrite: true);
            }
        }

        // NOTA: A limpeza da pasta Entrada é responsabilidade do job DescompactaDadosService
        // Ele limpa tudo antes de descompactar novos arquivos
    }

    /// <summary>
    /// Move pasta de importação para Processado/ renomeando com data yyyyMMdd
    /// </summary>
    private void MoverParaProcessadoComTimestamp(string origem, string destinoBase, string descricao, PerformContext? context)
    {
        try
        {
            var dataAtual = DateTime.Now.ToString("yyyyMMdd");
            var nomePasta = Path.GetFileName(origem);
            var novoNome = $"{nomePasta}_{dataAtual}";
            var destino = Path.Combine(destinoBase, novoNome);
            
            Directory.CreateDirectory(destinoBase);
            
            // Remover pasta processada anterior com mesmo nome (manter apenas 1)
            var pastasAnteriores = Directory.GetDirectories(destinoBase, $"{nomePasta}_*");
            foreach (var pastaAntiga in pastasAnteriores)
            {
                try
                {
                    Directory.Delete(pastaAntiga, recursive: true);
                    _logger.Information($"ZipCode - Pasta processada anterior removida: {Path.GetFileName(pastaAntiga)}");
                }
                catch (Exception ex)
                {
                    _logger.Warning($"ZipCode - Erro ao remover pasta anterior {Path.GetFileName(pastaAntiga)}: {ex.Message}");
                }
            }
            
            Directory.Move(origem, destino);
            
            context?.WriteLine($"📦 Movido para: processado\\{novoNome}");
            _logger.Information($"ZipCode - Pasta {descricao} movida: processado/{novoNome}");
        }
        catch (Exception ex)
        {
            context?.WriteLine($"⚠️  Erro ao mover para Processado: {ex.Message}");
            _logger.Warning($"ZipCode - Erro ao mover pasta {descricao}: {ex.Message}");
        }
    }

    private void SalvarMudancasJson(string pastaJson, List<ChangeRecord> mudancas)
    {
        try
        {
            // Limpar arquivos JSON existentes na pasta
            if (Directory.Exists(pastaJson))
            {
                var arquivosExistentes = Directory.GetFiles(pastaJson, "mudancas_*.json");
                foreach (var arquivo in arquivosExistentes)
                {
                    File.Delete(arquivo);
                }
                
                if (arquivosExistentes.Length > 0)
                {
                    _logger.Information($"ZipCode - {arquivosExistentes.Length} arquivo(s) JSON antigo(s) removido(s)");
                }
            }
            
            var timestamp = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");
            var caminhoJson = Path.Combine(pastaJson, $"mudancas_{timestamp}.json");

            // CORREÇÃO: Converter ChangeRecord para PostalInfo antes de salvar
            // O consumer espera o formato PostalInfo diretamente, não ChangeRecord
            var postalInfoList = mudancas.Select(m => ConverterChangeRecordParaPostalInfo(m)).ToList();

            var options = new JsonSerializerOptions
            {
                WriteIndented = true,
                PropertyNamingPolicy = null, // CORREÇÃO: PascalCase (padrão .NET) ao invés de camelCase
                Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            };

            var json = JsonSerializer.Serialize(postalInfoList, options);
            File.WriteAllText(caminhoJson, json, Encoding.UTF8);
            
            _logger.Information($"ZipCode - JSON salvo com {postalInfoList.Count} registros PostalInfo: {caminhoJson}");
        }
        catch (Exception ex)
        {
            _logger.Warning($"ZipCode - Falha ao salvar JSON de mudanças: {ex.Message}");
        }
    }

    /// <summary>
    /// Converte ChangeRecord para o formato PostalInfo esperado pelo consumer.
    /// Conforme especificação: PROMPT_INTEGRACAO_RABBITMQ.md
    /// </summary>
    private static Uninter.Correios.CrossCutting.Messaging.PostalInfo ConverterChangeRecordParaPostalInfo(ChangeRecord mudanca)
    {
        // Extrair ZipCode da chave primária como string
        var zipCode = mudanca.ChavePrimaria.TryGetValue("Id", out var idValue) 
            ? (idValue?.ToString() ?? string.Empty).PadLeft(8, '0')  // ✅ Garante 8 dígitos
            : string.Empty;

        // Extrair valores dos campos
        var cityId = ObterValorLong(mudanca.ValoresNovos, "CityId");
        var district = ObterValorString(mudanca.ValoresNovos, "District");
        var address = ObterValorString(mudanca.ValoresNovos, "Address");
        var number = ObterValorString(mudanca.ValoresNovos, "Number");
        var typeId = ObterValorInt(mudanca.ValoresNovos, "TypeId");

        return new Uninter.Correios.CrossCutting.Messaging.PostalInfo
        {
            ZipCode = zipCode,
            CityId = cityId,
            District = district,
            Address = address,
            Number = number,
            TypeId = typeId
        };
    }

    private static string ObterValorString(Dictionary<string, object?> valores, string chave)
    {
        if (valores.TryGetValue(chave, out var valor) && valor != null)
        {
            return valor.ToString() ?? string.Empty;
        }
        return string.Empty;
    }

    private static long ObterValorLong(Dictionary<string, object?> valores, string chave)
    {
        if (valores.TryGetValue(chave, out var valor) && valor != null)
        {
            if (valor is long longValue)
                return longValue;
            
            if (long.TryParse(valor.ToString(), out var parsed))
                return parsed;
        }
        return 0;
    }

    private static int ObterValorInt(Dictionary<string, object?> valores, string chave)
    {
        if (valores.TryGetValue(chave, out var valor) && valor != null)
        {
            if (valor is int intValue)
                return intValue;
            
            if (int.TryParse(valor.ToString(), out var parsed))
                return parsed;
        }
        return 0;
    }

    /// <summary>
    /// Envia as mudanças para a fila RabbitMQ (Segunda Fase).
    /// TODO: Implementar integração com RabbitMQ quando necessário.
    /// </summary>
    private async Task EnviarParaFilaRabbitMQ(List<ChangeRecord> mudancas)
    {
        // Preparado para segunda fase
        // Aqui será implementada a lógica de envio para fila
        _logger.Information($"ZipCode - Preparado para enviar {mudancas.Count} mudanças para RabbitMQ (aguardando implementação)");
        await Task.CompletedTask;
    }

    private static void GravarLogErro(string pastaErro, Exception ex, TimeSpan tempoDecorrido)
    {
        try
        {
            Directory.CreateDirectory(pastaErro);
            var timestamp = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");
            var caminhoLog = Path.Combine(pastaErro, $"erro_{timestamp}.log");

            var sb = new StringBuilder();
            sb.AppendLine($"Data/Hora  : {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            sb.AppendLine($"Duração    : {tempoDecorrido.TotalMinutes:F1} min");
            sb.AppendLine($"Tipo       : {ex.GetType().FullName}");
            sb.AppendLine($"Mensagem   : {ex.Message}");
            sb.AppendLine();
            sb.AppendLine("Stack Trace:");
            sb.AppendLine(ex.StackTrace);

            var inner = ex.InnerException;
            int nivel = 1;
            while (inner is not null)
            {
                sb.AppendLine();
                sb.AppendLine($"--- Inner Exception (nível {nivel++}) ---");
                sb.AppendLine($"Tipo       : {inner.GetType().FullName}");
                sb.AppendLine($"Mensagem   : {inner.Message}");
                sb.AppendLine(inner.StackTrace);
                inner = inner.InnerException;
            }

            File.WriteAllText(caminhoLog, sb.ToString(), Encoding.UTF8);
        }
        catch
        {
            // best-effort: falha ao gravar log não deve ocultar o erro original
        }
    }
}
