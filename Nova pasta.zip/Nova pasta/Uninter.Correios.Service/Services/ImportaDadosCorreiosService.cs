using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Threading.Tasks;

using Hangfire.Console;
using Hangfire.Server;

using Microsoft.Extensions.Options;

using Uninter.Correios.CrossCutting.Configurations;
using Uninter.Correios.CrossCutting.Contract;
using Uninter.Correios.Domain.Interfaces.Service;

namespace Uninter.Correios.Service.Services;

/// <summary>
/// Serviço responsável APENAS pelo download dos arquivos dos Correios.
/// Não extrai, não move e não remove arquivos.
/// </summary>
public class ImportaDadosCorreiosService : IImportaDadosCorreiosService
{
    private readonly IOptions<AppSettings> _appSettings;
    private readonly IAppLogger _logger;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IExecutaImportadorService _executaImportador;

    public ImportaDadosCorreiosService(
        IOptions<AppSettings> appSettings, 
        IAppLogger logger, 
        IHttpClientFactory httpClientFactory,
        IExecutaImportadorService executaImportador)
    {
        _appSettings = appSettings;
        _logger = logger;
        _httpClientFactory = httpClientFactory;
        _executaImportador = executaImportador;
    }

    public async Task DownloadEExecutarAsync(PerformContext context = null)
    {
        await DownloadAsync(context);
        // Nota: A execução do importador deve ser feita manualmente via dashboard
        // ou através de um job separado que orquestre todo o fluxo
    }

    public async Task DownloadAsync(PerformContext context = null)
    {
        var urlDownload = _appSettings.Value.EnderecoArquivoCorreiosZip;
        var raiz = _appSettings.Value.CaminhoProcessarArquivos;

        if (string.IsNullOrWhiteSpace(urlDownload))
        {
            var msg = "EnderecoArquivoCorreiosZip não configurado nas appsettings.";
            _logger.Warning($"ZipCode - {msg}");
            context?.WriteLine($"❌ ERRO: {msg}");
            throw new InvalidOperationException(msg);
        }

        if (string.IsNullOrWhiteSpace(raiz))
        {
            var msg = "CaminhoProcessarArquivos não configurado nas appsettings.";
            _logger.Warning($"ZipCode - {msg}");
            context?.WriteLine($"❌ ERRO: {msg}");
            throw new InvalidOperationException(msg);
        }

        var pastaZipado = Path.Combine(raiz, _appSettings.Value.CorreiosArquivos.PastaArquivosZipados);
        var pastaBkp = Path.Combine(pastaZipado, _appSettings.Value.CorreiosArquivos.PastaBackup);
        
        // Criar pastas se não existirem
        Directory.CreateDirectory(pastaZipado);
        Directory.CreateDirectory(pastaBkp);
        
        // MOVER ARQUIVO EXISTENTE PARA BKP ANTES DE BAIXAR NOVO
        var nomeArquivoZip = _appSettings.Value.CorreiosArquivos.NomeArquivoZip;
        var caminhoArquivoAtual = Path.Combine(pastaZipado, nomeArquivoZip);
        var caminhoBackup = Path.Combine(pastaBkp, nomeArquivoZip);
        
        if (File.Exists(caminhoArquivoAtual))
        {
            try
            {
                var tamanhoMB = new FileInfo(caminhoArquivoAtual).Length / 1024.0 / 1024.0;
                
                context?.WriteLine($"💾 Movendo arquivo existente para backup...");
                _logger.Information($"ZipCode - Movendo: {nomeArquivoZip} → bkp/{nomeArquivoZip}");
                
                // Remover arquivo anterior em bkp se existir
                if (File.Exists(caminhoBackup))
                {
                    File.Delete(caminhoBackup);
                    _logger.Information($"ZipCode - Backup anterior removido");
                }
                
                // Mover arquivo atual para bkp
                File.Move(caminhoArquivoAtual, caminhoBackup);
                
                context?.WriteLine($"✅ Arquivo movido para bkp/ ({tamanhoMB:F1} MB)");
                _logger.Information($"ZipCode - Arquivo movido para backup: {caminhoBackup} ({tamanhoMB:F1} MB)");
            }
            catch (Exception ex)
            {
                // Se o arquivo está bloqueado por outro processo, abortar o job imediatamente.
                // Não continuar — a tentativa de gravação também falharia com o mesmo erro.
                var msg = $"Arquivo {nomeArquivoZip} está em uso por outro processo. Verifique se há outra execução em andamento. Detalhe: {ex.Message}";
                _logger.Error($"ZipCode - {msg}", ex);
                context?.WriteLine($"❌ {msg}");
                throw new IOException(msg, ex);
            }
        }

        // Nome configurável via appsettings (CorreiosArquivos:NomeArquivoZip)
        var caminhoZipTemp = Path.Combine(pastaZipado, nomeArquivoZip);

        _logger.Information("ZipCode - === DOWNLOAD CORREIOS INICIADO ===");
        _logger.Information($"ZipCode - URL: {urlDownload}");
        _logger.Information($"ZipCode - Destino: {caminhoZipTemp}");
        
        context?.WriteLine("📥 === DOWNLOAD CORREIOS INICIADO ===");
        context?.WriteLine($"🔗 URL: {urlDownload}");
        context?.WriteLine($"💾 Destino: {caminhoZipTemp}");

        var sw = Stopwatch.StartNew();

        try
        {
            var httpClient = _httpClientFactory.CreateClient();
            httpClient.Timeout = TimeSpan.FromHours(_appSettings.Value.CorreiosArquivos.DownloadTimeoutHoras);

            using var response = await httpClient.GetAsync(urlDownload, HttpCompletionOption.ResponseHeadersRead);
            response.EnsureSuccessStatusCode();

            var contentLength = response.Content.Headers.ContentLength;
            if (contentLength.HasValue)
            {
                _logger.Information($"ZipCode - Tamanho esperado: {contentLength.Value / 1024.0 / 1024.0:F1} MB");
                context?.WriteLine($"📦 Tamanho esperado: {contentLength.Value / 1024.0 / 1024.0:F1} MB");
            }
            else
            {
                _logger.Information("ZipCode - Tamanho esperado: desconhecido (servidor não informou Content-Length)");
                context?.WriteLine("⚠️ Tamanho esperado: desconhecido");
            }

            await using (var streamOrigem = await response.Content.ReadAsStreamAsync())
            await using (var streamDestino = new FileStream(caminhoZipTemp, FileMode.Create, FileAccess.Write, FileShare.None, 81920, useAsync: true))
            {
                var progressBar = context?.WriteProgressBar();
                var buffer = new byte[81920];
                long totalBytes = 0;
                int lidos;
                long ultimoLog = 0;
                const long intervaloLog = 50 * 1024 * 1024; // Log a cada 50 MB

                while ((lidos = await streamOrigem.ReadAsync(buffer, 0, buffer.Length)) > 0)
                {
                    await streamDestino.WriteAsync(buffer, 0, lidos);
                    totalBytes += lidos;

                    // Atualizar barra de progresso no Hangfire (sem gravar no banco)
                    if (contentLength.HasValue && progressBar is not null)
                    {
                        var pct = (int)(totalBytes * 100.0 / contentLength.Value);
                        progressBar.SetValue(pct);
                    }

                    // Log apenas a cada 50 MB para não poluir
                    if (totalBytes - ultimoLog >= intervaloLog)
                    {
                        if (contentLength.HasValue)
                        {
                            var pct = totalBytes * 100.0 / contentLength.Value;
                            _logger.Information($"ZipCode - Download: {pct:F1}% ({totalBytes / 1024.0 / 1024.0:F1} MB)");
                        }
                        else
                        {
                            _logger.Information($"ZipCode - Download: {totalBytes / 1024.0 / 1024.0:F1} MB baixados");
                        }
                        ultimoLog = totalBytes;
                    }
                }
            }

            // Verificar integridade
            var tamanhoGravado = new FileInfo(caminhoZipTemp).Length;
            if (contentLength.HasValue && tamanhoGravado != contentLength.Value)
            {
                var msg = $"Download incompleto: esperado {contentLength.Value} bytes, gravados {tamanhoGravado} bytes.";
                var exIncompleto = new IOException(msg);
                File.Delete(caminhoZipTemp);
                _logger.Error($"ZipCode - {msg}", exIncompleto);
                throw exIncompleto;
            }

            sw.Stop();
            _logger.Information($"ZipCode - Download concluído em {sw.Elapsed.TotalSeconds:F1}s — {tamanhoGravado / 1024.0 / 1024.0:F1} MB.");
            context?.WriteLine($"✅ Download concluído: {tamanhoGravado / 1024.0 / 1024.0:F1} MB em {sw.Elapsed.TotalSeconds:F1}s");
            context?.WriteLine($"💾 Arquivo salvo: {caminhoZipTemp}");
            
            _logger.Information($"ZipCode - Arquivo ZIP disponível em: {caminhoZipTemp}");
            _logger.Information("ZipCode - === DOWNLOAD CONCLUÍDO ===");
            context?.WriteLine("✅ === DOWNLOAD CONCLUÍDO ===");
        }
        catch (Exception ex) when (ex is not IOException)
        {
            sw.Stop();
            _logger.Error($"ZipCode - Erro no download após {sw.Elapsed.TotalSeconds:F1}s: {ex.Message}", ex);
            context?.WriteLine($"❌ ERRO no download após {sw.Elapsed.TotalSeconds:F1}s");
            context?.WriteLine($"❌ {ex.GetType().Name}: {ex.Message}");
            context?.WriteLine("⚠️ Arquivo parcial não foi removido. Verifique: " + caminhoZipTemp);

            // NÃO remove o arquivo - deixa para análise ou limpeza manual
            throw;
        }
    }
}
