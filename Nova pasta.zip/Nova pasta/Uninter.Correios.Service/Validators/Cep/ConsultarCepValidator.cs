using FluentValidation;
using Uninter.Correios.CrossCutting.Constants;
using Uninter.Correios.CrossCutting.Extensions;
using Uninter.Correios.Domain.Request.Cep;

namespace Uninter.Correios.Service.Validators.Cep;

/// <summary>
/// Validador para consulta de CEP.
/// </summary>
public class ConsultarCepValidator : AbstractValidator<ConsultarCepRequest>
{
    public ConsultarCepValidator()
    {
        ClassLevelCascadeMode = CascadeMode.Stop;

        RegrasBasicas();
    }

    private void RegrasBasicas()
    {
        RuleFor(c => c.Cep)
            .NotEmpty()
            .WithMessage(c => $"{nameof(c.Cep)} é obrigatório.")
            .Must(cep => cep.IsCepValido())
            .WithMessage(c => CorreiosConstants.ErrorMessages.CEP_INVALIDO);
    }
}
