using FluentValidation;
using Uninter.Correios.CrossCutting.Helpers;
using Uninter.Correios.Domain.Request.Api;

namespace Uninter.Correios.Service.Validators;

/// <summary>
/// Validador para ListaEnderecosQueryParams.
/// Implementa as regras de validação conforme documentação da API dos Correios v2.
/// </summary>
public class ListaEnderecosQueryParamsValidator : AbstractValidator<ListaEnderecosQueryParams>
{
    public ListaEnderecosQueryParamsValidator()
    {
        // ========================================
        // VALIDAÇÕES DE LOGRADOURO
        // ========================================

        // Logradouro não deve conter vírgulas
        RuleFor(x => x.Logradouro)
            .Must(logradouro => !LogradouroHelper.ContemVirgula(logradouro))
            .WithMessage(x =>
            {
                var sugestao = LogradouroHelper.ObterSugestao(x.Logradouro);
                return $"O campo 'logradouro' não deve conter vírgulas ou números. " +
                       $"Informe apenas o nome da rua/avenida. Sugestão: '{sugestao}'";
            })
            .When(x => !string.IsNullOrWhiteSpace(x.Logradouro));

        // Logradouro não deve conter números
        RuleFor(x => x.Logradouro)
            .Must(logradouro => !LogradouroHelper.ContemNumeros(logradouro))
            .WithMessage(x =>
            {
                var sugestao = LogradouroHelper.ObterSugestao(x.Logradouro);
                return $"O campo 'logradouro' não deve conter números. " +
                       $"Informe apenas o nome da rua/avenida. Sugestão: '{sugestao}'";
            })
            .When(x => !string.IsNullOrWhiteSpace(x.Logradouro));

        // Se informar Logradouro, UF é obrigatória
        RuleFor(x => x.Uf)
            .NotEmpty()
            .WithMessage("Quando informar 'logradouro', o campo 'uf' é obrigatório.")
            .When(x => !string.IsNullOrWhiteSpace(x.Logradouro));

        // ========================================
        // VALIDAÇÕES DE BAIRRO
        // ========================================

        // Se informar Bairro, UF é obrigatória
        RuleFor(x => x.Uf)
            .NotEmpty()
            .WithMessage("Quando informar 'bairro', o campo 'uf' é obrigatório.")
            .When(x => !string.IsNullOrWhiteSpace(x.Bairro) && string.IsNullOrWhiteSpace(x.Logradouro));

        // Se informar Bairro, Localidade é obrigatória
        RuleFor(x => x.Localidade)
            .NotEmpty()
            .WithMessage("Quando informar 'bairro', o campo 'localidade' é obrigatório.")
            .When(x => !string.IsNullOrWhiteSpace(x.Bairro));

        // ========================================
        // VALIDAÇÕES DE UF
        // ========================================

        // UF deve ser válida (estados brasileiros)
        RuleFor(x => x.Uf)
            .Must(uf => UnidadeFederativaHelper.IsUfValida(uf))
            .WithMessage(x => $"UF '{x.Uf}' é inválida. " +
                             $"UFs válidas: {string.Join(", ", UnidadeFederativaHelper.ObterTodasUFs())}")
            .When(x => !string.IsNullOrWhiteSpace(x.Uf));

        // ========================================
        // VALIDAÇÕES DE PAGINAÇÃO
        // ========================================

        // Page não pode ser negativo
        RuleFor(x => x.Page)
            .GreaterThanOrEqualTo(0)
            .WithMessage("O número da página (page) não pode ser negativo.");

        // Size deve estar entre 1 e 2000
        RuleFor(x => x.Size)
            .InclusiveBetween(1, 2000)
            .WithMessage("O tamanho da página (size) deve estar entre 1 e 2000.");
    }
}
